
struct Declarator
{
  DeclaratorType type;
  DeclaratorScope scope;
  char * name;
} Declarator;
