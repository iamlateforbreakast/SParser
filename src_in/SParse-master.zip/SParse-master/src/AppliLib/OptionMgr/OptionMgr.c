/**********************************************//** 
  @file OptionMgr.c
  
  @class OptionMgr
  
  @brief The OptionMgr class manages the application configuration.
  
  The class OptionMgr is TBD
**************************************************/