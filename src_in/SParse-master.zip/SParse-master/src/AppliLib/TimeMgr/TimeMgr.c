/**********************************************//** 
  @file TimeMgr.c
  
  @class TimeMgr
  
  @brief This file implements the class TimeMgr
  
  The class TimeMgr is TBD
**************************************************/