/**********************************************//** 
  @file TimeMgr.h
  
  @class TimeMgr
  
  @brief This file contains the prototye for the class TimeMgr
  
  The class TimeMgr is TBD
**************************************************/