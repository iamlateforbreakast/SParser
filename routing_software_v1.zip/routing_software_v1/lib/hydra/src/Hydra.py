#!/usr/bin/env python3
 
"""-----------------------------------------------
 Class and functions for the main application
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import os
import logging
import math
import time

from lib.hydra.src.system.DTPSystem import DTPSystem
from lib.hydra.src.operator.Operator import Operator
from lib.hydra.src.routing.Routing import Routing
from lib.shared.hca_logger.hca_logger import HCALogger


class Hydra(object):
    
    def __init__(self, config_path, **kwargs):
        
        """
        Constructor
        
        Builds the routing manager based on the specified configuration
        file, and sets up the relevant logging (to console/file).
        
        @param config_path: absolute path or name of the YAML
            configuration file. Raises an exception if specified
            file path is invalid, or file is not of YAML format.
        @param **kwargs: kw arguments which should be a subset of:
            use_dcm: if True, connect to external interface such as 
                the simulator or other harware. Default to False for
                DROP 1 of software.
            console_log: if True, logs to console (default False),
            file_log: if True, logs to a text file (default False),
            log_file_dir: relative path to the hydra log file, defaults
                to '<cwd>/logs',
            log_file_name: name of the hydra log file, defaults to
                'hydra_%(timestamp)s.log',
            log_level: the level the hydra logger will log to, defaults
                to INFO level,
            logger_name: name of the hydra logger, defaults to 'HYDRA'.
        """
        
#         self.config_path = config_path
        
        # Connection to external (sim or hardware) using DCM
        use_dcm = kwargs.pop('use_dcm', True)
        
        console_log = kwargs.pop('console_log', False)
        file_log = kwargs.pop('file_log', False)
        
        log_file_dir = kwargs.pop('filedir', 'logs')
        log_file_name = kwargs.pop('filename', 'hydra_%(timestamp)s.log')
        
        log_level = kwargs.pop('log_level', logging.INFO)
        logger_name = kwargs.pop('logger_name', 'HYDRA')
        
        # Setup the HCA logging package
        if console_log and not file_log:
            HCALogger.setup(
                log_to_console = console_log,
                log_to_file = file_log,
                level = log_level
                )
            self.logger = logging.getLogger(name=logger_name)
        elif file_log and not console_log:
            HCALogger.setup(
                log_to_file = file_log,
                filedir = log_file_dir,
                filename = log_file_name,
                level = log_level
                )
            self.logger = logging.getLogger(name=logger_name)
        elif console_log and file_log:
            HCALogger.setup(
                log_to_console = console_log,
                log_to_file = file_log,
                filedir = log_file_dir,
                filename = log_file_name,
                level = log_level
                )
            self.logger = logging.getLogger(name=logger_name)

        else:
            # If no console or file logging specified, explicitly 
            # disable logging (for performance reasons).
            self.logger = None
            logging.disable(logging.CRITICAL)
            
        # Build DTP system for routing based on config file.
        self.dtp = DTPSystem(self.logger, config_path)
        
        # Set up the operator settings (BeamManager, LinkManager).
        self.operator = Operator(self.logger, self.dtp.antenna_elements,
                                 self.dtp.gateway_antennas)
        
        # Start the routing algorithm functions for the loaded system
        self.routing = Routing(self.logger, self.dtp, self.operator, use_dcm)
        
    
    def create_channel(self, chan_id, uplink, downlink, gain, target_page):
        
        if not self.dtp:
            raise Exception("No system available.")
            
        elif self.dtp:
            try:
                chan = self.routing.create_channel(chan_id, 
                                                   uplink, downlink, 
                                                   gain, target_page)
                
                self.logger.info(f"Successfully created {uplink.frequency_block.width} MHz wide channel.")
                self.logger.info(f"{chan_id}, {uplink.frequency_block.centre_freq} MHz, {downlink.frequency_block.centre_freq} MHz")
                return chan
            except ValueError as e:
                raise ValueError('Command \'create_channel\' failed') from e
    
    def delete_channel(self, channel_id, target_page):
       
        if self.logger:
            self.logger.setLevel(logging.INFO)
        
        if not self.dtp:
            raise Exception("No system available.")
        
        elif not self.operator.channel_storage.channels:
            raise Exception("No channels present in system")
        
        else:
            try:
                self.routing.delete_channel(channel_id, target_page)
            except ValueError as e:
                raise ValueError("Command 'delete_channel' failed") from e

                

if __name__ == '__main__':
    
    hydra = Hydra(r"C:\0_work\hca\config\onesat_dtp_arch_a.yml",
                  console_log = True, 
                  file_log = True,
                  use_dcm = False)
    
    hydra.operator.load_beams('test_8_elems.yaml')
    
    l1 = hydra.operator.link_manager.generate_link('uplink_1', 'rx_beam_8_elem', 30180, 100)
     
    l2 = hydra.operator.link_manager.generate_link('downlink_1', 'tx_beam_8_elem', 30220, 100)
#     
#     start_time = time.time()
#     
#     hydra.create_channel('12345', l1, l2, None, 0)
#     
#     print(time.time() - start_time)

#     l1 = hydra.operator.link_manager.generate_link('uplink_1', -4, 31500, 100)
#       
#     l2 = hydra.operator.link_manager.generate_link('downlink_1', -15, 31500, 100)
     
    start_time = time.time()
     
    hydra.create_channel('gw_gw_1', l1, l2, None, 0)
     
    print(time.time() - start_time)
    
    for rx in hydra.dtp.rxs:
        iss_i = 0
        for tdm in rx.bfn_blocks[0].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                          
        ts_i = 0
        for tdm in rx.bfn_blocks[0].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                          
        oss_i = 0
        for tdm in rx.bfn_blocks[0].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                          
        print(rx.name, iss_i, ts_i, oss_i)
#   
    for rxbfn in hydra.dtp.rxbfns:
        iss_i = 0
        for tdm in rxbfn.bfn_blocks[0].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                          
        ts_i = 0
        for tdm in rxbfn.bfn_blocks[0].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                          
        oss_i = 0
        for tdm in rxbfn.bfn_blocks[0].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                          
        print(rxbfn.name, iss_i, ts_i, oss_i)
      
    for rxbfn in hydra.dtp.rxbfns:
        iss_i = 0
        for tdm in rxbfn.bfn_blocks[1].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                        
        ts_i = 0
        for tdm in rxbfn.bfn_blocks[1].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                        
        oss_i = 0
        for tdm in rxbfn.bfn_blocks[1].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                        
        print(rxbfn.name, iss_i, ts_i, oss_i)
        
    for txbfn in hydra.dtp.txbfns:
        iss_i = 0
        for tdm in txbfn.bfn_blocks[0].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                        
        ts_i = 0
        for tdm in txbfn.bfn_blocks[0].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                        
        oss_i = 0
        for tdm in txbfn.bfn_blocks[0].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                        
        print(txbfn.name, iss_i, ts_i, oss_i)

    for txbfn in hydra.dtp.txbfns:
        iss_i = 0
        for tdm in txbfn.bfn_blocks[1].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                        
        ts_i = 0
        for tdm in txbfn.bfn_blocks[1].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                        
        oss_i = 0
        for tdm in txbfn.bfn_blocks[1].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                        
        print(txbfn.name, iss_i, ts_i, oss_i)
        
    for sw in hydra.dtp.sws:
        iss_i = 0
        for tdm in sw.bfn_blocks[0].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                        
        ts_i = 0
        for tdm in sw.bfn_blocks[0].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                        
        oss_i = 0
        for tdm in sw.bfn_blocks[0].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                        
        print(sw.name, iss_i, ts_i, oss_i)

    for sw in hydra.dtp.sws:
        iss_i = 0
        for tdm in sw.bfn_blocks[1].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                        
        ts_i = 0
        for tdm in sw.bfn_blocks[1].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                        
        oss_i = 0
        for tdm in sw.bfn_blocks[1].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                        
        print(sw.name, iss_i, ts_i, oss_i)
        

    for tx in hydra.dtp.txs:
        iss_i = 0
        for tdm in tx.bfn_blocks[1].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                       
        ts_i = 0
        for tdm in tx.bfn_blocks[1].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                       
        oss_i = 0
        for tdm in tx.bfn_blocks[1].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                       
        print(tx.name, iss_i, ts_i, oss_i)
    
    start_time = time.time()
     
    hydra.delete_channel('gw_gw_1', 0)
     
    print(time.time() - start_time)

#     l1 = hydra.operator.link_manager.generate_link('uplink_1', 'rx_beam_8_elem', 30180, 100)
#      
#     l2 = hydra.operator.link_manager.generate_link('downlink_1', -15, 30220, 100)
#      
#     start_time = time.time()
#      
#     hydra.create_channel('12345', l1, l2, None, 0)
#      
#     print(time.time() - start_time)
    
#     l1 = hydra.operator.link_manager.generate_link('uplink_1', -4, 30180, 100)
#      
#     l2 = hydra.operator.link_manager.generate_link('downlink_1', 'tx_beam_8_elem', 30220, 100)
#      
#     start_time = time.time()
#      
#     hydra.create_channel('12345', l1, l2, None, 0)
#      
#     print(time.time() - start_time)

#     i = 0
#     for txbfn in hydra.dtp.txbfns:
#         for bfn_block in txbfn.bfn_blocks:
#             for eng in bfn_block.bfns:
#                 for ram in eng.rams.occupancy:
#                     for slot in ram:
#                         if slot != []:
#                             i+=1
#     print(i)
                    
    
    
    
#     l1 = hydra.operator.link_manager.generate_link('uplink_2', 'rx_beam_8_elem', 30300, 100)
#     
#     l2 = hydra.operator.link_manager.generate_link('downlink_2', 'tx_beam_8_elem2', 30220, 100)
#     
#     hydra.create_channel('678910', l1, l2, None, 0)
    
#     l1 = hydra.operator.link_manager.generate_link('uplink_2', 'rx_beam_78_elem', 30300, 50)
#      
#     l2 = hydra.operator.link_manager.generate_link('downlink_2', 'tx_beam_78_elem', 30100, 50)
#      
#     hydra.create_channel('678910', l1, l2, None, 0)
    
    
    
#     i = 0
#     for rx in hydra.dtp.rxs:
#         hydra.logger.debug(rx.name)
#         for tdm in rx.bfn_blocks[0].ts.occupancy:
#             if i%8:
#                 hydra.logger.debug(tdm)
#             else:
#                 hydra.logger.debug('')
#                 hydra.logger.debug(tdm)
#             i+=1
#         break

#     for rxbfn in hydra.dtp.rxbfns:
#         print(rxbfn.name)
#         for eng in rxbfn.bfn_blocks[0].bfns:
#             print(eng.id)
#             
#             for freq in eng.frequency:
#                 print(freq['id'], freq['value'], freq['slots'])
#             input()
#     
    
    for rx in hydra.dtp.rxs:
        iss_i = 0
        for tdm in rx.bfn_blocks[0].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                          
        ts_i = 0
        for tdm in rx.bfn_blocks[0].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                          
        oss_i = 0
        for tdm in rx.bfn_blocks[0].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                          
        print(rx.name, iss_i, ts_i, oss_i)
#   
    for rxbfn in hydra.dtp.rxbfns:
        iss_i = 0
        for tdm in rxbfn.bfn_blocks[0].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                          
        ts_i = 0
        for tdm in rxbfn.bfn_blocks[0].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                          
        oss_i = 0
        for tdm in rxbfn.bfn_blocks[0].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                          
        print(rxbfn.name, iss_i, ts_i, oss_i)
      
    for rxbfn in hydra.dtp.rxbfns:
        iss_i = 0
        for tdm in rxbfn.bfn_blocks[1].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                        
        ts_i = 0
        for tdm in rxbfn.bfn_blocks[1].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                        
        oss_i = 0
        for tdm in rxbfn.bfn_blocks[1].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                        
        print(rxbfn.name, iss_i, ts_i, oss_i)
        
    for txbfn in hydra.dtp.txbfns:
        iss_i = 0
        for tdm in txbfn.bfn_blocks[0].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                        
        ts_i = 0
        for tdm in txbfn.bfn_blocks[0].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                        
        oss_i = 0
        for tdm in txbfn.bfn_blocks[0].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                        
        print(txbfn.name, iss_i, ts_i, oss_i)

    for txbfn in hydra.dtp.txbfns:
        iss_i = 0
        for tdm in txbfn.bfn_blocks[1].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                        
        ts_i = 0
        for tdm in txbfn.bfn_blocks[1].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                        
        oss_i = 0
        for tdm in txbfn.bfn_blocks[1].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                        
        print(txbfn.name, iss_i, ts_i, oss_i)
        
    for sw in hydra.dtp.sws:
        iss_i = 0
        for tdm in sw.bfn_blocks[0].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                        
        ts_i = 0
        for tdm in sw.bfn_blocks[0].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                        
        oss_i = 0
        for tdm in sw.bfn_blocks[0].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                        
        print(sw.name, iss_i, ts_i, oss_i)

    for sw in hydra.dtp.sws:
        iss_i = 0
        for tdm in sw.bfn_blocks[1].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                        
        ts_i = 0
        for tdm in sw.bfn_blocks[1].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                        
        oss_i = 0
        for tdm in sw.bfn_blocks[1].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                        
        print(sw.name, iss_i, ts_i, oss_i)
        

    for tx in hydra.dtp.txs:
        iss_i = 0
        for tdm in tx.bfn_blocks[1].iss.occupancy:
            for ts in tdm:
                if ts != []:
                    iss_i+=1
                       
        ts_i = 0
        for tdm in tx.bfn_blocks[1].ts.occupancy:
            for ts in tdm:
                if ts != []:
                    ts_i+=1
                       
        oss_i = 0
        for tdm in tx.bfn_blocks[1].oss.occupancy:
            for ts in tdm:
                if ts != []:
                    oss_i+=1
                       
        print(tx.name, iss_i, ts_i, oss_i)
#   
#     for rxbfn in hydra.dtp.rxbfns:
#         print(rxbfn.name)
#         for b_id,bfn_block in enumerate(rxbfn.bfn_blocks):
#             print(b_id)
#             for bfn in bfn_block.bfns:
#                 print(bfn.name)
#                 for ram_i in range(8):
#                     print(bfn.rams.occupancy[ram_i])
#                 input()
#             input()
#     for txbfn in hydra.dtp.txbfns:
#         iss_i = 0
#         for tdm in txbfn.bfn_blocks[0].iss.occupancy:
#             for ts in tdm:
#                 if ts != []:
#                     iss_i+=1
#                        
#         ts_i = 0
#         for tdm in txbfn.bfn_blocks[0].ts.occupancy:
#             for ts in tdm:
#                 if ts != []:
#                     ts_i+=1
#                        
#         oss_i = 0
#         for tdm in txbfn.bfn_blocks[0].oss.occupancy:
#             for ts in tdm:
#                 if ts != []:
#                     oss_i+=1
#                        
#         print(txbfn.name, iss_i, ts_i, oss_i)
    
#     a = hydra.routing.stage_one.freq_to_bfn_lut
#     print(a[(30000,'HORIZ')])
#     print(a[(30000,'VERT')])
#     
#     b = hydra.routing.stage_two.freq_to_bfn_lut
#     print(b[(30000,'HORIZ')])
#     print(b[(30000,'VERT')])
    

    
    # Other config files: # five_rank_config_example.yml
    #hydra.loadSystem(config='default', use_dcm = False) 
    
#     # Generate some Link objects
#     from lib.hydra.tools.dummy_link_gen.LinkManager import LinkManager
#     link_manager = LinkManager(hydra.dtp)
#     
#     uplink = link_manager.generate_link('uplink_0', 'rx_beam_0', 8000, 8)
#     downlink = link_manager.generate_link('downlink_0', 'tx_beam_0', 7650, 8)
#     
#     hydra.create_channel(uplink, downlink, None)
     
     
#     a=hydra.create_channel(1, 2192, 1, 2192)
#     print(a.rx)
#     hydra.create_channel(2, 2672, 3, 2672)
#     hydra.create_channel(1, 3152, 1, 3152)
#     hydra.create_channel(7, 3632, 13, 3932)
#     hydra.delete_channel(7, 3632, 13, 3932)
    
#     r = next(a for a in hydra.dtp.rxs)
# #     i=0
#     for p in r.outPorts.values():
#         if p.serdes:
#             print(p)
    
#     for c in hydra.dtp.system_manager.channels:
# #         print(c.up_fdr, c.up_frq, c.dwn_fdr, c.dwn_frq)
#         print(c.id)
#     c = next(a for a in hydra._dtp.system_manager.channels)
#     print(c.id)
#     
#     print(f"{c.rx} has {len(c.rx.sts.SS1.usage)} channels ")
#     print(f"{c.rx} has {len(c.rx.sts.TS.usage)} channels ")
#     print(f"{c.rx} has {len(c.rx.sts.SS2.usage)} channels ")
# 
#     print(f"{c.sw} has {len(c.sw.sts.SS1.usage)} channels ")
#     print(f"{c.sw} has {len(c.sw.sts.TS.usage)} channels ")
#     print(f"{c.sw} has {len(c.sw.sts.SS2.usage)} channels ")
# 
#     print(f"{c.tx} has {len(c.tx.sts.SS1.usage)} channels ")
#     print(f"{c.tx} has {len(c.tx.sts.TS.usage)} channels ")
#     print(f"{c.tx} has {len(c.tx.sts.SS2.usage)} channels ")
#     
#     for rx in hydra._dtp.rxs:
#         print(rx.sts.SS1.usage)
#          
#     input()
#     c.delete()
# 
#     print(f"{c.rx} has {len(c.rx.sts.SS1.usage)} channels ")
#     print(f"{c.rx} has {len(c.rx.sts.TS.usage)} channels ")
#     print(f"{c.rx} has {len(c.rx.sts.SS2.usage)} channels ")
# 
#     print(f"{c.sw} has {len(c.sw.sts.SS1.usage)} channels ")
#     print(f"{c.sw} has {len(c.sw.sts.TS.usage)} channels ")
#     print(f"{c.sw} has {len(c.sw.sts.SS2.usage)} channels ")
# 
#     print(f"{c.tx} has {len(c.tx.sts.SS1.usage)} channels ")
#     print(f"{c.tx} has {len(c.tx.sts.TS.usage)} channels ")
#     print(f"{c.tx} has {len(c.tx.sts.SS2.usage)} channels ")
#     
#     for rx in hydra._dtp.rxs:
#         print(rx.sts.SS1.usage)
    
    

#     
#     for s in hydra._dtp.serdes:
#         print(s)
#         print(s.occupancy)
    
#     for asic in set.union(hydra._dtp.system_manager.setOfRxTx, hydra._dtp.system_manager.setOfSwitches):
#         print(asic,asic.id)
    
    # Route one sub-channel
#     hydra.create_channel(1, 2, 1, 2)
#     hydra.create_channel(1, 2, 1, 2)
#     hydra.create_channel(15, 3842, 15, 3842)

    # Route 100 sub-channels from input file
#     hydra.createMultipleChannels(fromFile=True, fillLevel=None)
    
    # Route to specific capacity level (as %)
#     hydra.createMultipleChannels(fromFile=False, fillLevel=20)
    
    
    
#     for rx in hydra._dtp.rxs:
#         print(len(rx.sts.SS1.usage))
#         break
#     for sw in hydra._dtp.system_manager.setOfSwitches:
#         print(len(sw.sts.SS1.usage))
#         break

#     for rx in hydra._dtp.rxs:
#         print(rx,rx.id)
#     for tx in hydra._dtp.txs:
#         print(tx,tx.id)    
#     for sw in hydra._dtp.sws:
#         print(sw,sw.id)
#     for sw in hydra._dtp.sws:
#         print(sw,len(sw.availableTrialCo))

#     for rx in hydra._dtp.rxs:
#         print(rx)
#         try:
#             print(max(list(rx.sts.SS1.usage.keys()), key=lambda item: item[0]))
#         except:
#             pass
# #         print(len(rx.sts.SS1.usage))
#         print(rx.sts.SS1.usage)        
#         print(rx.sts.TS.usage)        
#         print(rx.sts.SS2.usage)
#     for sw in hydra._dtp.sws:
#         print(sw)
# #         print(max(list(sw.sts.SS1.usage.keys()), key=lambda item: item[0]))
# #         print(len(sw.sts.SS1.usage))
#         print(len(sw.sts.SS1.usage))
#         print(sw.sts.TS.usage)
#         print(sw.sts.SS2.usage)
#     for tx in hydra._dtp.txs:
#         print('tx')
# #         print(max(list(tx.sts.SS1.usage.keys()), key=lambda item: item[0]))   
# #         print(len(tx.sts.SS1.usage)) 
#         print(tx.sts.SS1.usage)
#         print(tx.sts.TS.usage)
#         print(tx.sts.SS2.usage)


# Coding the system, PEP8 refactoring, implementing new config file reader, minor tweaks to api




