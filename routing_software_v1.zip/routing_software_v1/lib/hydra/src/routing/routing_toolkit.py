"""-----------------------------------------------
 Functions common to routing in any Stage
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

def route_sts_lcee(bfn_block, in_coord, out_coord):
    
    """
    Routing through an STS switch (inside a BFN engine).
    Routes from iss input to oss output.
    Uses 'Least Congested End-to-End' method. 
    
    @param bfn_block: the home of the STS in question
    @param in_coord: (TDM,TS) at the input of the ISS
    @param out_coord: (TDM,TS) at the output of the OSS
    
    """
    
    # Assign parameters for the switches relating to the BFN block.
    iss = bfn_block.iss # Input Spatial Switch
    ts = bfn_block.ts # Time Switch
    oss = bfn_block.oss # Output Spatial Switch
    
    
    # Get a set of available TDMs on the ISS and OSS using an
    # and intersection of sets (as all values inside the
    # available_tdms list are unique.
    # NOTE: The output spatial switch behaves slightly differently,
    # ISS: available_tdms[<timeslot>] = potential output TDMs from
    # the given input TDM.
    # OSS: available_tdms[<timeslot>] = potential input TDMs from 
    # the given output TDM.
    potential_tdms = set(iss.available_tdms[in_coord[1]]).intersection(oss.available_tdms[out_coord[1]])
    
    # If None is present in the set, remove it. Doesn't raise an
    # exception if None is not present.
    potential_tdms.discard(None)
    
    # Must also discard in case of tdm_offset
    if ts.tdm_offset:
        for tdm in range(ts.tdm_offset):
            potential_tdms.discard(tdm)
    
    
    tdm_ranking = {}
    
    # Further assess the potential TDMs
    for TDM in potential_tdms:
        # For each TDM, check if the input timeslot needed is empty,
        # and check if the output timeslot needed is available.
        if (ts.occupancy[TDM][in_coord[1]] == [] and 
            ts.available_ts[TDM][out_coord[1]] == out_coord[1]):
            
            tdm_ranking[TDM] = 0
            
            # Rank TDMs as we go in terms of LCEE
            # From the request input TDM, how many slots are routed
            # to the current <TDM>?

            for in_slot,iss_out_tdm in enumerate(iss.occupancy[in_coord[0]]):
                
                if TDM not in iss_out_tdm:
                    
                    continue
                
                else:
                    
                    for out_slot in ts.occupancy[TDM][in_slot]:
                        
                        if out_coord[0] not in oss.occupancy[TDM][out_slot]:
                            
                            continue
                        
                        else:
                            
                            tdm_ranking[TDM] += 1
                    
         
    
    try:
        lcee_tdm = min(tdm_ranking, key=tdm_ranking.get)    
    except:
        return False
    
    # TEMP TESTING
    # SET ISS
    iss.occupancy[in_coord[0]][in_coord[1]].append(lcee_tdm)
    # Remove from available
    iss.available_tdms[in_coord[1]][lcee_tdm] = None
    
    # SET TS
    ts.occupancy[lcee_tdm][in_coord[1]].append(out_coord[1])
    # Remove from available
    ts.available_ts[lcee_tdm][out_coord[1]] = None
    
    # SET OSS
    oss.occupancy[lcee_tdm][out_coord[1]].append(out_coord[0])
    # Remove from available
    oss.available_tdms[out_coord[1]][lcee_tdm] = None
    

    return lcee_tdm
    


def route_sts_fafs(bfn_block, in_coord, out_coord):
    
    """
    Routing through an STS switch (inside a BFN engine).
    Routes from iss input to oss output.
    Selects TDM on a first-available, first-served basis.
    
    @param bfn_block: the home of the STS in question
    @param in_coord: (TDM,TS) at the input of the ISS
    @param out_coord: (TDM,TS) at the output of the OSS
    
    """
    
    # Assign parameters for the switches relating to the BFN block.
    iss = bfn_block.iss # Input Spatial Switch
    ts = bfn_block.ts # Time Switch
    oss = bfn_block.oss # Output Spatial Switch
    

    
   
    # Get a set of available TDMs on the ISS and OSS using an
    # and intersection of sets (as all values inside the
    # available_tdms list are unique.
    # NOTE: The output spatial switch behaves slightly differently,
    # ISS: available_tdms[<timeslot>] = potential output TDMs from
    # the given input TDM.
    # OSS: available_tdms[<timeslot>] = potential input TDMs from 
    # the given output TDM.
    potential_tdms = set(iss.available_tdms[in_coord[1]]).intersection(oss.available_tdms[out_coord[1]])
    
    # If None is present in the set, remove it. Doesn't raise an
    # exception if None is not present.
    potential_tdms.discard(None)
    
    # Discard anything higher than the amount of timeswitches
    for tdm in range(ts.no_of_timeswitches, iss.tdms_in):
        potential_tdms.discard(tdm)
    
    # Must also discard in case of tdm_offset
    if ts.tdm_offset:
        for tdm in range(ts.tdm_offset):
            potential_tdms.discard(tdm)

    
    # Further assess the potential TDMs
    for TDM in potential_tdms:
        # For each TDM, check if the input timeslot needed is empty,
        # and check if the output timeslot needed is available.
        if (ts.occupancy[TDM][in_coord[1]] == [] and 
            ts.available_ts[TDM][out_coord[1]] == out_coord[1]):
            

            # SET ISS
            iss.occupancy[in_coord[0]][in_coord[1]].append(TDM)
            # Remove from available
            iss.available_tdms[in_coord[1]][TDM] = None
            
            # SET TS
            ts.occupancy[TDM][in_coord[1]].append(out_coord[1])
            # Remove from available
            ts.available_ts[TDM][out_coord[1]] = None
            
            # SET OSS
            oss.occupancy[TDM][out_coord[1]].append(out_coord[0])
            # Remove from available
            oss.available_tdms[out_coord[1]][TDM] = None
            

            
            return TDM

    return False

            
            