"""-----------------------------------------------
 Class and functions for Stage 1 of RA
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging
import random
from operator import itemgetter
# import time
# import sys

# from lib.hydra.src.system.asic import Rx, RxBFN, Sw, TxBFN, Tx
from lib.hydra.src.system.path.Path import SERDES_Path, STS_Path
from lib.hydra.src.routing.routing_toolkit import *
# from lib.dcm.src.DCM import DCM
from lib.hydra.src.system.Constants import (POL_TO_BFN, ENG_TO_FREQ_ID, 
                                            POL_TO_CONV)


class StageOne(object):

    def __init__(self, hydra_logger, rxs, rxbfns, serdes, asic_serdes_lut, 
                 freq_to_bfn_lut):
     
        """
        Constructor
        
        DESC

        
        @param hydra_logger: 
        @param rxs: 
        @param rxbfns: 
        @param serdes: 
        @param asic_serdes_LUT:
        @param freq_to_bfn:
        """
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
            
        # Assign ASIC sets for each mode
        self.rxs = rxs
        self.rxbfns = rxbfns

    
        # Assign ASIC SERDES LUT
        # Used for speed and convenience of finding the connections
        # between any two given asics.
        self.asic_serdes_lut = asic_serdes_lut
        
        # Assign frequency to bfn LUT
        self.freq_to_bfn_lut = freq_to_bfn_lut        
        
        if self.freq_to_bfn_lut:
            self._build_pre_allocated_routes()
            stage_status = True#self._validate_routes()
            
        if stage_status:
            if self.logger:
                self.logger.info("STAGE 1 routes have been pre-allocated and all checks passed.")
        else:
            if self.logger:
                self.logger.error("STAGE 1 routes validation failed.")
            raise Exception("STAGE 1 routes validation failed.")

    def _get_eng_id(self, freq_id):
        
        try:
            return next((e,f) for (e,f) in ENG_TO_FREQ_ID.items() if freq_id in f)[0]
        
        except StopIteration:
            raise Exception(f"No engine assigned to frequency ID: {freq_id}")
        
    def _get_frequency_value(self, bfn_block, eng_id, freq_id):

        try:
            return next(f for f in bfn_block.bfns[eng_id].frequency if f['id']==freq_id)
                    
        except StopIteration:
            return None
        
    def _get_sorted_adcs(self, adcs):
        
        # Filter the full list of adcs on the ASIC to only the
        # relevant ones for that BFN block. BFN block 0 contains
        # pol A ("HORIZ"), BFN block 1 contains pol B ("VERT").
        
        # Initialise sorted adc list for each BFN block
        adc_list = [[],[]]
        
        for adc in adcs:
            
            if adc.antenna_element.pol == 'HORIZ':
                
                adc_list[0].append(adc)
            
            elif adc.antenna_element.pol == 'VERT':
                
                adc_list[1].append(adc)
        
        # Want a list with 4 entries, with <None> for the non 
        # existent ADCs.
        for adc_subset in adc_list:
            
            while len(adc_subset) != 4:

                adc_subset.append(None)
                
        return adc_list
    
    def _get_channeliser_slot(self, freq, adc):
        
        # Return a TDM,TS coord for a given frequency on some ADC.
        # If the ADC is not present, return None (i.e. no route to 
        # be preallocated from the Rx).
        
        if freq and adc:
            
            # Get the sub-channel number from the frequency
            SC = adc.get_sc_number(freq)
            
            # Use the SC number to get the TDM,TS.
            coord = adc.channeliser.get_slot(SC)
            
            return coord
            
        elif not freq or not adc:
            return None
                
    def _build_pre_allocated_routes(self):
                
        # Only assessing BFN(0) since BFN(1) handles the 
        # same frequencies, just a different polarisation.
        # Each time, assess BFN(0), and each engine.
        # Identify if that engine has a frequency_1 assigned
        # from the f2b yaml file. If it does, assign that as
        # the first frequency in the order, and increment up
        # the number of frequencies. Use the first four 
        # timeslots for this on <iss.output>
        # <iss.input> must be set to the first TDM on the 
        # first serdes connecting the RxBFN to the Rx,
        
        if self.logger:
            self.logger.info("Building Stage 1 routes...")
            
        # Loop through each Rx BFN ASIC.
        for rxbfn in self.rxbfns:
            
            # Create a frequency order list for staggering per BFN ASIC
            # (one for each TDM wrt SERDES).
            tdm0_stagger = [i for i in range(0,64)]
            tdm1_stagger = [i for i in range(64,128)]
            
            if self.logger:
                self.logger.debug(f"Pre-allocating with {rxbfn.name}")
            
            # Loop through each Rx ASIC
            for rx in self.rxs:
                
                # Check if User RX before proceeding
                if 'MOB' not in rx.mode:
                    continue

                
                # Identify SERDES between the two ASICs
                serdes_list = self.asic_serdes_lut[rx.name][rxbfn.name]
                
                # Sort ADCs for current RX ASIC
                adcs_sorted = self._get_sorted_adcs(rx.adcs)
                
                # Loop through each bfn block
                for bfn_block in rxbfn.bfn_blocks:
                    
                    # Initialise frequency counter
                    f_counter = 0
                    # Initialise timeslot counter
                    ts_counter = 0
                    
                    # Choose the right SERDES for each BFN ASIC-half
                    # SERDES0 for BFN(0), SERDES1 for BFN(1)
                    # (in the context of the serdes between the two 
                    # asics).
                    bfn_index = rxbfn.bfn_blocks.index(bfn_block)
                    
                    # Assign current SERDES
                    sd = serdes_list[bfn_index]
                    
                    # Choose adcs for current BFN block
                    adc_list = adcs_sorted[bfn_index]
                    
                    # Loop through the max frequencies on each 
                    # SERDES.
                    # This number is the data precision of the SERDES
                    # divided by the maximum antenna elements per Rx 
                    # per polarisation (4, fixed)
                    max_freqs_per_sd = sd.size//4
                    for _ in range(max_freqs_per_sd):
                        
                        # Create route from SERDES to Rx BFN engine.
                        # This is done for all frequencies, even if 
                        # not in the freq allocation (becasue we are 
                        # planning for all of the freqs).
                        
                        # --------v-SERDES TDM SELECTION-v--------- #
                        
                        # For the first (64) frequencies, choose TDM0
                        # on that SERDES
                        if f_counter == 0:
                            # Get info for TDM0 (source and sink)
                            sd_src_tdm = sd.source.operating_tdm[0]
                            sd_sink_tdm = sd.sink.operating_tdm[0]
                        
                            sd_occ = serdes_list[bfn_index].occupancy[0]
                            
                            stagger = tdm0_stagger

                        # For the 65th frequency (first on new TDM),
                        # choose TDM1 on that SERDES
                        if f_counter == max_freqs_per_sd:
                            
                            sd_src_tdm = sd.source.operating_tdm[1]
                            sd_sink_tdm = sd.sink.operating_tdm[1]
                            
                            sd_occ = sd.occupancy[1]
                            
                            stagger = tdm1_stagger
                            
                            # Also reset frequency and timeslot counter, 
                            # because new serdes TDM after 64th freq
                            ts_counter = 0
                            f_counter = 0
                            
                        # For the rest of the frequencies,
                        # choose TDM1 on that SERDES  
                        if f_counter == (max_freqs_per_sd+1):
                            # Get info for TDM1 (rest of freq)
                            sd_sink_tdm = sd.sink.operating_tdm[1]
                            sd_src_tdm = sd.source.operating_tdm[1]
                            
                            sd_occ = serdes_list[bfn_index].occupancy[1]
                        
                        # --------^-SERDES TDM SELECTION-^--------- #
                        

                        # -----------v-SLOT ASSIGNMENT-v----------- #
                        
                        # Identify the frequency ID being assigned
                        freq_id = stagger[f_counter]
                        
                        # Identify the BFN engine ID that handles
                        # the frequency ID being allocated. 
                        eng_id = self._get_eng_id(freq_id)
                        
                        # Identify frequency using frequency ID
                        freq = self._get_frequency_value(bfn_block, eng_id, freq_id)
                        

                        # Loop 4 times for 1st freq.
                        # 1 slot per antenna element, therefore max 4
                        # per polarisation.
                        for elem_i in range(4):
                            # -------------v-RX ASIC-v------------- #
                            # If frequency is assigned, return a
                            # coordinate (TDM,TS) on the RX ISS input
                            in_coord = self._get_channeliser_slot(freq['value'], adc_list[elem_i])
                            
                            # Get the output coordinate (TDM,TS) to 
                            # route to relevant SERDES.
                            out_coord = (sd_src_tdm, ts_counter)
                            
                            # If the frequency exists, create a route
                            # through the RX ASIC STS, from <in_coord>
                            # to <out_coord>. Uses least congested 
                            # end-to-end algorithm.
                            if in_coord:
                                
                                success = route_sts_fafs(rx.bfn_blocks[0], in_coord, out_coord)
                                
                                # Remember which antenna elements relate
                                # to which timeslots.
                                freq['slots'][adc_list[elem_i].antenna_element.id] = ts_counter
                                
                                if type(success) != int:
                                    raise Exception("***FAILED TO CREATE ROUTE***")

                            # -------------^-RX ASIC-^------------- #
                            
                                # ------------v-SERDES-v--------------- #
                                # The value being assigned <freq_id>,
                                # has no significance, it is just for
                                # tracking here.
                                sd_occ[ts_counter] = freq_id
                                # ------------^-SERDES-^--------------- #
                                
                                # -------v-RX BFN ISS (+ RAMs)-v------- #
                                # Route spatial switch from TDM <sd_sink_tdm>
                                # to TDM <eng_id>
                                bfn_block.iss.occupancy[sd_sink_tdm][ts_counter].append(eng_id)
                                
                                # The ISS maps directly to the storage on
                                # the BFN engine.
                                # Each of the active RAMs recieve all the
                                # slots, and we append <"READY"> to 
                                # to signify they are ready to be used in
                                # the beamformer.
                                for ram_i in range(bfn_block.bfns[eng_id].rams.no_of_timeswitches):
                                    bfn_block.bfns[eng_id].rams.occupancy[ram_i][ts_counter].append(freq_id)
                            # -------^-RX BFN ISS (+ RAMs)-^------- #

                            
                            # Incrememnt the timeslot counter
                            ts_counter += 1
                        
                            
                        # After frequency assigned, move onto the next.
                        f_counter += 1

                        # Identify the frequency ID being assigned
                        freq_id = stagger[f_counter]
                        
                        # Identify the BFN engine ID that handles
                        # the frequency ID being allocated. 
                        eng_id = self._get_eng_id(freq_id)
                        
                        # Identify frequency using frequency ID
                        freq = self._get_frequency_value(bfn_block, eng_id, freq_id)

                        # Repeat for 2nd freq.
                        for elem_i in range(4):
                            # ----------v-RX ASIC OSS-v------------ #                           

                            in_coord = self._get_channeliser_slot(freq['value'], adc_list[elem_i])
                            out_coord = (sd_src_tdm, ts_counter)
                            
                            if in_coord:
                                success = route_sts_fafs(rx.bfn_blocks[0], in_coord, out_coord)
                                
                                # Remember which antenna elements relate
                                # to which timeslots.
                                freq['slots'][adc_list[elem_i].antenna_element.id] = ts_counter
       
                                if type(success) != int:
                                    

                                    
                                    raise Exception("***FAILED TO CREATE ROUTE***")
                            # ----------^-RX ASIC OSS-^------------ #
                            
                                # ------------v-SERDES-v--------------- #
                                # The value being assigned <freq_id>,
                                # has no significance, it is just for
                                # tracking here.
                                sd_occ[ts_counter] = freq_id
                                # ------------^-SERDES-^--------------- #
                                
                                # -------v-RX BFN ISS (+ RAMs)-v------- #
                                # Route spatial switch from TDM <sd_sink_tdm>
                                # to TDM <eng_id>
                                bfn_block.iss.occupancy[sd_sink_tdm][ts_counter].append(eng_id)
                                
                                # The ISS maps directly to the storage on
                                # the BFN engine.
                                # Each of the active RAMs recieve all the
                                # slots, and we append <"READY"> to 
                                # to signify they are ready to be used in
                                # the beamformer.
                                for ram_i in range(bfn_block.bfns[eng_id].rams.no_of_timeswitches):
                                    bfn_block.bfns[eng_id].rams.occupancy[ram_i][ts_counter].append(freq_id)
                                # -------^-RX BFN ISS (+ RAMs)-^------- #
                            
                            # Incrememnt the timeslot counter
                            ts_counter += 1
                            
                            
                        # Incrememnt frequency counter
                        f_counter += 1

                # Move stagger pattern along for the next RX ASIC.
                tdm0_stagger.append(tdm0_stagger.pop(0))
                tdm1_stagger.append(tdm1_stagger.pop(0))
                
    def _get_iss_output(self, iss, start_coord):
            
        return iss.occupancy[start_coord[0]][start_coord[1]]
    
    def _assess_rx_route(self, bfn_block, iss_out_tdm, start_ts):
        
        # TS
        # Identify output timeslot
        ts_out_slot = bfn_block.ts.occupancy[iss_out_tdm][start_ts][0]
        
        # OSS
        # Identify output TDM
        oss_out_tdm = bfn_block.oss.occupancy[iss_out_tdm][ts_out_slot][0]
        
        return oss_out_tdm, ts_out_slot
    
    def _assess_serdes_route(self, rx, oss_out_tdm, ts_out_slot, freq_id, destination_info):

        # Convert TDM to port ID
        src_port_id = int(oss_out_tdm/2)
        # Get port object
        src_port = rx.out_ports[src_port_id]
        # Get SERDES object
        sd = src_port.serdes
        
        # Choose correct TDM on the SERDES (0 or 1)
        sd_tdm_id = oss_out_tdm % 2
        sd_tdm = sd.occupancy[sd_tdm_id]
        
        serdes_object_check = []
        # Check each possible destination
        for dest in destination_info:
            dest_asic = dest[0]

            # Check the SERDES object
            if sd in self.asic_serdes_lut[rx.name][dest_asic.name]:
                serdes_object_check.append(True)
                break
            else:
                serdes_object_check.append(False)
            
        # Check the SERDES slot
        if sd_tdm[ts_out_slot] == freq_id:
            serdes_slot_check = True
        else:
            serdes_slot_check = False
        
        # Get port object
        sink_port = sd.sink
        # Get arriving TDM
        rxbfn_iss_in_tdm = sink_port.operating_tdm[sd_tdm_id]
        
        # TODO: RX BFN ISS CHECK -------------------------
        rxbfn = sink_port.asic
        
        return rxbfn, rxbfn_iss_in_tdm, serdes_object_check, serdes_slot_check
    
    def _assess_rxbfn_route(self, rxbfn, iss_in_tdm, ts_slot, pol, freq_id, destination_info):
        
        # Check arrival at correct RX BFN ASIC
        # Check each possible destination
        rxbfn_object_check = []
        for dest in destination_info:
            dest_asic = dest[0]
            dest_eng = dest[2]
            
            if rxbfn is dest_asic:
                rxbfn_object_check.append(True)
            else:
                rxbfn_object_check.append(False)
        
        block_id = next(k for k,v in POL_TO_BFN.items() if v == pol)
        bfn_block = rxbfn.bfn_blocks[block_id]
        
        # Identify output TDM
        iss_out_tdm = bfn_block.iss.occupancy[iss_in_tdm][ts_slot][0]

        # Check arrival at correct Rx BFN Engine
        arrival_engine = bfn_block.bfns[iss_out_tdm]
        
        engine_object_check = []
        for dest in destination_info:
            dest_eng = dest[2]
            
            if arrival_engine is dest_eng:
                engine_object_check.append(True)
            else:
                engine_object_check.append(False)
        
        # Rx BFN ENG RAM CHECK
        engine_ram_check = []
        for ram_i in range(arrival_engine.rams.no_of_timeswitches):
#                             print(arrival_engine.rams.occupancy[ram_i])
            if arrival_engine.rams.occupancy[ram_i][ts_slot][0] == freq_id:
                engine_ram_check.append(True)
            else:
                engine_ram_check.append(False)
                
        return rxbfn_object_check, engine_object_check, engine_ram_check
            
    def _validate_routes(self):
        
        # Loop through frequency allocation, and ensure there is an
        # existing route for each frequency to the correct engine.
        for frequency,destination_info in self.freq_to_bfn_lut.items():
            
            # Assign frequency value
            freq = frequency[0]
            
            # Check that frequency is assigned. Go to next if not.
            if not freq:
                continue
            
            # Assign frequency polarisation
            pol = frequency[1]
            
            # Since <destination_info> is a set with any BFN ASICs
            # assigned to the chosen freq, can choose any dest to 
            # identify the <freq_id> as it is the same frequency.
            dest_eng = next(d for d in destination_info)[2]          
            
            # Assuming one engine for now
            freq_id = next(f['id'] for f in dest_eng.frequency if f['value'] == freq)
            
#             sys.stdout.write(f"{freq_id, freq, pol, dest_asic.name, dest_engine.name}\n")
            
            # 
            adc_id_range = POL_TO_CONV[pol]
#             print(freq, pol)
            # Go through each Rx ASIC for the given frequency.
            for rx in self.rxs:
                
                # Check if User RX before proceeding
                if 'MOB' not in rx.mode:
                    continue
                
#                 print(rx.name)
                for adc in rx.adcs:
                    
                    if adc.id in adc_id_range:
#                         print(freq)
                        # Get starting coordinate from frequency
                        start_coord = self._get_channeliser_slot(freq, adc)
#                         print(start_coord)

                        # In case of multicast route (where there is 
                        # more than one BFN engine assigned to the 
                        # same frequency), there are multiple output
                        # TDMs from the input spatial switch. Hence
                        # each of these routes must be validated.
                        iss_tdm_list = self._get_iss_output(rx.bfn_blocks[0].iss, start_coord)
                        
                        # Go through each output TDM of the ISS, and
                        # assess each part of the route to the BFN.
                        for iss_tdm in iss_tdm_list:
                            
                            # Assess Rx STS route
                            oss_tdm,ts_slot = self._assess_rx_route(rx.bfn_blocks[0], iss_tdm, start_coord[1])
                            
                            # Assess SERDES route
                            (rxbfn,iss_tdm,
                             serdes_object_check, 
                             serdes_slot_check) = self._assess_serdes_route(rx, oss_tdm, ts_slot, freq_id, destination_info)
                            
                            # Assess RxBFN ISS route
                            (rxbfn_object_check, 
                             engine_object_check, 
                             engine_ram_check) = self._assess_rxbfn_route(rxbfn, iss_tdm, ts_slot, pol, freq_id, destination_info)
                        
                        # If any errors along the route, print check info
                        if (not serdes_slot_check or 
                            True not in serdes_object_check or 
                            True not in rxbfn_object_check or 
                            True not in engine_object_check or 
                            False in engine_ram_check):
                            
                            if self.logger:
                                self.logger.error("*** CHECKS ***\n")
                                self.logger.error(f"serdes_slot_check: {serdes_slot_check}\n")
                                self.logger.error(f"serdes_object_check: {serdes_object_check}\n")
                                self.logger.error(f"rxbfn_object_check: {rxbfn_object_check}\n")
                                self.logger.error(f"engine_object_check: {engine_object_check}\n")
                                self.logger.error(f"engine_ram_check: {engine_ram_check}\n")
                            
                            # If any checks fail
                            return False

        # If all checks pass
        return True
    
    def _check_rxbfn_capacity(self, rxbfn):
        
        """
        TODO
        
        """
        # Pick a random BFN Block (either 0 or 1)
        bfn_block_choices = random.sample(rxbfn.bfn_blocks, len(rxbfn.bfn_blocks))
        # Start checking each block
        for bfn_block in bfn_block_choices:
            # Pick a random TDM to check
            tdm_choices = random.sample([i for i in range(bfn_block.ts.no_of_timeswitches)], bfn_block.ts.no_of_timeswitches)
            for TDM in tdm_choices:
                for slot in range(bfn_block.ts.slots):
                    if (bfn_block.ts.occupancy[TDM][slot] == [] and 
                        bfn_block.ts.available_ts[TDM][slot] == slot):
                        # Return the bfn_block for routing.
                        return bfn_block
                    # if not empty
                    else:
                        # Check next slot
                        continue
                # All slots checked, check the next TDM
                continue
            # All TDMs checked, check the next bfn_block
            continue
        # No space on this ASIC, must checked next.
        return False
    
    def _get_serdes_congestion(self, asic_a, asic_b):
        
        """
        TODO:
        
        """
        
        # Identify serdes between two ASICs.
        serdes_list = self.asic_serdes_lut[asic_a.name][asic_b.name]
        
        # Initialise  list for checks    
        serdes_checks = list()
        
        # For each one, identify the least congested TDM
        for s in serdes_list:
            
            # Return info on both TDMs within SERDES.
            s_occ = s.get_occupancy()
            
            serdes_checks.append((s, 0, s_occ[0]))
            serdes_checks.append((s, 1, s_occ[1]))              
        
        # Return the list
        return serdes_checks
    
    def _get_rx_serdes_slot_fafs(self, serdes_organised):
        
        """
        TODO:
         
        """
        
        # First sort the list by lowest congestion level.
        serdes_sorted = sorted(serdes_organised, key=itemgetter(2))
        
        # Need to pick a slot that is free both on the SERDES and
        # on the timeswitch within the engine.
        
        # If there isn't one on the current serdes, go to next least
        # congested.
        for s_info in serdes_sorted:
            
            # Reference serdes object
            s_obj = s_info[0]
            # Reference serdes internal tdm (0 or 1)
            s_tdm = s_info[1]
            
            # Check through slots, get first available
            for slot in range(s_obj.size):
                
                if s_obj.occupancy[s_tdm][slot] == None:
                    
                    return s_obj, s_tdm, slot
        
        else:
            raise Exception("NO VALID SLOT FOUND")
        
    def create_gw_route(self, sub_channel, uplink_frequency, uplink_gw, gain, target_page):
        
        """
        TODO
        
        """
        
        # First need to identify where this sub-channel lands on
        # the Rx ASIC.
        
        # Identify the Rx ASIC
        rx = uplink_gw.asic
        # Identify the adc connected to the element
        adc = uplink_gw.conv
        # Get the channeliser slot
        rx_iss_in_coord = self._get_channeliser_slot(uplink_frequency, adc)
        
        # Now need to choose an Rx BFN ASIC and SERDES to be used.
        # Shuffle the rxbfns and continue.
        rxbfn_choices = random.sample(self.rxbfns, len(self.rxbfns))
        
        # Looping through as a backup in case some not free.
        for rxbfn in rxbfn_choices:
            # Now we must guarantee a valid route exists on this 
            # rxbfn.
            bfn_block = self._check_rxbfn_capacity(rxbfn)
            
            # If no space, check the next ASIC
            if bfn_block == False:
                # Go to next rxbfn
                continue
            # We found a valid Rx BFN ASIC and BFN Block.
            else:
                # Exit the loop
                break

        # Now must choose SERDES and slot.
        # Organise serdes in terms of congestion
        serdes_organised = self._get_serdes_congestion(rx, rxbfn)
        # Pick and serdes based on first available first served.
        serdes, serdes_tdm, serdes_slot = self._get_rx_serdes_slot_fafs(serdes_organised)
        # Identify the TDM this relates to on the Rx OSS
        oss_out_tdm = serdes.source.operating_tdm[serdes_tdm]
        
        # Setup Rx in and out coords
        in_coord = rx_iss_in_coord
        out_coord = (oss_out_tdm, serdes_slot)
        
        # Route Rx ASIC
        success_tdm = route_sts_fafs(rx.bfn_blocks[0], in_coord, out_coord)
        
        if type(success_tdm) != int:
            raise Exception("Failed to create route through Rx ASIC STS.")
        else:
            # ISS slots selected
            iss_route = {'in_tdm' : in_coord[0],
                         'slot'   : in_coord[1],
                         'out_tdm': success_tdm}
            # TS slots selected
            ts_route = {'in_slot' : in_coord[1],
                        'tdm'     : success_tdm,
                        'out_slot': out_coord[1]}
            # OSS slots selected
            oss_route = {'in_tdm' : success_tdm,
                         'slot'   : out_coord[1],
                         'out_tdm': out_coord[0]}
            
            # Create the STS_Path object for this sub-channel
            rx_path = STS_Path(self.logger, rx, rx.bfn_blocks[0], iss_route, ts_route, oss_route)
            # Add the path to the sub-channel
            sub_channel.add_path(rx_path, 0)
        
        # Route SERDES (Rx-RxBFN)
        serdes.occupancy[serdes_tdm][serdes_slot] = uplink_frequency
        # Create the SERDES_Path object for this sub-channel
        serdes_path_rx = SERDES_Path(self.logger, serdes, serdes_tdm, serdes_slot)
        # Add the path to the sub-channel
        sub_channel.add_path(serdes_path_rx, 1)
        
        # Process coordinates to pass to stage 3.
        rxbfn_iss_in_tdm = serdes.sink.operating_tdm[serdes_tdm]
        rxbfn_iss_in_coord = (rxbfn_iss_in_tdm, serdes_slot)
        


        # Return the information to continue routing
        return (rxbfn, bfn_block, rxbfn_iss_in_coord)
        
    def allocate_new_eng(self, freq, pol):
        
        """
        TODO
        
        """
        # TEMPORARILY REMOVED DUE TO BUG FIXING. 
        
        