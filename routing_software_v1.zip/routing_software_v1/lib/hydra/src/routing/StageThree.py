"""-----------------------------------------------
 Class and functions for Stage 3 of RA
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging
import math
import random
from operator import itemgetter

# from lib.hydra.src.system.asic import Rx, RxBFN, Sw, TxBFN, Tx
from lib.hydra.src.system.subchannel.SubChannel import SubChannel
from lib.hydra.src.system.path.Path import BFN_Path, SERDES_Path, STS_Path
from lib.hydra.src.system.sample.Sample import Sample
from lib.hydra.src.routing.routing_toolkit import *
# from lib.dcm.src.DCM import DCM
# from lib.hydra.src.system.Constants import ()


class StageThree(object):

    def __init__(self, hydra_logger, rxbfns, sws, txbfns, serdes, asic_serdes_lut,
                 freq_to_rxbfn_lut, freq_to_txbfn_lut):
     
        """
        Constructor
        
        DESC

        
        @param hydra_logger: 
        @param rbfns: 
        @param sws:
        @param txbfns: 
        @param serdes: 
        @param asic_serdes_LUT:
        """
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
            
        # Reference ASIC sets for each mode
#         self.rxs = rxs
        self.rxbfns = rxbfns
        self.sws = sws
        self.txbfns = txbfns
#         self.txs = txs

        # Reference LUTs
        self.freq_to_rxbfn_lut = freq_to_rxbfn_lut
        self.freq_to_txbfn_lut = freq_to_txbfn_lut
        self.asic_serdes_lut = asic_serdes_lut
        
    def _check_tx_engine_timeswitch(self, tx_eng, elems_in_beam):
         
        """
        TODO:
         
        """
        
        # Number of slots needed per branch of the Tx engine
        amount_of_slots = math.ceil(elems_in_beam/tx_eng.bfn_state)
        
        # Initialise list
        slots_fafs = list()
        
        # Need to find the first <amount_of_slots> slots available.
        for slot in range(tx_eng.ts.slots):
            
            # Is the <slot> free?
            if tx_eng.ts.available_ts[0][slot] == slot:
                # If yes, append to first available list.
                slots_fafs.append(slot)
            else:
                # If not, to next slot
                continue
            
            # If we have found enough slots for the current request,
            # return those slots
            if len(slots_fafs) == amount_of_slots:
                return slots_fafs
            else:
                continue
            
        # If end of for loop reached, not enough slots free, must
        # go to next engine.
        return False
        
    def _check_tx_engine_ram(self, tx_eng, freq, beamweights):
         
        """
        TODO:
         
        """
        
        # Check the available space on the RAMs for the required
        # beam. If there is enough space, return and continue routing
        # with the most congested timeslot first. If at least one
        # timeslot has no options, return and assign a new TX engine.
        
        # Identify slots for this frequency on the output of the RAM.
        # This is a direct mapping with the OSS for the Tx side.
        ram_slots = next(f['slots'] for f in tx_eng.frequency if f['value'] == freq)


        # Initialise checking dict
        eng_ram_check = dict()
        
        # Loop through each element in the beam
        for element in beamweights:
            # Identify relevant timeslot for the element
            ram_out_slot = ram_slots[element.id]
            
            # Initialise counter for this specific slot
            eng_ram_check[element] = 0

            # Now check each RAM, how many have this slot available?
            for ram_i in range(tx_eng.bfn_state):
                

                # If it is available
                if tx_eng.rams.available_ts[ram_i][ram_out_slot] == ram_out_slot:
                    # Increment counter for this slot
                    eng_ram_check[element] += 1
                    
        
        # Now if one of these entries is 0, not enough space.
        if 0 in eng_ram_check.values():
            # This engine doesn't have enough space. 
            # Check another.
            return False
        # Otherwise, continue routing with this Tx info
        else:
            
            num_elems = len(beamweights)
            # One more check to be made, if there is no space on the 
            # output of the timeswitch, must also find new engine.
            tx_eng_timeswitch_check = self._check_tx_engine_timeswitch(tx_eng, num_elems)
            
            # Return again if false returned.
            if tx_eng_timeswitch_check == False:
                return False
            
            # Otherwise, return the RAM info + timeswitch info.
            # Convert to a list
            eng_ram_check_list = [(ram_slots[element.id], element, beamweights[element], availability) for element,availability in eng_ram_check.items()]
            # Sort the list by the least available RAMs.
            tx_eng_ram_check = sorted(eng_ram_check_list, key=itemgetter(3))
            return tx_eng_ram_check, tx_eng_timeswitch_check
        
    def _check_rx_engine_timeswitch(self, engine, elems_in_beam):
         
        """
        TODO:
         
        """
        
        # Check the space needed per branch for this freq
        # Need to round up because 0 assigned for non 
        # multiples of number of active branches.
        # Active branches hardcoded to 8 for v1.
        amount_of_slots = math.ceil(elems_in_beam/engine.bfn_state)
     
        # Report the max available space of the engine per
        # branch. 'Max' because must be consecutive slots.
        for slot in range(engine.ts.slots):
            
            # Loop consecutive slots, starting from <slot>
            for i in range(amount_of_slots):
                
                # Check to ensure that timeslot in allowable range
                if slot+i == engine.ts.slots:
                    self.logger.warning(f"UNABLE TO FIND {amount_of_slots} FREE CONSECUTIVE SLOTS on BFN engine {engine.name}")
                    # This engine doesn't have enough space. 
                    # Check another.
                    return False
                
                # If the slot is empty and we aren't at the final
                # slot, go to the next i
                if (engine.ts.occupancy[0][slot+i] == [] and 
                    i < amount_of_slots - 1):
                    # Goes to next i value
                    continue
                # If the slot+i isn't empty, break to next slot
                elif engine.ts.occupancy[0][slot+i] != []:
                    # Goes to next slot value
                    break
                # If we reach here, we are at the final slot,
                # and all consecutive slots before are free
                else:
                    # Return first slot, final slot
                    # Continue routing
                    return slot, slot+i
             

    def _process_uplink(self, freq, pol, beamweights):
        
        """
        TODO:
        
        """
        # Reference to number of elements
        num_elements = len(beamweights)
        
        # First identify which engines handle this frequency.
        allocation_set = self.freq_to_rxbfn_lut[(freq,pol)]
        
        for alloc in allocation_set:
            
            # This entry is the engine handling the frequency
            eng = alloc[2]
            
            # Check space on the Rx engine
            check_result = self._check_rx_engine_timeswitch(eng, num_elements)
            
            if type(check_result) == tuple:
                # Use this engine, continue routing
                return alloc, check_result
            else:
                # Check next engine
                continue
        
        # If by the end of checks, still False, need to assign new
        # Engine
        if check_result == False:
            return 'rxbfn'
            
    def _process_downlink(self, freq, pol, beamweights):
        
        """
        TODO:
        
        """
        
        # First identify which engines handle this frequency.
        allocation_set = self.freq_to_txbfn_lut[(freq,pol)]
        
        for alloc in allocation_set:
            
            # This entry is the engine handling the frequency
            eng = alloc[2]
            
            # Check space on the Tx engine
            check_result = self._check_tx_engine_ram(eng, freq, beamweights)
            
            if type(check_result) == tuple:
                # Use this engine, continue routing
                return alloc, check_result
            else:
                # Check next engine
                continue
        
        # If by the end of checks, still False, need to assign new
        # Engine
        if check_result == False:
            return 'txbfn'
            

    def _get_tx_serdes_slot_fafs(self, serdes_organised, tx_eng_ts_slot):
        
        """
        TODO:
         
        """
        
        # First sort the list by lowest congestion level.
        serdes_sorted = sorted(serdes_organised, key=itemgetter(2))
        
        # Need to pick a slot that is free both on the SERDES and
        # on the timeswitch within the engine.
        
        # If there isn't one on the current serdes, go to next least
        # congested.
        for s_info in serdes_sorted:
            
            # Reference serdes object
            s_obj = s_info[0]
            # Reference serdes internal tdm (0 or 1)
            s_tdm = s_info[1]

            # If the slot requried is free on the serdes, use it.
            if s_obj.occupancy[s_tdm][tx_eng_ts_slot] == None:
                
                return s_obj, s_tdm
            else:
                continue
        
        else:
            raise Exception("NO VALID SLOT FOUND")
        
    def _get_rx_serdes_slot_fafs(self, serdes_organised, bfn_ts):
        
        """
        TODO:
         
        """
        
        # First sort the list by lowest congestion level.
        serdes_sorted = sorted(serdes_organised, key=itemgetter(2))
        
        # Need to pick a slot that is free both on the SERDES and
        # on the timeswitch .
        
        # If there isn't one on the current serdes, go to next least
        # congested.
        for s_info in serdes_sorted:
            
            # Reference serdes object
            s_obj = s_info[0]
            # Reference serdes internal tdm (0 or 1)
            s_tdm = s_info[1]
            
            # Check through slots, get first available
            for slot in range(s_obj.size):
                
                if (s_obj.occupancy[s_tdm][slot] == None and 
                    bfn_ts.available_ts[0][slot] == slot):
                    
                    return s_obj, s_tdm, slot
        
        else:
            raise Exception("NO VALID SLOT FOUND")
        
        

    def _get_serdes_congestion(self, asic_a, asic_b):
        
        """
        TODO:
        
        """
        
        # Identify serdes between two ASICs.
        # Either RxBFN-Sw or Sw-TxBFN.
        serdes_list = self.asic_serdes_lut[asic_a.name][asic_b.name]
        
        # Initialise  list for checks    
        serdes_checks = list()
        
        # For each one, identify the least congested TDM
        for s in serdes_list:
            
            # Return info on both TDMs within SERDES.
            s_occ = s.get_occupancy()
            
            serdes_checks.append((s, 0, s_occ[0]))
            serdes_checks.append((s, 1, s_occ[1]))              
        
        # Return the list
        return serdes_checks
    
    def _user_rxbfn_to_sw(self, rx_info, sw_asic, sub_channel, uplink_freq, uplink_beamweights):
        
        """
        TODO:
        
        """
        
        # Which Rx BFN ASIC?
        rxbfn = rx_info[0][0]
        # Which Rx BFN block?
        rx_bfn_block = rx_info[0][1]
        # Which Rx BFN engine?
        rx_eng = rx_info[0][2]
        
        # Which RAM slots were found?
        ram_out_slot = rx_info[1][0]
        ram_out_slot_final = rx_info[1][1]
        
        # Organise SERDES (related to congestion)
        # Pick from these later.
        serdes_organised = self._get_serdes_congestion(rxbfn, sw_asic)

        # Create Rx BFN path object for this sub-channel
        rxbfn_path = BFN_Path(self.logger, rxbfn, rx_bfn_block, rx_eng)
        # Add the path to the sub-channel
        sub_channel.add_path(rxbfn_path, 2)
        
        # Identify slots for this frequency on the input of the RAM.
        # This is a direct mapping with the ISS for the Rx side.
        ram_slots = next(f['slots'] for f in rx_eng.frequency if f['value'] == uplink_freq)
        
        # Pick the next available timeslot which satisfies 
        # both free space on engine timeswitch and SERDES
        serdes, serdes_tdm, serdes_slot = self._get_rx_serdes_slot_fafs(serdes_organised, rx_eng.ts)
        # Identify the TDM this relates to on the OSS
        oss_out_tdm = serdes.source.operating_tdm[serdes_tdm]
        
        # Create the SERDES_Path object for this sub-channel
        serdes_path_rx = SERDES_Path(self.logger, serdes, serdes_tdm, serdes_slot)
        # Add the path to the sub-channel
        sub_channel.add_path(serdes_path_rx, 3)
        
        # Initialise ram counter
        ram_i = 0
        # Now we need to route each sample in turn.
        for element,beamweight in uplink_beamweights.items():
            
            # Reset ram counter if used all active branches.
            # Also increment timeslot with each reset.
            if ram_i == rx_eng.bfn_state:
                # Reset to ram 0
                ram_i = 0
                # Increment the ram output time slot
                ram_out_slot += 1
            
            ram_in_slot = ram_slots[element.id]
            rx_eng.rams.occupancy[ram_i][ram_in_slot].append(ram_out_slot)
            
            if ram_out_slot != ram_out_slot_final:
                # 'Reserve' the invalid output slots from MACC process
                ts_out_slot = -1
                rx_eng.ts.occupancy[0][ram_out_slot].append(ts_out_slot)
            else:
                ts_out_slot = serdes_slot
                
            # Create a Sample object for this route
            # First setup info dicts
            # RAM path
            ram_route = {'ram_id'  : ram_i,
                         'in_slot' : ram_in_slot,
                         'out_slot': ram_out_slot}
            # Timeswitch path
            ts_route = {'in_slot' : ram_out_slot,
                        'out_slot': ts_out_slot}
                     
            # Now create the object
            rx_sample = Sample(self.logger, rx_eng, element, beamweight, ram_route, ts_route)
            # Append this to the BFN Path object
            rxbfn_path.add_sample(rx_sample)
            
            # Increment ram counter
            ram_i += 1
        
        # After all samples routed, we now have one beamformed
        # sub-channel. We can continue routing.
        
        # Route the rx engine timswitch
        rx_eng.ts.occupancy[0][ram_out_slot_final].append(serdes_slot)
        # ENSURE WE REMOVE THIS SLOT FROM THE AVAILABLE LIST
        rx_eng.ts.available_ts[0][serdes_slot] = None
        
        # Route the rx bfn output spatial switch
        rx_bfn_block.oss.occupancy[rx_eng.id][serdes_slot].append(oss_out_tdm)
        # ENSURE WE REMOVE THIS SLOT FROM THE AVAILABLE LIST
        rx_bfn_block.oss.available_tdms[serdes_slot][rx_eng.id] = None
        # Also need to add this to the RxBFN path
        # OSS slots selected
        oss_route = {'in_tdm' : rx_eng.id,
                     'slot'   : serdes_slot,
                     'out_tdm': oss_out_tdm}
        rxbfn_path.ss_route = oss_route
        
        
        # Route the SERDES
        serdes.occupancy[serdes_tdm][serdes_slot] = uplink_freq
        
        # So arrival coordinates at the Sw ASIC are
        in_tdm = serdes.sink.operating_tdm[serdes_tdm]
        in_slot = serdes_slot
        
        return (in_tdm, in_slot)
    
    def _user_txbfn_to_sw(self, tx_info, sw_asic, sub_channel, downlink_freq):
        
        """
        TODO:
        
        """
        
        # Which Tx BFN ASIC?
        txbfn = tx_info[0][0]
        # Which Tx BFN block?
        tx_bfn_block = tx_info[0][1]
        # Which Tx BFN engine?
        tx_eng = tx_info[0][2]
        
        # Setup BFN Path object for this sub-channel
        txbfn_path = BFN_Path(self.logger, txbfn, tx_bfn_block, tx_eng)
        # Add the path to the sub-channel
        sub_channel.add_path(txbfn_path, 6)
        
        # We must also check the slots on the RAMs.
        # This is different to the RX side. For each sample, we must
        # confirm that there is a possible output on the correct
        # antenna element for the requested beam. This is done during
        # downlink processing stage.
        
        # What is the optimal order to perform the Tx BFN routing?
        # This is a list of (timeslot, free RAMs, +info). We must route
        # the slots starting with the one with least RAM options.
        ram_slot_priority = tx_info[1][0]
        
        # These are the timeswitch slots to be used. 
        # In this case this is for the multicast.
        ts_out_slots = tx_info[1][1]
        
        # We must also choose the timeswitch input side slot.
        ts_in_slot = next(slot for slot in range(tx_eng.ts.slots) if 
                          tx_eng.ts.occupancy[0][slot] == [])
        
        # Make a list to pick RAM IDs and timeslots from.
        ram_id_choices = {ram_id:list(ts_out_slots) for ram_id in range(tx_eng.bfn_state)}
#         # Number of slots needed per branch of the Tx engine
#         amount_of_slots = math.ceil(len(downlink_beamweights)/tx_eng.bfn_state)
#         ram_id_choices = [ram_id for ram_id in range(tx_eng.bfn_state) for _ in range(amount_of_slots)]

        # Now go through each entry in the priority list.
        for slot_info in ram_slot_priority:
            
            ram_out_slot = slot_info[0]
            element = slot_info[1]
            beamweight = slot_info[2]
            
            # Check each RAM for space
            for ram_id,in_slots in ram_id_choices.items():
                # If the current RAM has been used up, go to next
                if in_slots == []:
                    # Go to next ram_id and in_slots
                    continue
#                 print(ram_id_choices)
                ram_in_slot = int(in_slots[0])
                # If the desired input is free and the desired output
                # is available, choose this ram.
                if (tx_eng.rams.occupancy[ram_id][ram_in_slot] == [] and
                    tx_eng.rams.available_ts[ram_id][ram_out_slot] == ram_out_slot):
                    # Route the sample.
                    tx_eng.rams.occupancy[ram_id][ram_in_slot].append(ram_out_slot)
                    # Remove from available
                    tx_eng.rams.available_ts[ram_id][ram_out_slot] = None
                    
                    # Remove the slot from the out_slots 
                    in_slots.pop(0)
                    
                    # Exit the RAM choice loop once sample routed.
                    break
             
            # PROCESS THE SAMPLE
            # Create a Sample object for this route
            # First setup info dicts
            # Timeswitch path
            ts_route = {'in_slot' : ts_in_slot,
                        'out_slot': ram_in_slot}
            # RAM path
            ram_route = {'ram_id'  : ram_id,
                         'in_slot' : ram_in_slot,
                         'out_slot': ram_out_slot}
                     
            # Now create the object
            tx_sample = Sample(self.logger, tx_eng, element, beamweight, ram_route, ts_route)
            # Append this to the BFN Path object
            txbfn_path.add_sample(tx_sample)
             
        # Sample was created above, but easier to just multicast 
        # as follows in one go.
        for ts_out_slot in ts_out_slots:
            # Multicast to output of timeswitch
            tx_eng.ts.occupancy[0][ts_in_slot].append(ts_out_slot)
            # REMOVE THEM FROM AVAILABLE
            tx_eng.ts.available_ts[0][ts_out_slot] = None
        
        # We know the timeslot on the SERDES, just need to select
        # a SERDES. 
        # NOTE: same Sw ASIC as before of course, as we want all of 
        # a channel in one Sw ASIC.
        # Organise SERDES (related to congestion)
        serdes_slot = ts_in_slot
        serdes_organised = self._get_serdes_congestion(sw_asic, txbfn)
        serdes, serdes_tdm = self._get_tx_serdes_slot_fafs(serdes_organised, serdes_slot)
        # Identify the TDM this relates to on the ISS
        iss_in_tdm = serdes.sink.operating_tdm[serdes_tdm]
        
        # Route the tx bfn input spatial switch
        tx_bfn_block.iss.occupancy[iss_in_tdm][serdes_slot].append(tx_eng.id)
        # ENSURE WE REMOVE THIS SLOT FROM THE AVAILABLE LIST
        tx_bfn_block.iss.available_tdms[serdes_slot][tx_eng.id] = None
        # Also need to add this to the TxBFN path
        # ISS slots selected
        iss_route = {'in_tdm' : iss_in_tdm,
                     'slot'   : serdes_slot,
                     'out_tdm': tx_eng.id}
        txbfn_path.ss_route = iss_route
        
        # Create the SERDES_Path object for this sub-channel
        serdes_path_tx = SERDES_Path(self.logger, serdes, serdes_tdm, serdes_slot)
        # Add the path to the sub-channel
        sub_channel.add_path(serdes_path_tx, 5)
        
        # Route the SERDES
        serdes.occupancy[serdes_tdm][serdes_slot] = downlink_freq
        
        # So destination coordinates for the Sw ASIC are
        out_tdm = serdes.source.operating_tdm[serdes_tdm]
        out_slot = serdes_slot
        
        return (out_tdm, out_slot)
    
    def _gw_rxbfn_to_sw(self, sub_channel, uplink_freq, rxbfn, rxbfn_block, rxbfn_coord, sw_asic):
        
        """
        TODO:
        
        """
        
        # Get the SERDES congestion levels
        serdes_organised = self._get_serdes_congestion(rxbfn, sw_asic)
        # Pick the next available timeslot which satisfies 
        # both free space on engine timeswitch and SERDES
        serdes, serdes_tdm, serdes_slot = self._get_rx_serdes_slot_fafs(serdes_organised, rxbfn_block.ts)
        
        # Identify the TDM this relates to on the Rx BFN OSS
        oss_out_tdm = serdes.source.operating_tdm[serdes_tdm]
        
        # Create the SERDES_Path object for this sub-channel
        serdes_path_rx = SERDES_Path(self.logger, serdes, serdes_tdm, serdes_slot)
        # Add the path to the sub-channel
        sub_channel.add_path(serdes_path_rx, 3)
        
        # Process coords for RxBFN BFN Block
        in_coord = rxbfn_coord
        out_coord = (oss_out_tdm, serdes_slot)
        
        # Now we can route across the RxBFN STS
        success_tdm = route_sts_fafs(rxbfn_block, in_coord, out_coord)
        
        if type(success_tdm) != int:
            raise Exception("Failed to create route through Sw ASIC")
        else:
            # ISS slots selected
            iss_route = {'in_tdm' : in_coord[0],
                         'slot'   : in_coord[1],
                         'out_tdm': success_tdm}
            # TS slots selected
            ts_route = {'in_slot' : in_coord[1],
                        'tdm'     : success_tdm,
                        'out_slot': out_coord[1]}
            # OSS slots selected
            oss_route = {'in_tdm' : success_tdm,
                         'slot'   : out_coord[1],
                         'out_tdm': out_coord[0]}
            
            # Create the STS_Path object for this sub-channel
            rxbfn_path = STS_Path(self.logger, rxbfn, rxbfn_block, iss_route, ts_route, oss_route)
            # Add the path to the sub-channel
            sub_channel.add_path(rxbfn_path, 2)
            
        # Route the SERDES
        serdes.occupancy[serdes_tdm][serdes_slot] = uplink_freq
        
        # Get the coordinates on the Sw ASIC, input of ISS.
        in_tdm = serdes.sink.operating_tdm[serdes_tdm]
        in_slot = serdes_slot
        
#         print(uplink_freq)
#         print(rxbfn.name) 
#         print(in_coord, out_coord, success_tdm)
#         print(serdes, serdes_tdm, serdes_slot)
        
        return (in_tdm, in_slot)
    
    def _gw_txbfn_to_sw(self, sub_channel, downlink_freq, txbfn, txbfn_block, txbfn_coord, sw_asic):
        
        """
        TODO:
        
        """
        
        # Get the SERDES congestion levels
        serdes_organised = self._get_serdes_congestion(sw_asic, txbfn)
        # Pick the next available timeslot which satisfies 
        # both free space on engine timeswitch and SERDES
        # NOTE:  The function is the same as the Rx. This is because
        # the tx_serdes slot finds a special case for Tx beamforming.
        serdes, serdes_tdm, serdes_slot = self._get_rx_serdes_slot_fafs(serdes_organised, txbfn_block.ts)
        
        # Identify the TDM this relates to on the Tx BFN ISS
        iss_in_tdm = serdes.sink.operating_tdm[serdes_tdm]
        
        # Create the SERDES_Path object for this sub-channel
        serdes_path_tx = SERDES_Path(self.logger, serdes, serdes_tdm, serdes_slot)
        # Add the path to the sub-channel
        sub_channel.add_path(serdes_path_tx, 5)
        
        # Process coords for TxBFN BFN Block
        in_coord = (iss_in_tdm, serdes_slot)
        out_coord = txbfn_coord
        
        # Now we can route across the TxBFN STS
        success_tdm = route_sts_fafs(txbfn_block, in_coord, out_coord)
        
        if type(success_tdm) != int:
            raise Exception("Failed to create route through Sw ASIC")
        else:
            # ISS slots selected
            iss_route = {'in_tdm' : in_coord[0],
                         'slot'   : in_coord[1],
                         'out_tdm': success_tdm}
            # TS slots selected
            ts_route = {'in_slot' : in_coord[1],
                        'tdm'     : success_tdm,
                        'out_slot': out_coord[1]}
            # OSS slots selected
            oss_route = {'in_tdm' : success_tdm,
                         'slot'   : out_coord[1],
                         'out_tdm': out_coord[0]}
            
            # Create the STS_Path object for this sub-channel
            txbfn_path = STS_Path(self.logger, txbfn, txbfn_block, iss_route, ts_route, oss_route)
            # Add the path to the sub-channel
            sub_channel.add_path(txbfn_path, 6)
            
        # Route the SERDES
        serdes.occupancy[serdes_tdm][serdes_slot] = downlink_freq
        
        # Get the coordinates on the Sw ASIC, input of ISS.
        in_tdm = serdes.sink.operating_tdm[serdes_tdm]
        in_slot = serdes_slot
        
#         print(downlink_freq)
#         print(txbfn.name) 
#         print(in_coord, out_coord, success_tdm)
#         print(serdes, serdes_tdm, serdes_slot)
        
        return (in_tdm, in_slot)
        
    
    def _route_sw(self, sw_asic, sub_channel, in_coord, out_coord):
        
        """
        TODO:
        
        """
        # Randomly choose which BFN Block to be used on Sw
        # NOTE: this might need to change
        bfn_block_id = random.randrange(2)
        sw_bfn_block = sw_asic.bfn_blocks[bfn_block_id]
        
        success_tdm = route_sts_fafs(sw_bfn_block, in_coord, out_coord)
        
        if type(success_tdm) != int:
            raise Exception("Failed to create route through Sw ASIC")
        else:
            # ISS slots selected
            iss_route = {'in_tdm' : in_coord[0],
                         'slot'   : in_coord[1],
                         'out_tdm': success_tdm}
            # TS slots selected
            ts_route = {'in_slot' : in_coord[1],
                        'tdm'     : success_tdm,
                        'out_slot': out_coord[1]}
            # OSS slots selected
            oss_route = {'in_tdm' : success_tdm,
                         'slot'   : out_coord[1],
                         'out_tdm': out_coord[0]}
            
            # Create the STS_Path object for this sub-channel
            sw_path = STS_Path(self.logger, sw_asic, sw_bfn_block, iss_route, ts_route, oss_route)
            # Add the path to the sub-channel
            sub_channel.add_path(sw_path, 4)
            
        
    def create_user_route(self, sub_channel_id, sw_asic,
                                uplink_freq, uplink_pol, uplink_beamweights, 
                                downlink_freq, downlink_pol, downlink_beamweights, 
                                gain, target_page):
        
        """
        TODO:
        
        """

        # Process the uplink (i.e. check for engine space)
        rx_engine_result = self._process_uplink(uplink_freq, uplink_pol, uplink_beamweights)
        # Process the downlink (i.e. check for engine space)
        tx_engine_result = self._process_downlink(downlink_freq, downlink_pol, downlink_beamweights)
        
        # Return the engine check results if they are strings only.
        if type(rx_engine_result) == str and type(tx_engine_result) == str:
            return [rx_engine_result, tx_engine_result]
        
        elif type(rx_engine_result) == str:
            return [rx_engine_result]
        
        elif type(tx_engine_result) == str:
            return [tx_engine_result]
        
        # Continue routing if they are not strings.
        # Initialise new sub-channel object
        sub_channel = SubChannel(self.logger, sub_channel_id, uplink_freq, downlink_freq)
        
        # Rx -------------------------------------
        # Create route from RxBFN to Sw ASIC. 
        # Including beamforming operations.
        sw_in_coord = self._user_rxbfn_to_sw(rx_engine_result, sw_asic, sub_channel,
                                              uplink_freq, uplink_beamweights)
        
        
        # Tx ------------------------------------
        # Create route from TxBFN to Sw ASIC. 
        # Including beamforming operations.
        sw_out_coord = self._user_txbfn_to_sw(tx_engine_result, sw_asic, sub_channel,
                                               downlink_freq)

        
        # Sw ------------------------------------
        # Taking the arrival coordinates from the Rx beamforming and
        # destination coordinates from the Tx beamforming, we can now
        # route across the sts switch in the Sw ASIC.
        self._route_sw(sw_asic, sub_channel, sw_in_coord, sw_out_coord)
        
        # Return the fully routed sub-channel
        return sub_channel
        
    def create_gw_route(self, sub_channel, 
                              uplink_freq, downlink_freq,
                              rxbfn, rxbfn_block, rxbfn_coord,
                              sw_asic,
                              txbfn, txbfn_block, txbfn_coord, 
                              gain, target_page):
        
        """
        TODO:
        
        """
        
        # We have all the ASICs needed, RxBFN,Sw,TxBFN.
        # We have the input to the input spatial switch on the Rx BFN.
        # We have the output to the output spatial switch on the TxBFN.
        # NEED: Select a SERDES + SERDES slot on each side.
        #       Route the STS switches in all three ASICs.
        
        # Route Rx BFN - Sw (up to arrival at Sw )
        sw_in_coord = self._gw_rxbfn_to_sw(sub_channel, uplink_freq, rxbfn, rxbfn_block, rxbfn_coord, sw_asic)
        
        # Route Tx BFN - Sw (up to arrival at Sw)
        sw_out_coord = self._gw_txbfn_to_sw(sub_channel, downlink_freq, txbfn, txbfn_block, txbfn_coord, sw_asic)
        
        # Route Sw
        # Taking arrival coords from RxBFN and destination coords from 
        # TxBFN, route throgh the Sw ASIC
        self._route_sw(sw_asic, sub_channel, sw_in_coord, sw_out_coord)
        
        return sub_channel
        
        
    def create_rtn_route(self, sub_channel, sw_asic,
                               uplink_freq, uplink_pol, uplink_beamweights, 
                               downlink_freq,
                               txbfn, txbfn_block, txbfn_coord,
                               gain, target_page):
        
        """
        TODO:
        
        """
        
        # Process the uplink (i.e. check for engine space)
        rx_engine_result = self._process_uplink(uplink_freq, uplink_pol, uplink_beamweights)
        
        # Return the engine check results if they are strings only.
        if type(rx_engine_result) == str:
            return [rx_engine_result]
        
        # Rx -------------------------------------
        # Create route from RxBFN to Sw ASIC. 
        # Including beamforming operations.
        sw_in_coord = self._user_rxbfn_to_sw(rx_engine_result, sw_asic, sub_channel,
                                              uplink_freq, uplink_beamweights)
        
        # Tx -------------------------------------
        # Route Tx BFN - Sw (up to arrival at Sw)
        sw_out_coord = self._gw_txbfn_to_sw(sub_channel, downlink_freq, txbfn, txbfn_block, txbfn_coord, sw_asic)
        
        # Sw ------------------------------------
        # Taking the arrival coordinates from the Rx beamforming and
        # destination coordinates from the Tx beamforming, we can now
        # route across the sts switch in the Sw ASIC.
        self._route_sw(sw_asic, sub_channel, sw_in_coord, sw_out_coord)
        
        return sub_channel

    def create_fwd_route(self, sub_channel, sw_asic,
                               rxbfn, rxbfn_block, rxbfn_coord,
                               uplink_freq,
                               downlink_freq, downlink_pol, downlink_bws, 
                               gain, target_page):
        
        """
        TODO:
        
        """
        # Process the downlink (i.e. check for engine space)
        tx_engine_result = self._process_downlink(downlink_freq, downlink_pol, downlink_bws)
        
        # Return the engine check results if they are strings only.
        if type(tx_engine_result) == str:
            return [tx_engine_result]
        
        # Rx -------------------------------------
        # Route Rx BFN - Sw (up to arrival at Sw)
        sw_in_coord = self._gw_rxbfn_to_sw(sub_channel, uplink_freq, rxbfn, rxbfn_block, rxbfn_coord, sw_asic)
        
        # Tx -------------------------------------
        # Create route from TxBFN to Sw ASIC. 
        # Including beamforming operations.
        sw_out_coord = self._user_txbfn_to_sw(tx_engine_result, sw_asic, sub_channel, downlink_freq)
        
        
        # Sw ------------------------------------
        # Taking the arrival coordinates from the Rx gw route and
        # destination coordinates from the Tx beamforming route, we 
        # can now route across the sts switch in the Sw ASIC.
        self._route_sw(sw_asic, sub_channel, sw_in_coord, sw_out_coord)
        
        return sub_channel

