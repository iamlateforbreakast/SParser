"""-----------------------------------------------
 Class and functions for the ROUTING ALGORITHM
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging
import math

# from lib.hydra.src.system.asic import Rx, RxBFN, Sw, TxBFN, Tx
from lib.hydra.src.system.channel.Channel import Channel
from lib.hydra.src.system.subchannel.SubChannel import SubChannel
# from lib.hydra.src.system.path.Path import Path
# from lib.hydra.src.system.sample.Sample import Sample
from lib.hydra.src.routing.StageOne import StageOne
from lib.hydra.src.routing.StageTwo import StageTwo
from lib.hydra.src.routing.StageThree import StageThree
from lib.hydra.src.routing.routing_toolkit import *
# from lib.dcm.src.DCM import DCM
from lib.hydra.src.system.Constants import (POL_TO_BFN, ENG_TO_FREQ_ID, 
                                            ASIC_PAGES)


class Routing(object):

    def __init__(self, hydra_logger, dtp, operator, use_dcm):
     
        """
        Constructor
        
        Responsible for initialising the algo, and managing each stage
        Takes the DTP System and Operator Settings as arguments. 
        This constructor performs some post-processing on the DTP 
        System model, such as removing unused ports on the ASICs, 
        generating a LUT for identifying the serdes between any two 
        ASICs (in adjacent ranks), and assigning the frequency to BFN 
        engine allocation.
        
        @param hydra_logger: hydra logger instance passed down,
        @param dtp: Model of the DTP system, loaded by config file
        @param operator: Operator settings passed down, contains
            beams, and store channel objects there.
        @param use_dcm: parameter for non-DCM testing.
        
        """
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
        
        # Using master asic dict from DTPSystem,
        
        
        # Assign ASIC sets for each rank
        self.rxs = dtp.rxs
        self.rxbfns = dtp.rxbfns
        self.sws = dtp.sws
        self.txbfns = dtp.txbfns
        self.txs = dtp.txs
        
        # Assign serdes 
        self.serdes = dtp.serdes
        
        # Assign operator
        self.operator = operator
        
        # [QOL] Filter active in and out ports for each asic rank
        self._remove_unused_ports(self.rxs)
        self._remove_unused_ports(self.rxbfns)
        self._remove_unused_ports(self.sws)
        self._remove_unused_ports(self.txbfns)
        self._remove_unused_ports(self.txs)
        
        # [QOL] Process the frequency to BFN engine allocation as defined 
        # by the config file. The file has been loaded in by the 
        # Operator class. Creates a LUT for freq-to-bfn info whilst
        #  assigning relevant params to the engine objects
        if operator.freq2bfn and self.rxbfns:
            self.freq_to_rxbfn_lut = self._process_frequency_allocation(operator.freq2bfn, self.rxbfns, 'rxbfn')
        else:
            self.logger.warning("No frequency-to-BFN LUT (RX) loaded.")
            self.freq_to_rxbfn_lut = None
            
        if operator.freq2bfn and self.txbfns:
            self.freq_to_txbfn_lut = self._process_frequency_allocation(operator.freq2bfn, self.txbfns, 'txbfn')
        else:
            self.logger.warning("No frequency-to-BFN LUT (TX) loaded.")
            self.freq_to_txbfn_lut = None
        
        # [QOL] ASICPAIR-TO-SERDES LUT
        self.asic_serdes_lut = self._get_asic_serdes_lut()
                
        # Stage 1
        self.stage_one = StageOne(self.logger, self.rxs, self.rxbfns,
                                  self.serdes, self.asic_serdes_lut,
                                  self.freq_to_rxbfn_lut)        
        # Stage 2
        self.stage_two = StageTwo(self.logger, self.txs, self.txbfns,
                                  self.serdes, self.asic_serdes_lut,
                                  self.freq_to_txbfn_lut)        
        # Stage 3
        self.stage_three = StageThree(self.logger, 
                                      self.rxbfns, self.sws, self.txbfns,
                                      self.serdes, self.asic_serdes_lut,
                                      self.freq_to_rxbfn_lut, self.freq_to_txbfn_lut)

    def _remove_unused_ports(self, asic_set):
        
        """
        Go through each asic in specified list, find the ports
        with no SERDES connections and remove them.
        
        """
        
        if asic_set:
        
            for asic in asic_set:
                out_ports_to_remove = []
                in_ports_to_remove = []
                  
                # Find the unused
                for out_port_num, out_port in asic.out_ports.items():
                    if not out_port.serdes:
                        out_ports_to_remove.append(out_port_num)
                          
                for in_port_num, in_port in asic.in_ports.items():
                    if not in_port.serdes:
                        in_ports_to_remove.append(in_port_num)
                  
                # Remove the unused
                if out_ports_to_remove:
                    for p in out_ports_to_remove:
                        asic.out_ports.pop(p)
                          
                if in_ports_to_remove:
                    for p in in_ports_to_remove:
                        asic.in_ports.pop(p)
        
        else:
            pass
                        
    def _get_asic_serdes_lut(self):
        
        """
        Generate a lookup table for the given system.
        Input two ASICs, return a set of SERDES connecting the two.
        
        asic_serdes_lut['ASIC1']['ASIC2'] -> list(sd0,sd1,sd2...)
        
        """
        
        asic_serdes_lut = {}
        for s in self.serdes:
  
            if s.source.asic.name in asic_serdes_lut:
                  
                if s.sink.asic.name in asic_serdes_lut[s.source.asic.name]:
                    asic_serdes_lut[s.source.asic.name][s.sink.asic.name].append(s)
                  
                else:
                    asic_serdes_lut[s.source.asic.name].update({s.sink.asic.name:[s]})
                      
            else:
                asic_serdes_lut[s.source.asic.name] = {s.sink.asic.name:[s]}
        
        return asic_serdes_lut
                    
    def _process_frequency_allocation(self, freq_to_bfn, bfn_set, bfn_type):
        
        """
        Takes the frequency allocation yaml dict, and a bfn set and
        assigns relevant params to each engine. Lays groundwork
        for the stagger pattern by assigning frequency IDs and slot
        relationship to each bfn engine. Details of this are found 
        in "asic.internals", namely "_freq_id_to_slot_lut" and
        "_eng_to_freq_id_lut".
        
        Also,returns organised LUT for use by all stages:
        freq_to_bfn_LUT[(freq,pol)] = (bfn_asic, set(engs) )
        
        """
        
        # Initialise LUT
        freq_to_bfn_LUT = dict()
        
        # Go through each asic in the freq_to_bfn allocation yaml.
        for allocation in freq_to_bfn:
            
            # Only assign RxBFNs for Stage 1, TxBFNs for Stage 2.
            if bfn_type in allocation['node']:
                # Find relevant BFN ASIC object
                bfn_asic = next(asic for asic in bfn_set 
                                if allocation['node'] == asic.name)
                
                # Loop through each engine in allocation
                for engine in allocation['engines']:
                    
                    # Assign params
                    eng_id = engine['id']
                    f1 = engine['frequency_1']
                    f2 = engine['frequency_2']
                    
                    # Loop through each of the 2 blocks in the BFN ASIC
                    for bfn_block in bfn_asic.bfn_blocks:
                        
                        # Find the correct BFN engine on the ASIC.
                        bfn_eng = next(eng for eng in bfn_block.bfns if eng.id == eng_id)
                        # Assign 1st freq
                        bfn_eng.frequency[0]['id'] = ENG_TO_FREQ_ID[eng_id][0]
                        bfn_eng.frequency[0]['value'] = f1
#                         bfn_eng.frequency[0]['slots'] = FREQ_ID_TO_SLOT[bfn_eng.frequency[0]['id']]
                        # Assign 2nd freq
                        bfn_eng.frequency[1]['id'] = ENG_TO_FREQ_ID[eng_id][1]
                        bfn_eng.frequency[1]['value'] = f2
#                         bfn_eng.frequency[1]['slots'] = FREQ_ID_TO_SLOT[bfn_eng.frequency[1]['id']]
                        
                        # Also assign polarisation i.e., 
                        # BFN(0) handles pol A, 
                        # BFN(1) handles pol B.
                        POL = POL_TO_BFN[bfn_asic.bfn_blocks.index(bfn_block)]
                    
                        # Add to LUT
                        # If this f1,POL is not already assigned, assign it
                        if (f1,POL) not in freq_to_bfn_LUT:
                            freq_to_bfn_LUT[(f1,POL)] = {(bfn_asic, bfn_block, bfn_eng)}
                        
                        # If it is already assigned, append to existing
                        else:
                            freq_to_bfn_LUT[(f1,POL)].add((bfn_asic, bfn_block, bfn_eng))
                            
                        # If this f2,POL is not already assigned, assign it
                        if (f2,POL) not in freq_to_bfn_LUT:
                            freq_to_bfn_LUT[(f2,POL)] = {(bfn_asic, bfn_block, bfn_eng)}
                            
                        # If it is already assigned, append to existing
                        else:
                            freq_to_bfn_LUT[(f2,POL)].add((bfn_asic, bfn_block, bfn_eng))
                            
                    
                        # Lastly for the engine, relate elements to slots.
#                         bfn_eng.assign_elements_to_slots()
                
        return freq_to_bfn_LUT
    
#     def _check_engines(self, alloc_set, elems_in_beam):
#         
#         """
#         TODO:
#         
#         """
#     
#         # Check for multiple engines assigned to the frequency.
#         for alloc in alloc_set:
#             
#             # This entry is the engine handling the frequency
#             eng = alloc[2]
#         
#             # Report the available space of the engine per
#             # branch.
#             eng_space = eng.get_available_space()
#             
#             # Check the space needed per branch for this freq
#             # Need to round up because 0 assigned for non 
#             # multiples of number of active branches.
#             # Active branches hardcoded to 8 for v1.
#             space_needed = math.ceil(elems_in_beam/eng.bfn_state)
#             
#             # (per branch) Check if enough space.
#             if eng_space >= space_needed:
#                 
#                 # Assign this engine as the selected for the 
#                 # current request
#                 eng.is_selected = True
#                 
#                 # Return from this frequency, go to next
#                 return True
#             
#             eng.is_selected = False
#         
#         # If this part of the loop is reached, it means
#         # there is no available engine, so a new one 
#         # must be assigned.
#         return False
    
    def _get_asic_available_space(self, asic):
        
        """
        TODO:
         
        """   
        
        # Initialise counter
        asic_occupancy = 0
        
        # Go through each bfn block
        for bfn_block in asic.bfn_blocks:
            # Count the space on the timeswitch
            for TDM in range(bfn_block.ts.no_of_timeswitches):
                for TS in range(bfn_block.ts.slots):
                    # If timeslot not empty, increment
                    if bfn_block.ts.occupancy[TDM][TS] != []:
                        asic_occupancy += 1
        
        asic_max_occupancy = TDM * TS
        
        # Return the difference
        return asic_max_occupancy - asic_occupancy
    
    def _get_sw_lc(self, channel_width):    
        
        """
        TODO:
         
        """
        
        # Initialise dict for keeping track of all occupancies
        switch_occ_tracker = dict()
         
        # Go through each Sw
        for sw in self.sws:
             
            # Get the free space of the switch asic
            switch_space = self._get_asic_available_space(sw)
            
            # Does this have enough space for the channel?
            # (divide by two to get sub-channels).
            if switch_space < channel_width//2:
                # Don't add to tracker, go back to top of loop.
                continue
            
            # Add to tracking dict
            switch_occ_tracker[switch_space] = sw
        
        try:
            # Return the switch object with lowest occupancy
            return switch_occ_tracker[min(switch_occ_tracker)]
        except:
            raise Exception("UNABLE TO GET LEAST CONGESTED SWITCH")

    def _process_request(self, uplink, downlink):
        
        """
        This function takes the requested link objects and breaks 
        down the key parameters.
        If it is a BEAM, then the engines for each of the frequencies
        must be checked for available capacity. If any are found to 
        have inadequate capacity, STAGE 1/2 must be used to allocate a
        new engine.
        If it is a GATEWAY, then STAGE 1/2 must be triggered to happen
        as normal.
        
        Call the relevant STAGE 3 commands after processing.
        
        """
        
        # Determine the type of traffic from the uplink and downlink.
        if hasattr(uplink, 'beam') and hasattr(downlink, 'beam'):
            
            traffic_type = 'user'
            self.logger.debug(f"Routing method: create_user_channel()")
            return getattr(self, 'create_user_channel'), traffic_type

        elif hasattr(uplink, 'beam') and hasattr(downlink, 'gateway'):
            
            traffic_type = 'rtn'
            self.logger.debug(f"Routing method: create_rtn_channel()")
            return getattr(self, 'create_rtn_channel'), traffic_type
            
        elif hasattr(uplink, 'gateway') and hasattr(downlink, 'beam'):
            
            traffic_type = 'fwd'
            self.logger.debug(f"Routing method: create_fwd_channel()")
            return getattr(self, 'create_fwd_channel'), traffic_type
            
        elif hasattr(uplink, 'gateway') and hasattr(downlink, 'gateway'):
            
            traffic_type = 'gw'
            self.logger.debug(f"Routing method: create_gw_channel()")
            return getattr(self, 'create_gw_channel'), traffic_type

    def create_user_channel(self, channel_id, uplink, downlink, gain, target_page, traffic_type):
        
        """
        TODO:
        
        """
        
        # Initialise new channel object
        chan = Channel(self.logger, channel_id, uplink, downlink, gain, traffic_type)
        
        # Initialise sub-channel counter
        sc_i = 0
        
        # Polarisation of requested uplink
        up_pol = uplink.beam.pol
        # Polarisation of requested downlink
        down_pol = downlink.beam.pol
        
        # Make a copy of the frequency list
        uplink_freqs = list(uplink.freq_list)
        downlink_freqs = list(downlink.freq_list)

        # Width of the channel
        channel_width = uplink.frequency_block.width
        
        # Since all of a channel goes to one Sw ASIC, we can work 
        # this out now, once, for all sub-channels
        sw_asic = self._get_sw_lc(channel_width)

        # Routing 2 MHz band at a time, keep going until none left.
        while uplink_freqs != [] and downlink_freqs != []:
            # Choose current frequency
            up_f = uplink_freqs[0]
            down_f = downlink_freqs[0]
            
            # Choose current beamweights
            up_bws = uplink.beam.beamweights[up_f]
            down_bws = downlink.beam.beamweights[down_f]
           

            
            stage_three_status = self.stage_three.create_user_route(sc_i, sw_asic,
                                                                    up_f, up_pol, up_bws, 
                                                                    down_f, down_pol, down_bws, 
                                                                    gain, target_page)
            
            # Check the result of the attempted stage 3 route
            # If it is a sub-channel, remove frequencies and go to
            # the next one (success)
            if type(stage_three_status) == SubChannel:
                
                # Add this sub-channel to the over channel object
                chan.add_sub_channel(stage_three_status)
                
                # Remove uplink frequency
                uplink_freqs.pop(0)
                # Remove downlink frequency
                downlink_freqs.pop(0)
                
                # Increment Sub-channel counter
                sc_i += 1
                
                # Return to top of while loop
#                 input()
                continue
            
            # If 'rxbfn', Stage 1 allocate new engine
            elif stage_three_status == ['rxbfn']:
                
                # Attempt to allocate new engine
                try:
                    self.stage_one.allocate_new_eng(up_f, up_pol)
                    
                    # Once allocated, return to top of while loop
                    # to attempt same frequency again
                    continue
                # TODO:
                except:
                    raise Exception("Failed to allocated new RX engine")
                
            # If 'txbfn', Stage 2 allocate new engine
            elif stage_three_status == ['txbfn']:
                
                # Attempt to allocate new engine
                try:
                    self.stage_two.allocate_new_eng(down_f, down_pol)
                    
                    # Once allocated, return to top of while loop
                    # to attempt same frequency again
                    continue
                # TODO:
                except:
                    raise Exception("Failed to allocated new TX engine")
            
            # If both, Stage 1 and 2 allocate new engine
            elif stage_three_status == ['rxbfn','txbfn']:
                
                # Attempt to allocate new RX engine
                try:
                    self.stage_one.allocate_new_eng(up_f, up_pol)
                # TODO:
                except:
                    raise Exception("Failed to allocated new RX engine")
                
                # Attempt to allocate new TX engine
                try:
                    self.stage_two.allocate_new_eng(down_f, down_pol)
                # TODO:
                except:
                    raise Exception("Failed to allocated new TX engine")
                
                # If both succeed, back to top of while loop
                continue
            
            # TEMP TO RETURN
            else:
                return None
        
        return chan
        
    def create_gw_channel(self, channel_id, uplink, downlink, gain, target_page, traffic_type):
        
        """
        TODO:
        
        """
        
        # Initialise new channel object
        chan = Channel(self.logger, channel_id, uplink, downlink, gain, traffic_type)
        
        # Make a copy of the frequency list
        uplink_freqs = list(uplink.freq_list)
        downlink_freqs = list(downlink.freq_list)

        # Assign gateways
        up_gw = uplink.gateway
        down_gw = downlink.gateway
        
        # Initialise sub-channel counter
        sc_i = 0
        
        # Width of the channel
        channel_width = uplink.frequency_block.width
        # Since all of a channel goes to one Sw ASIC, we can work 
        # this out now, once, for all sub-channels
        sw_asic = self._get_sw_lc(channel_width)
        
        # Routing 2 MHz band at a time, keep going until none left.
        while uplink_freqs != [] and downlink_freqs != []:
            
            # Choose current frequency
            up_f = uplink_freqs[0]
            down_f = downlink_freqs[0]
            
            # Initialise new sub-channel object
            sub_chan = SubChannel(self.logger, sc_i, up_f, down_f)
            
            # Call Stage 1 route gateway method
            stage_one_status = self.stage_one.create_gw_route(sub_chan,
                                                              up_f, up_gw, 
                                                              gain, target_page)
#             return sub_chan
            # Call Stage 2 route gateway method
            stage_two_status = self.stage_two.create_gw_route(sub_chan,
                                                              down_f, down_gw,
                                                              gain, target_page)
            
            # If both succeed
            if type(stage_one_status) == tuple and type(stage_two_status) == tuple:
                
                # Process returned information
                # RXBFN info
                rxbfn = stage_one_status[0]
                rxbfn_block = stage_one_status[1]
                # This is the input on the RxBFN ISS
                rxbfn_coord = stage_one_status[2]
                
                # TXBFN info
                txbfn = stage_two_status[0]
                txbfn_block = stage_two_status[1]
                # This is the output on the TxBFN OSS
                txbfn_coord = stage_two_status[2]
                
                try:
                    
                    self.stage_three.create_gw_route(sub_chan, up_f, down_f,
                                                     rxbfn, rxbfn_block, rxbfn_coord, 
                                                     sw_asic,
                                                     txbfn, txbfn_block, txbfn_coord, 
                                                     gain, target_page)
                    
                    # Add this sub-channel to the over channel object
                    chan.add_sub_channel(sub_chan)
                    
                    # Remove uplink frequency
                    uplink_freqs.pop(0)
                    # Remove downlink frequency
                    downlink_freqs.pop(0)
                    
                    # Increment Sub-channel counter
                    sc_i += 1
                    
                    # Return to top of while loop
                    continue
                except:
                    raise Exception("***FAILED TO CREATE STAGE 3 GW-GW ROUTE***")
            
#             # Raise exception if no route found for this sub-channel
#             elif stage_one_status == 'NO_SPACE' :#or stage_two_status == 'NO_SPACE':
#                 raise Exception("***FAILED TO CREATE STAGE 1 or STAGE 2 GW-GW SUB-CHANNEL***")
            
        return chan
        
    def create_rtn_channel(self, channel_id, uplink, downlink, gain, target_page, traffic_type):
        
        """
        TODO:
        
        """
        
        # Initialise new channel object
        chan = Channel(self.logger, channel_id, uplink, downlink, gain, traffic_type)
        
        # Polarisation of requested uplink
        up_pol = uplink.beam.pol
        
        # Make a copy of the frequency list
        uplink_freqs = list(uplink.freq_list)
        downlink_freqs = list(downlink.freq_list)
        
        # Assign gateway
        down_gw = downlink.gateway
        
        # Initialise sub-channel counter
        sc_i = 0
        
        # Width of the channel
        channel_width = uplink.frequency_block.width
        
        # Since all of a channel goes to one Sw ASIC, we can work 
        # this out now, once, for all sub-channels
        sw_asic = self._get_sw_lc(channel_width)
            
        # Routing 2 MHz band at a time, keep going until none left.
        while uplink_freqs != [] and downlink_freqs != []:
            
            # Choose current frequency
            up_f = uplink_freqs[0]
            down_f = downlink_freqs[0]
            
            # Choose current beamweights
            up_bws = uplink.beam.beamweights[up_f]
            
            # Initialise new sub-channel object
            sub_chan = SubChannel(self.logger, sc_i, up_f, down_f)
            
            # Stage 2 first
            # Call Stage 2 route gateway method
            # TODO: NEW BFN ALLOCATION (REMOVED)
            stage_two_status = self.stage_two.create_gw_route(sub_chan,
                                                              down_f, down_gw,
                                                              gain, target_page)
            
            if type(stage_two_status) == tuple:
                
                # TXBFN info
                txbfn = stage_two_status[0]
                txbfn_block = stage_two_status[1]
                # This is the output on the TxBFN OSS
                txbfn_coord = stage_two_status[2]
                
                try:
                    stage_three_status = self.stage_three.create_rtn_route(sub_chan, sw_asic,
                                                                           up_f, up_pol, up_bws, 
                                                                           down_f,
                                                                           txbfn, txbfn_block, txbfn_coord,
                                                                           gain, target_page)
                    
                    # If success
                    if type(stage_three_status) == SubChannel:
                        
                        # Add this sub-channel to the over channel object
                        chan.add_sub_channel(sub_chan)
                        
                        # Remove uplink frequency
                        uplink_freqs.pop(0)
                        # Remove downlink frequency
                        downlink_freqs.pop(0)
                        
                        # Increment Sub-channel counter
                        sc_i += 1
                        
                        # Return to top of while loop
                        continue
                    # If not sucess
                    elif stage_three_status[0] == 'rxbfn':
                        # Attempt to allocate new engine
                        try:
                            self.stage_one.allocate_new_eng(up_f, up_pol)
                            
                            # Once allocated, return to top of while loop
                            # to attempt same frequency again
                            continue
                        # TODO:
                        except:
                            raise Exception("Failed to allocated new RX engine")
                except:
                    raise Exception("***FAILED TO CREATE STAGE 3 RTN ROUTE***")
            # Raise exception if no route found for this sub-channel
#             elif stage_two_status[0] == 'NO_SPACE':
#                 raise Exception("***FAILED TO CREATE STAGE 2 GW SUB-CHANNEL***")

        return chan
        
    def create_fwd_channel(self, channel_id, uplink, downlink, gain, target_page, traffic_type):
        
        """
        TODO:
        
        """
        
        # Initialise new channel object
        chan = Channel(self.logger, channel_id, uplink, downlink, gain, traffic_type)
        
        # Polarisation of requested downlink
        down_pol = downlink.beam.pol
        
        # Make a copy of the frequency list
        uplink_freqs = list(uplink.freq_list)
        downlink_freqs = list(downlink.freq_list)
        
        # Assign gateway
        up_gw = uplink.gateway
        
        # Initialise sub-channel counter
        sc_i = 0
        
        # Width of the channel
        channel_width = uplink.frequency_block.width
        
        # Since all of a channel goes to one Sw ASIC, we can work 
        # this out now, once, for all sub-channels
        sw_asic = self._get_sw_lc(channel_width)
            
        # Routing 2 MHz band at a time, keep going until none left.
        while uplink_freqs != [] and downlink_freqs != []:
            
            # Choose current frequency
            up_f = uplink_freqs[0]
            down_f = downlink_freqs[0]
            
            # Choose current beamweights
            down_bws = downlink.beam.beamweights[down_f]
            
            # Initialise new sub-channel object
            sub_chan = SubChannel(self.logger, sc_i, up_f, down_f)
            
            # Stage 1 first
            # Call Stage 1 route gateway method
            # TODO: NEW BFN ALLOCATION (REMOVED)
            stage_one_status = self.stage_one.create_gw_route(sub_chan,
                                                              up_f, up_gw,
                                                              gain, target_page)
            
            if type(stage_one_status) == tuple:
                
                # RXBFN info
                rxbfn = stage_one_status[0]
                rxbfn_block = stage_one_status[1]
                # This is the input on the RxBFN ISS
                rxbfn_coord = stage_one_status[2]
                
                try:
                    stage_three_status = self.stage_three.create_fwd_route(sub_chan, sw_asic,
                                                                           rxbfn, rxbfn_block, rxbfn_coord,
                                                                           up_f,
                                                                           down_f, down_pol, down_bws, 
                                                                           gain, target_page)
                    
                    # If success
                    if type(stage_three_status) == SubChannel:
                        
                        # Add this sub-channel to the over channel object
                        chan.add_sub_channel(sub_chan)
                        
                        # Remove uplink frequency
                        uplink_freqs.pop(0)
                        # Remove downlink frequency
                        downlink_freqs.pop(0)
                        
                        # Increment Sub-channel counter
                        sc_i += 1
                        
                        # Return to top of while loop
                        continue
                    # If not sucess
                    elif stage_three_status[0] == 'txbfn':
                        # Attempt to allocate new engine
                        try:
                            self.stage_two.allocate_new_eng(down_f, down_pol)
                            
                            # Once allocated, return to top of while loop
                            # to attempt same frequency again
                            continue
                        # TODO:
                        except:
                            raise Exception("Failed to allocated new TX engine")
                except:
                    raise Exception("***FAILED TO CREATE STAGE 3 FWD ROUTE***")
            # Raise exception if no route found for this sub-channel
#             elif stage_two_status[0] == 'NO_SPACE':
#                 raise Exception("***FAILED TO CREATE STAGE 2 GW SUB-CHANNEL***")

        return chan        
    
    def create_channel(self, channel_id, uplink, downlink, gain, target_page):
        
        """
        TODO:
        
        """
        
        # Check that <channel_id> is unique. Reject if not.
        if channel_id in self.operator.channel_storage.active_ids:
            raise Exception(f"A Channel with channel_id: '{channel_id}' already exists. Command rejected.")
        
        # Gain must be None for v1.
        if gain != None:
            raise Exception("Gain setting not in scope for v1. Please assign 'None' instead.")

        if target_page not in ASIC_PAGES:
            raise ValueError("Target page must be an integer type. 0 for active memory, 1 for shadow memory.")

        # Check Uplink and Downlink names.
        # If neither exist, continue.
        if (uplink.name not in self.operator.channel_storage.active_uplinks and
            downlink.name not in self.operator.channel_storage.active_downlinks):
            self.logger.debug("Verified uplink and downlink IDs.")
        
        # If Uplink exists, Downlink doesn't, return error saying
        # "multicast not supported in v1".
        elif (uplink.name in self.operator.channel_storage.active_uplinks and
              downlink.name not in self.operator.channel_storage.active_downlinks):
            raise Exception("Multicast not supported in v1 of the routing algorithm.")
            
        # If Downlink exists, return error saying "rejected unicast 
        # attempt".
        elif downlink.name in self.operator.channel_storage.active_downlinks:
            raise Exception("Attempted unicast has been rejected.")
        
        # Process the request and call the relevant stage 3 methods.
        routing_method,traffic_type = self._process_request(uplink, downlink)
        
        # Call the correct method for routing 
        channel = routing_method(channel_id, uplink, downlink, gain, target_page, traffic_type)
        
        # Add the newly created channel to the set of channels
        self.operator.channel_storage.channels.add(channel)
        self.operator.channel_storage.active_ids.add(channel_id)
        self.operator.channel_storage.active_uplinks.add(uplink.name)
        self.operator.channel_storage.active_downlinks.add(downlink.name)
        
        
    def delete_channel(self, channel_id, target_page):
        
        """
        TODO:
        
        """
        # Find correct channel
        try:
            chan = next(c for c in self.operator.channel_storage.channels if c.id == channel_id)
        except StopIteration as e:
            raise ValueError(f"Channel with ID: '{channel_id}' doesn't exist") from e
        
        # Delete the channel (Removes all keys, updates available slots).
        chan.delete(target_page)
        
        # Remove the channel from the set of channels
        self.operator.channel_storage.channels.remove(chan)
        
        # Remove channel for garbage collection
        del chan
