"""-----------------------------------------------
 Class and functions for Stage 2 of RA
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging
import random
from operator import itemgetter
# import time
# import sys

# from lib.hydra.src.system.asic import Rx, RxBFN, Sw, TxBFN, Tx
from lib.hydra.src.system.path.Path import SERDES_Path, STS_Path
from lib.hydra.src.routing.routing_toolkit import *
# from lib.dcm.src.DCM import DCM
from lib.hydra.src.system.Constants import (POL_TO_BFN, ENG_TO_FREQ_ID, 
                                            POL_TO_CONV)


class StageTwo(object):

    def __init__(self, hydra_logger, txs, txbfns, serdes, asic_serdes_lut,
                 freq_to_bfn_lut):
     
        """
        Constructor
        
        DESC

        
        @param hydra_logger: 
        @param txs: 
        @param txbfns: 
        @param serdes: 
        @param asic_serdes_LUT:
        """
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
            
        # Assign ASIC sets for each mode

        self.txbfns = txbfns
        self.txs = txs
    
        # Assign ASIC SERDES LUT
        # Used for speed and convenience of finding the connections
        # between any two given asics.
        self.asic_serdes_lut = asic_serdes_lut
        
        # Assign frequency to bfn LUT
        self.freq_to_bfn_lut = freq_to_bfn_lut
        
        if self.freq_to_bfn_lut:
            self._build_pre_allocated_routes()
            # TODO:
            stage_status = True#self._validate_routes()

            
        if stage_status:
            if self.logger:
                self.logger.info("STAGE 2 routes have been pre-allocated and all checks passed.")
        else:
            if self.logger:
                self.logger.error("STAGE 2 routes validation failed.")
            raise Exception("STAGE 2 routes validation failed.")

    def _get_eng_id(self, freq_id):
        
        try:
            return next((e,f) for (e,f) in ENG_TO_FREQ_ID.items() if freq_id in f)[0]
        
        except StopIteration:
            raise Exception(f"No engine assigned to frequency ID: {freq_id}")
        
    def _get_frequency_value(self, bfn_block, eng_id, freq_id):

        try:
            return next(f for f in bfn_block.bfns[eng_id].frequency if f['id']==freq_id)
                    
        except StopIteration:
            return None
        
    def _get_sorted_dacs(self, dacs):
        
        # Filter the full list of dacs on the ASIC to only the
        # relevant ones for that BFN block. BFN block 0 contains
        # pol A ("HORIZ"), BFN block 1 contains pol B ("VERT").
        
        # Initialise sorted dac list for each BFN block
        dac_list = [[],[]]
        
        for dac in dacs:
            
            if dac.antenna_element.pol == 'HORIZ':
                
                dac_list[0].append(dac)
            
            elif dac.antenna_element.pol == 'VERT':
                
                dac_list[1].append(dac)
        
        # Want a list with 4 entries, with <None> for the non 
        # existent ADCs.
        for dac_subset in dac_list:
            
            while len(dac_subset) != 4:

                dac_subset.append(None)
                
        return dac_list
    
    def _get_channeliser_slot(self, freq, dac):
        
        # Return a TDM,TS coord for a given frequency on some DAC.
        # If the DAC is not present, return None (i.e. no route to 
        # be preallocated from the Rx).
        
        if freq and dac:
            
            # Get the sub-channel number from the frequency
            SC = dac.get_sc_number(freq)
            # Use the SC number to get the TDM,TS.
            coord = dac.channeliser.get_slot(SC)
            
            return coord
            
        elif not freq or not dac:
            return None
                
    def _build_pre_allocated_routes(self):
                
        # Only assessing BFN(0) since BFN(1) handles the 
        # same frequencies, just a different polarisation.
        # Each time, assess BFN(0), and each engine.
        # Identify if that engine has a frequency_1 assigned
        # from the f2b yaml file. If it does, assign that as
        # the first frequency in the order, and increment up
        # the number of frequencies. Use the first four 
        # timeslots for this on <oss.input>
        # <oss.output> must be set to the first TDM on the 
        # first serdes connecting the TxBFN to the Tx,
        
        # NOTE: The following considers connecting each 
        # TxBFN to each Tx in the same way that Stage 1 does.
        # This time however, we are looking backwards (i.e. 
        # from the tx antenna elements).
        # This means that all of the labelling is the opposite
        # compared to stage 1.
        
        if self.logger:
            self.logger.info("Building Stage 2 routes...")
        
        # Loop through each Tx BFN ASIC.
        for txbfn in self.txbfns:
            
            # Create a frequency order list for staggering per BFN ASIC
            # (one for each TDM wrt SERDES).
            tdm0_stagger = [i for i in range(0,64)]
            tdm1_stagger = [i for i in range(64,128)]
            
            if self.logger:
                self.logger.debug(f"Pre-allocating with {txbfn.name}")
            
            # Loop through each Tx ASIC
            for tx in self.txs:
                
                # Check if User TX before proceeding
                if 'MOB' not in tx.mode:
                    continue

                # Identify SERDES between the two ASICs
                serdes_list = self.asic_serdes_lut[txbfn.name][tx.name]
                
                # Sort DACs for current TX ASIC
                dacs_sorted = self._get_sorted_dacs(tx.dacs)
                
                # Loop through each bfn block
                for bfn_block in txbfn.bfn_blocks:
                    
                    # Initialise frequency counter
                    f_counter = 0
                    # Initialise timeslot counter
                    ts_counter = 0
                    
                    # Choose the right SERDES for each BFN ASIC-half
                    # SERDES0 for BFN(0), SERDES1 for BFN(1)
                    # (in the context of the serdes between the two 
                    # asics).
                    bfn_index = txbfn.bfn_blocks.index(bfn_block)
                    
                    # Assign current SERDES
                    sd = serdes_list[bfn_index]
                    
                    # Choose dacs for current BFN block
                    dac_list = dacs_sorted[bfn_index]
                    
                    # Loop through the max frequencies on each 
                    # SERDES.
                    # This number is the data precision of the SERDES
                    # divided by the maximum antenna elements per Tx 
                    # per polarisation (4, fixed)
                    max_freqs_per_sd = sd.size//4
                    for _ in range(max_freqs_per_sd):
                        
                        # Create route from SERDES to Tx BFN engine.
                        # This is done for all frequencies, even if 
                        # not in the freq allocation (becasue we are 
                        # planning for all of the freqs).
                        
                        # --------v-SERDES TDM SELECTION-v--------- #
                        
                        # For the first (64) frequencies, choose TDM0
                        # on that SERDES
                        if f_counter == 0:
                            # Get info for TDM0 (source and sink)
                            sd_src_tdm = sd.source.operating_tdm[0]
                            sd_sink_tdm = sd.sink.operating_tdm[0]
                        
                            sd_occ = serdes_list[bfn_index].occupancy[0]
                            
                            stagger = tdm0_stagger

                        # For the 65th frequency (first on new TDM),
                        # choose TDM1 on that SERDES
                        if f_counter == max_freqs_per_sd:
                            
                            sd_src_tdm = sd.source.operating_tdm[1]
                            sd_sink_tdm = sd.sink.operating_tdm[1]
                            
                            sd_occ = sd.occupancy[1]
                            
                            stagger = tdm1_stagger
                            
                            # Also reset frequency and timeslot counter, 
                            # because new serdes TDM after 64th freq
                            ts_counter = 0
                            f_counter = 0
                            
                        # For the rest of the frequencies,
                        # choose TDM1 on that SERDES  
                        if f_counter == (max_freqs_per_sd+1):
                            # Get info for TDM1 (rest of freq)
                            sd_sink_tdm = sd.sink.operating_tdm[1]
                            sd_src_tdm = sd.source.operating_tdm[1]
                            
                            sd_occ = serdes_list[bfn_index].occupancy[1]
                        
                        # --------^-SERDES TDM SELECTION-^--------- #
                        

                        # -----------v-SLOT ASSIGNMENT-v----------- #
                        
                        # Identify the frequency ID being assigned
                        freq_id = stagger[f_counter]
                        
                        # Identify the BFN engine ID that handles
                        # the frequency ID being allocated. 
                        eng_id = self._get_eng_id(freq_id)
                        
                        # Identify frequency using frequency ID
                        freq = self._get_frequency_value(bfn_block, eng_id, freq_id)

                        # Loop 4 times for 1st freq.
                        # 1 slot per antenna element, therefore max 4
                        # per polarisation.
                        for elem_i in range(4):
                            # -------------v-TX ASIC-v------------- #
                            # If frequency is assigned, return a
                            # coordinate (TDM,TS) on the TX OSS output
                            out_coord = self._get_channeliser_slot(freq['value'], dac_list[elem_i])
                            
                            # Get the input coordinate (TDM,TS) to 
                            # route to relevant SERDES.
                            in_coord = (sd_sink_tdm, ts_counter)
                            
                            # If the frequency exists, create a route
                            # through the TX ASIC STS, from <in_coord>
                            # to <out_coord>. Uses least congested 
                            # end-to-end algorithm.
                            if out_coord:
                                success = route_sts_fafs(tx.bfn_blocks[1], in_coord, out_coord)
                                
                                # Remember which antenna elements relate
                                # to which timeslots.
                                freq['slots'][dac_list[elem_i].antenna_element.id] = ts_counter
                                
                                if type(success) != int:
                                    raise Exception("***FAILED TO CREATE ROUTE***")
                                

                            # -------------^-TX ASIC-^------------- #
                            
                                # ------------v-SERDES-v--------------- #
                                # The value being assigned <freq_id>,
                                # has no significance, it is just for
                                # tracking here.
                                sd_occ[ts_counter] = freq_id
                                # ------------^-SERDES-^--------------- #
                                
                                # -------v-TX BFN OSS (+ RAMs)-v------- #
                                # Route spatial switch from TDM <eng_id>
                                # to TDM <sd_src_tdm>
                                bfn_block.oss.occupancy[eng_id][ts_counter].append(sd_src_tdm)
                                
                                # The OSS maps directly to the storage on
                                # the BFN engine.
                                # Each of the active RAMs recieve all the
                                # slots, and we append <freq_id> to 
                                # signify they are ready to be used in
                                # the beamformer.

                            # -------^-RX BFN ISS (+ RAMs)-^------- #
                            
                            # Incrememnt the timeslot counter
                            ts_counter += 1
                        
                            
                        # After frequency assigned, move onto the next.
                        f_counter += 1

                        # Identify the frequency ID being assigned
                        freq_id = stagger[f_counter]
                        
                        # Identify the BFN engine ID that handles
                        # the frequency ID being allocated. 
                        eng_id = self._get_eng_id(freq_id)
                        
                        # Identify frequency using frequency ID
                        freq = self._get_frequency_value(bfn_block, eng_id, freq_id)

                        # Repeat for 2nd freq.
                        for elem_i in range(4):
                            # ----------v-RX ASIC OSS-v------------ #                           

                            out_coord = self._get_channeliser_slot(freq['value'], dac_list[elem_i])
                            in_coord = (sd_sink_tdm, ts_counter)
                            
                            if out_coord:
                                success = route_sts_fafs(tx.bfn_blocks[1], in_coord, out_coord)
                                
                                # Remember which antenna elements relate
                                # to which timeslots.
                                freq['slots'][dac_list[elem_i].antenna_element.id] = ts_counter
                                
                                if type(success) != int:
                                    

                                    
                                    raise Exception("***FAILED TO CREATE ROUTE***")
                            # ----------^-RX ASIC OSS-^------------ #
                            
                                # ------------v-SERDES-v--------------- #
                                # The value being assigned <freq_id>,
                                # has no significance, it is just for
                                # tracking here.
                                sd_occ[ts_counter] = freq_id
                                # ------------^-SERDES-^--------------- #
                                
                                # -------v-RX BFN ISS (+ RAMs)-v------- #
                                # Route spatial switch from TDM <sd_sink_tdm>
                                # to TDM <eng_id>
                                bfn_block.oss.occupancy[eng_id][ts_counter].append(sd_src_tdm)
                                
                                # The ISS maps directly to the storage on
                                # the BFN engine.
                                # Each of the active RAMs recieve all the
                                # slots, and we append <"READY"> to 
                                # to signify they are ready to be used in
                                # the beamformer.

                                # -------^-RX BFN ISS (+ RAMs)-^------- #
                            
                            # Incrememnt the timeslot counter
                            ts_counter += 1
                            
                            
                        # Incrememnt frequency counter
                        f_counter += 1

                # Move stagger pattern along for the next RX ASIC.
                tdm0_stagger.append(tdm0_stagger.pop(0))
                tdm1_stagger.append(tdm1_stagger.pop(0))
                
    def _get_oss_input(self, oss, out_coord):
         
        # Find the input coord for that oss output
        return next(oss_input for oss_input in range(oss.tdms_in) if oss.occupancy[oss_input][out_coord[1]] == [out_coord[0]])
    
    def _assess_tx_route(self, bfn_block, oss_in_tdm, out_ts):
               
        # TS
        # Identify output timeslot
        ts_in_slot = next(in_ts for in_ts in range(bfn_block.ts.slots) if bfn_block.ts.occupancy[oss_in_tdm][in_ts] == [out_ts])
        
        # ISS
        # Identify output TDM
        iss_in_tdm = next(iss_input for iss_input in range(bfn_block.iss.tdms_out) if bfn_block.iss.occupancy[iss_input][ts_in_slot] == [oss_in_tdm])
        
        return iss_in_tdm, ts_in_slot
    
    def _assess_serdes_route(self, rx, oss_out_tdm, ts_out_slot, freq_id, destination_info):

        # Convert TDM to port ID
        src_port_id = int(oss_out_tdm/2)
        # Get port object
        src_port = rx.out_ports[src_port_id]
        # Get SERDES object
        sd = src_port.serdes
        
        # Choose correct TDM on the SERDES (0 or 1)
        sd_tdm_id = oss_out_tdm % 2
        sd_tdm = sd.occupancy[sd_tdm_id]
        
        serdes_object_check = []
        # Check each possible destination
        for dest in destination_info:
            dest_asic = dest[0]

            # Check the SERDES object
            if sd in self.asic_serdes_lut[rx.name][dest_asic.name]:
                serdes_object_check.append(True)
                break
            else:
                serdes_object_check.append(False)
            
        # Check the SERDES slot
        if sd_tdm[ts_out_slot] == freq_id:
            serdes_slot_check = True
        else:
            serdes_slot_check = False
        
        # Get port object
        sink_port = sd.sink
        # Get arriving TDM
        rxbfn_iss_in_tdm = sink_port.operating_tdm[sd_tdm_id]
        
        # TODO: RX BFN ISS CHECK -------------------------
        rxbfn = sink_port.asic
        
        return rxbfn, rxbfn_iss_in_tdm, serdes_object_check, serdes_slot_check
    
    def _assess_rxbfn_route(self, rxbfn, iss_in_tdm, ts_slot, pol, freq_id, destination_info):
        
        # Check arrival at correct RX BFN ASIC
        # Check each possible destination
        rxbfn_object_check = []
        for dest in destination_info:
            dest_asic = dest[0]
            dest_eng = dest[2]
            
            if rxbfn is dest_asic:
                rxbfn_object_check.append(True)
            else:
                rxbfn_object_check.append(False)
        
        block_id = next(k for k,v in POL_TO_BFN.items() if v == pol)
        bfn_block = rxbfn.bfn_blocks[block_id]
        
        # Identify output TDM
        iss_out_tdm = bfn_block.iss.occupancy[iss_in_tdm][ts_slot][0]

        # Check arrival at correct Rx BFN Engine
        arrival_engine = bfn_block.bfns[iss_out_tdm]
        
        engine_object_check = []
        for dest in destination_info:
            dest_eng = dest[2]
            
            if arrival_engine is dest_eng:
                engine_object_check.append(True)
            else:
                engine_object_check.append(False)
        
        # Rx BFN ENG RAM CHECK
        engine_ram_check = []
        for ram_i in range(arrival_engine.rams.no_of_timeswitches):
            if arrival_engine.rams.occupancy[ram_i][ts_slot][0] == freq_id:
                engine_ram_check.append(True)
            else:
                engine_ram_check.append(False)
                
        return rxbfn_object_check, engine_object_check, engine_ram_check
            
    def _validate_routes(self):
        
        # Loop through frequency allocation, and ensure there is an
        # existing route for each frequency to the correct engine.
        for frequency,destination_info in self.freq_to_bfn_lut.items():
            
            # Assign frequency value
            freq = frequency[0]
            
            # Check that frequency is assigned. Go to next if not.
            if not freq:
                continue
            
            # Assign frequency polarisation
            pol = frequency[1]
            
            # Since <destination_info> is a set with any BFN ASICs
            # assigned to the chosen freq, can choose any dest to 
            # identify the <freq_id> as it is the same frequency.
            dest_eng = next(d for d in destination_info)[2]          
            
            # Assuming one engine for now
            freq_id = next(f['id'] for f in dest_eng.frequency if f['value'] == freq)
            

            dac_id_range = POL_TO_CONV[pol]
            # Go through each Rx ASIC for the given frequency.
            for tx in self.txs:
                
                # Check if User RX before proceeding
                if 'MOB' not in tx.mode:
                    continue
                
                for dac in tx.dacs:
                    
                    if dac.id in dac_id_range:
                        # Get starting coordinate from frequency
                        end_coord = self._get_channeliser_slot(freq, dac)

                        # In case of multicast route (where there is 
                        # more than one BFN engine assigned to the 
                        # same frequency), there are multiple output
                        # TDMs from the input spatial switch. Hence
                        # each of these routes must be validated.
                        oss_tdm_list = self._get_oss_input(tx.bfn_blocks[1].oss, end_coord)
                        
                        # Go through each output TDM of the ISS, and
                        # assess each part of the route to the BFN.
                        for oss_tdm in [oss_tdm_list]:
                            
                            # Assess Rx STS route
                            iss_tdm,ts_slot = self._assess_tx_route(tx.bfn_blocks[1], oss_tdm, end_coord[1])
                            
                            
                            # Assess SERDES route
                            (txbfn,oss_tdm,
                             serdes_object_check, 
                             serdes_slot_check) = self._assess_serdes_route(tx, iss_tdm, ts_slot, freq_id, destination_info)


        # If all checks pass
        return True
    
    def _check_txbfn_capacity(self, txbfn):
        
        """
        TODO
        
        """
        # Pick a random BFN Block (either 0 or 1)
        bfn_block_choices = random.sample(txbfn.bfn_blocks, len(txbfn.bfn_blocks))
        # Start checking each block
        for bfn_block in bfn_block_choices:
            # Pick a random TDM to check
            tdm_choices = random.sample([i for i in range(bfn_block.ts.no_of_timeswitches)], bfn_block.ts.no_of_timeswitches)
            for TDM in tdm_choices:
                for slot in range(bfn_block.ts.slots):
                    if (bfn_block.ts.occupancy[TDM][slot] == [] and 
                        bfn_block.ts.available_ts[TDM][slot] == slot):
                        # Return the bfn_block for routing.
                        return bfn_block
                    # if not empty
                    else:
                        # Check next slot
                        continue
                # All slots checked, check the next TDM
                continue
            # All TDMs checked, check the next bfn_block
            continue
        # No space on this ASIC, must checked next.
        return False
    
    def _get_serdes_congestion(self, asic_a, asic_b):
        
        """
        TODO:
        
        """
        
        # Identify serdes between two ASICs.
        serdes_list = self.asic_serdes_lut[asic_a.name][asic_b.name]
        
        # Initialise  list for checks    
        serdes_checks = list()
        
        # For each one, identify the least congested TDM
        for s in serdes_list:
            
            # Return info on both TDMs within SERDES.
            s_occ = s.get_occupancy()
            
            serdes_checks.append((s, 0, s_occ[0]))
            serdes_checks.append((s, 1, s_occ[1]))              
        
        # Return the list
        return serdes_checks
    
    def _get_tx_serdes_slot_fafs(self, serdes_organised):
        
        """
        TODO:
         
        """
        
        # First sort the list by lowest congestion level.
        serdes_sorted = sorted(serdes_organised, key=itemgetter(2))
        
        # Need to pick a slot that is free both on the SERDES and
        # on the timeswitch within the engine.
        
        # If there isn't one on the current serdes, go to next least
        # congested.
        for s_info in serdes_sorted:
            
            # Reference serdes object
            s_obj = s_info[0]
            # Reference serdes internal tdm (0 or 1)
            s_tdm = s_info[1]
            
            # Check through slots, get first available
            for slot in range(s_obj.size):
                
                if s_obj.occupancy[s_tdm][slot] == None:
                    
                    return s_obj, s_tdm, slot
        
        else:
            raise Exception("NO VALID SLOT FOUND")
        
    def create_gw_route(self, sub_channel, downlink_frequency, downlink_gw, gain, target_page):
        
        """
        TODO
        
        """
        
        # First need to identify where this sub-channel lands on
        # the Tx ASIC.
        
        # Identify the Tx ASIC
        tx = downlink_gw.asic
        # Identify the adc connected to the element
        dac = downlink_gw.conv
        # Get the channeliser slot
        tx_oss_out_coord = self._get_channeliser_slot(downlink_frequency, dac)
        
        # Now need to choose an Tx BFN ASIC and SERDES to be used.
        # Shuffle the txbfns and continue.
        txbfn_choices = random.sample(self.txbfns, len(self.txbfns))
        
        # Looping through as a backup in case some not free.
        for txbfn in txbfn_choices:
            # Now we must guarantee a valid route exists on this 
            # txbfn.
            bfn_block = self._check_txbfn_capacity(txbfn)
            
            # If no space, check the next ASIC
            if bfn_block == False:
                # Go to next rxbfn
                continue
            # We found a valid Tx BFN ASIC and BFN Block.
            else:
                # Exit the loop
                break

        # Now must choose SERDES and slot.
        # Organise serdes in terms of congestion
        serdes_organised = self._get_serdes_congestion(txbfn, tx)
        # Pick and serdes based on first available first served.
        serdes, serdes_tdm, serdes_slot = self._get_tx_serdes_slot_fafs(serdes_organised)
        # Identify the TDM this relates to on the OSS
        iss_in_tdm = serdes.sink.operating_tdm[serdes_tdm]
         
        # Setup Tx coords
        in_coord = (iss_in_tdm, serdes_slot)
        out_coord = tx_oss_out_coord
         
        # Route Tx ASIC
        success_tdm = route_sts_fafs(tx.bfn_blocks[1], in_coord, out_coord)
         
        if type(success_tdm) != int:
            raise Exception("Failed to create route through Rx ASIC STS.")
        else:
            # ISS slots selected
            iss_route = {'in_tdm' : in_coord[0],
                         'slot'   : in_coord[1],
                         'out_tdm': success_tdm}
            # TS slots selected
            ts_route = {'in_slot' : in_coord[1],
                        'tdm'     : success_tdm,
                        'out_slot': out_coord[1]}
            # OSS slots selected
            oss_route = {'in_tdm' : success_tdm,
                         'slot'   : out_coord[1],
                         'out_tdm': out_coord[0]}
             
            # Create the STS_Path object for this sub-channel
            tx_path = STS_Path(self.logger, tx, tx.bfn_blocks[1], iss_route, ts_route, oss_route)
            # Add the path to the sub-channel
            sub_channel.add_path(tx_path, 8)
         
        # Route SERDES (Tx-TxBFN)
        serdes.occupancy[serdes_tdm][serdes_slot] = downlink_frequency
        # Create the SERDES_Path object for this sub-channel
        serdes_path_tx = SERDES_Path(self.logger, serdes, serdes_tdm, serdes_slot)
        # Add the path to the sub-channel
        sub_channel.add_path(serdes_path_tx, 7)
         
        # Process coordinates to pass to stage 3.
        txbfn_oss_out_tdm = serdes.source.operating_tdm[serdes_tdm]
        txbfn_oss_out_coord = (txbfn_oss_out_tdm, serdes_slot)
        

        # Return the information to continue routing
        return (txbfn, bfn_block, txbfn_oss_out_coord)
        

    def allocate_new_eng(self, freq, pol):
        
        """
        TODO
        
        """