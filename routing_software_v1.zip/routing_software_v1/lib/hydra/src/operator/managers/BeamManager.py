"""-----------------------------------------------
 Class and functions for the Beam Manager
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import yaml
import logging
import os

from lib.hydra.src.system.beam.Beam import RxBeam, TxBeam
from lib.hydra.src.system.beam.BeamWeight import BeamWeight

class BeamManager(object):
    
    def __init__(self, hydra_logger, antenna_elements, beam_config_path=None):
        
        """
        Constructor
        
        Description
        
        @param hydra_logger: 
        @param antenna_elements: 
        @param beam_config_path:   
             
        """
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
        
        # Assign antennas elements
        self.antenna_elements = antenna_elements
        
        # Initialise beams set
        self.rx_beams = set()
        self.tx_beams = set()
            
    def _add_beam(self, beam_name, beam_type, beam_id, beam_pol, beamweight_sets):
        
        # Initialise beamweight sets
        bws = {}
        
        # Each key in beamweight_sets is a frequency
        for granule,beamweights in beamweight_sets.items():
            # Initialise this granule
            bws[granule] = dict()
            
            # Now add each beamweight for the granule
            for beamweight in beamweights:
                
                # First must process list into relevant objects
                
                # Find antenna element object by identify matching 
                # element ids
                ae_obj = next(elem for elem in self.antenna_elements 
                              if elem.id == beamweight['element'] 
                              and elem.pol == beam_pol)
                
                # Create a beamweight object from supplied weights
                bw_obj = BeamWeight(beamweight['amplitude'], beamweight['phase'])
                
                # Assign the mapping to the granule.
                bws[granule][ae_obj] = bw_obj
            
        if beam_type == 'RX':
            b = RxBeam(beam_name, beam_id, beam_type, beam_pol, bws)
            self.rx_beams.add(b)
            
        elif beam_type == 'TX':
            b = TxBeam(beam_name, beam_id, beam_type, beam_pol, bws)
            self.tx_beams.add(b)
            
        else:
            raise ValueError(f"Incorrect beam type: {beam_type}")
        
        if self.logger:
            self.logger.debug(f"Loading beam: {b.name}")
        
    
    def load_beams(self, beam_config_name):
        
        # Setup path to beam config yaml file
        current_file_dir = os.path.dirname(os.path.realpath(__file__))
        beam_dir = current_file_dir.split(os.path.sep)
        beam_dir[-3] = 'config'
        beam_dir[-2] = 'beams'
        beam_dir[-1] = beam_config_name 
        
        beam_config_path = os.path.sep.join(beam_dir)
        
        if self.logger:
            self.logger.info(f"Attempting to load beams from {beam_config_path}")
        
        # Open specified file and load beam config yaml
        with open(beam_config_path, 'r') as bcf:
            beam_dict = yaml.safe_load(bcf)
            
        if beam_dict:
            # Now to parse the beam_dict
            beam_list = beam_dict.pop('beams', None)

            for beam in beam_list:
                self._add_beam(beam['name'], beam['type'], beam['id'], beam['polarisation'],
                              beam['beamweight_sets'])
                
        else:
            return
        
        # Check that Rx and Tx beams have been loaded
        if self.rx_beams and self.tx_beams:
            pass
        else:
            if self.logger:
                self.logger.warning("No beams have been loaded.")

        if self.logger:
            self.logger.info(f"Loaded {len(self.rx_beams)} RX Beam(s)")
            self.logger.info(f"Loaded {len(self.tx_beams)} TX Beam(s)")
        