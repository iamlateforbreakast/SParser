"""-----------------------------------------------
 Class and functions for the Link Manager
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging

from lib.hydra.src.system.link.Link import Uplink, Downlink
from lib.hydra.src.system.frequency.FrequencyBlock import FrequencyBlock

class LinkManager(object):
    
    def __init__(self, hydra_logger, rx_beams, tx_beams, gw_antennas):
        
        """
        Constructor
        
        Description
        
        @param aaaaaaa: 
        @param aaaaaaa: 
        @param aaaaaaa:   
             
        """
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
        
        # Assign beams so that links can be generated
        self.rx_beams = rx_beams
        self.tx_beams = tx_beams
        
        # Assign gateway antennas
        self.gws = gw_antennas
        
        # Initialise list of uplinks and downlinks
        self.uplinks = []
        self.downlinks = []

    def generate_link(self, link_name, beam_name, centre_freq, width):
        
        # Check if this is gateway or user beam.
        # Negative beam name indicates gateway antenna being
        # specified
        if type(beam_name) == str:
            # Combine to all beams.
            self.beams = self.rx_beams | self.tx_beams
            
            # Get beam object using name
            link_object = next(b for b in self.beams if b.name == beam_name)
            
        elif beam_name < 0:
            # Get Antenna object using gateway id
            link_object = next(gw for gw in self.gws if gw.id == beam_name)
        
        else:
            raise ValueError(f"Invalid input: {beam_name}. \
                               Must be an existing beam name or GW ID.")
        
        if hasattr(link_object, 'pol'):
            pol = link_object.pol
        else:
            pol = None
        
        # Create frequency block object 
        freq_block = FrequencyBlock(centre_freq, width, pol)
        
        # Check what kind of link this is, i.e. Rx or Tx
        if link_object.type == 'RX':
            L = Uplink(link_object, freq_block, link_name)
            self.uplinks.append(L)
        
        elif link_object.type == 'TX':
            L = Downlink(link_object, freq_block, link_name)
            self.downlinks.append(L)            
        
        else:
            raise ValueError(f"Invalid link_object type: {link_object.type}")
        
        return L