"""-----------------------------------------------
 Class and functions for the storage of channels
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""


import logging

class ChannelStorage(object):
    
    def __init__(self, hydra_logger):
        
        """
        Constructor
        
        Description
        
        @param aaaaaaa: 
        @param aaaaaaa: 
        @param aaaaaaa:   
             
        """
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
        
        # Initialise active channels set
        self.channels = set()
        
        # Initialise active channel IDs set
        self.active_ids = set()
        
        # Initialise active uplinks set
        self.active_uplinks = set()
        
        # Initialise active downlinks set
        self.active_downlinks = set()