"""-----------------------------------------------
 Class and functions for the Operator settings,
 including
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging
import os
import yaml

from lib.hydra.src.operator.managers.BeamManager import BeamManager 
from lib.hydra.src.operator.managers.LinkManager import LinkManager
from lib.hydra.src.operator.managers.ChannelStorage import ChannelStorage

class Operator(object):
    
    def __init__(self, hydra_logger, antenna_elements, gateway_antennas):
        
        """
        Constructor
        
        Description
        
        @param hydra_logger: 
        @param antenna_elements: 
        @param gateway_antennas:   
             
        """
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
            
        # Start Beam Manager
        if self.logger:
            self.logger.info(f"Started Beam Manager.")
        
        self.beam_manager = BeamManager(self.logger,
                                        antenna_elements)
        
        # Start temp. Link Manager
        if self.logger:
            self.logger.info("(Starting Link Manager...)")

        self.link_manager = LinkManager(self.logger, self.beam_manager.rx_beams,
                                        self.beam_manager.tx_beams, 
                                        gateway_antennas)
        
        if self.logger:
            self.logger.info(f"(Ready to create links.)")

        # Start Channel Storage
        self.channel_storage = ChannelStorage(self.logger)

        # Load frequency to BFN engine allocation
        # Setup path to freq2bfn yaml file (fixed for this drop)
        current_file_dir = os.path.dirname(os.path.realpath(__file__))
        freq2bfn_dir = current_file_dir.split(os.path.sep)
        freq2bfn_dir[-2] = 'config'
        freq2bfn_dir[-1] = 'freq_to_bfn_allocation'
        freq2bfn_dir.append('f2b_onesat_dtp_arch_a.yaml') 
        
        freq2bfn_dir_path = os.path.sep.join(freq2bfn_dir)
        
        self._load_freq2bfn(freq2bfn_dir_path)
        
    
    def _load_freq2bfn(self, freq2bfn_path):
        
        # Open specified file and load freq2bfn yaml
        with open(freq2bfn_path, 'r') as f2b:
            freq2bfn_dict = yaml.safe_load(f2b)
            
        self.freq2bfn = freq2bfn_dict.pop('allocation')
        
    def load_beams(self, beam_config_name):
        
        self.beam_manager.load_beams(beam_config_name)
