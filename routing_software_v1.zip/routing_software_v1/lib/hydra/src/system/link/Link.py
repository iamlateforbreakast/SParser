
import math

from lib.hydra.src.system.beam.Beam import Beam
from lib.hydra.src.system.antenna.AntennaElement import AntennaElement
from lib.hydra.src.system.frequency.FrequencyBlock import FrequencyBlock



class Link(object):
	
	def __init__(self):
		
		if type(self) == Link:
			raise Exception("Link is an abstract type!")
		
	def _process_freq_block(self, freq_block):
		
		# Reference cf
		cf = freq_block.centre_freq
		
		# Initialise freq list
		self.freq_list = list()
		
		# The following processing stages are exact opposites of each
		# other. 
		# Odd C.F. with even multiple of 2 MHz width -> OK
		# Odd C.F. with odd multiple of 2 MHz width -> +1 SC
		# Even C.F. with odd multiple of 2 MHz width -> OK
		# Even C.F. with even multiple of 2 MHz width -> +1 SC
	
		# Check if odd cf requested
		if cf % 2 == 1:
			# Identify if even or odd number of sub-channels.
			# If even, split as expected.
			# If odd, must add one and then split as expected.
			num_of_sc = freq_block.width//2 
			
			if num_of_sc % 2 == 1:
				num_of_sc += 1
			# Looks strange, but divides by 2 and floors result, which
			# gives number of sc  below/above, then multiply by 2 MHz to
			# get the frequency again. +1 or -1 because at the edge.
			low_f = cf-(num_of_sc//2)*2 +1
			up_f = cf+(num_of_sc//2)*2 -1	
		
		elif cf % 2 == 0:
			# Identify if even or odd number of sub-channels.
			# If odd, split as expected.
			# If even, must add one and then split as expected.
			num_of_sc = freq_block.width//2
			
			if num_of_sc % 2 == 0:
				num_of_sc += 1
			# Looks strange, but divides by 2 and floors result, which
			# gives number of sc  below/above, then multiply by 2 MHz to
			# get the frequency again.
			low_f = cf-(num_of_sc//2)*2
			up_f = cf+(num_of_sc//2)*2
		
		for f in range(low_f, up_f+2, 2):
			self.freq_list.append(f)
			
		# Amend the width if needed
		freq_block.width = len(self.freq_list)
			
			
class Uplink(Link):
	
	def __init__(self, link, frequency_block, name):

		# Check if link is for a Beam object or gateway number		
		if link.__class__.__bases__[0] == Beam:
			
			self.beam = link
		
		elif link.__class__.__bases__[0] == AntennaElement:
			
			self.gateway = link
			
		else:
			raise ValueError(f"Incorrect type: {type(link)} specified")
		
		# Assign frequency block identifier
		if type(frequency_block) != FrequencyBlock:
			
			raise ValueError(f"Incorrect type: {type(frequency_block)} specified")
		
		# Assign name
		self.name = name
		
		# Reference the frequency block
		self.frequency_block = frequency_block
		
		# Generate the frequency list, amend width
		self._process_freq_block(frequency_block)

	
	
class Downlink(Link):
		
	def __init__(self, link, frequency_block, name):
		
		# Check if link is for a Beam object or gateway number		
		if link.__class__.__bases__[0] == Beam:
			
			self.beam = link
		
		elif link.__class__.__bases__[0] == AntennaElement:
			
			self.gateway = link
			
		else:
			raise ValueError(f"Incorrect type: {type(link)} specified")
		
		# Assign frequency block identifier
		if type(frequency_block) != FrequencyBlock:
			
			raise ValueError(f"Incorrect type: {type(frequency_block)} specified")
		
		# Assign name
		self.name = name
		
		# Reference the frequency block
		self.frequency_block = frequency_block
		
		# Generate the frequency list, amend width
		self._process_freq_block(frequency_block)
	
	