
from lib.hydra.src.system.Constants import FREQUENCY_BANDS


class FrequencyBlock(object):
    
    def __init__(self, centre_freq, width, pol):
        
        # Identify the band of this request
        for k,v in FREQUENCY_BANDS.items():
            if centre_freq < v[1] and centre_freq >= v[0]:
                self.band = k
        
        self.centre_freq = centre_freq
        
        self.width = width
        
        self.pol = pol
        # TODO: ask about granularity