
from itertools import count

class AntennaElement(object):
	
	def __init__(self):
		
		# Force Beam as an abstract type
		if type(self) == AntennaElement:
			raise Exception("AntennaElement is an abstract type")


class RxAntennaElement(AntennaElement):
	
	# Assign IDs for naming
	_id = count(0)
	
	def __init__(self, elem_id, pol, elem_type, asic, conv):
		
		# Check input args
		if type(asic).__name__.lower() != 'rx':
			raise ValueError(f'Expected RxDSC, not {type(asic)}')
		if type(conv).__name__.lower() != 'adc':
			raise ValueError(f'Expected ADC, not {type(conv)}')

		# Assign antenna element number
		self.id = elem_id
		# Assign polarisation
		self.pol = pol
		# Assign antenna type (Rx or Tx)
		self.type = elem_type
		# Assign relevant asic
		self.asic = asic
		# Assign relevant converter
		self.conv = conv
	
	
class TxAntennaElement(AntennaElement):
	
	# Assign IDs for naming
	_id = count(0)
	
	def __init__(self, elem_id, pol, elem_type, asic, conv):
		
		# Check input args
		if type(asic).__name__.lower() != 'tx':
			raise ValueError(f'Expected TxDSC, not {type(asic)}')
		if type(conv).__name__.lower() != 'dac':
			raise ValueError(f'Expected DAC, not {type(conv)}')
		
		# Assign antenna element number
		self.id = elem_id
		# Assign polarisation
		self.pol = pol
		# Assign antenna type (Rx or Tx)
		self.type = elem_type
		# Assign relevant asic
		self.asic = asic
		# Assign relevant converter
		self.conv = conv