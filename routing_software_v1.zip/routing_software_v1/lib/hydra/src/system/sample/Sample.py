"""-----------------------------------------------
 Class and functions for a sample
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging
from lib.hydra.src.system.antenna.AntennaElement import (RxAntennaElement,
                                                         TxAntennaElement)

class Sample(object):

    def __init__(self, hydra_logger, engine, antenna_element, beamweight, ram_route, ts_route):
     
        """
        Constructor
        
        DESC

        
        @param hydra_logger: 
        @param antenna_element: 
        @param beamweight:
        @param ram_route: 
        @param ts_route: 
        @param ss_route:
        
        """
        
        
        # Initialise logger
        self.logger = hydra_logger
        
        # Set logger level
        if self.logger:
            self.logger.disabled = False
#             self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
            
        # Reference antenna element
        self.antenna_element = antenna_element
        
        # Reference beamweight
        self.beamweight = beamweight
        
        # Reference engine
        self.ts = engine.ts
        self.rams = engine.rams
        
        # Route info
        # These dicts look like (for ram):
        # {'ram_id' : int(),
        #  'in_slot'   : int(),
        #  'out_slot': int()}
        # Can be changed to tuples for speed.
        self.ram_route = ram_route
        self.ts_route = ts_route
            
    
    def delete(self, target_page):
        
        """
        TODO
        
        """   
        
        # RAM
        in_slot = self.ram_route['in_slot']
        ram_id = self.ram_route['ram_id']
        out_slot = self.ram_route['out_slot']
        self.rams.occupancy[ram_id][in_slot].remove(out_slot)
        # Add it back to the availables
        self.rams.available_ts[ram_id][out_slot] = out_slot
        
        # Timeswitch
        in_slot = self.ts_route['in_slot']
        out_slot = self.ts_route['out_slot']
        # Remove the out_slot from the list.
        if out_slot in self.ts.occupancy[0][in_slot]:
            self.ts.occupancy[0][in_slot].remove(out_slot)
        # Only add it back in if it wasn't -1.
        # -1 is used as the 'reserve' slot id when beamforming.
        if out_slot != -1:
            # Add it back to the availables
            self.ts.available_ts[0][out_slot] = out_slot
        
        
    def get_info(self):
        
        """
        TODO
        
        """
        
            
