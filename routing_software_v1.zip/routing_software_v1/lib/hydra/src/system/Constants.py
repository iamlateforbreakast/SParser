"""-----------------------------------------------
 System constants used in HYDRA
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

# Import channeliser look up table.
# Kept seperate as it is a large file.
from lib.hydra.src.system.asic.internals._channeliser_lut import (demux_LUT, 
                                                                  mux_LUT)
from lib.hydra.src.system.asic.internals._eng_to_freq_id_lut import eng_to_freq_id
# from lib.hydra.src.system.asic.internals._freq_id_to_slot_lut import freq_id_to_slot


""" ASIC """
# PAGES
ASIC_PAGES = {0 : 'active_memory',
              1 : 'shadow_memory'}
# Converters (ADC & DAC)
ANTENNA_ELEMENTS_PER_CONVERTER = 1
TDMS_PER_CONVERTER = 8
CONVERTERS_PER_ASIC = 8

# Frequency bands [min,max] GHz
FREQUENCY_BANDS = {'Ka':[26.5,40],
                   'Ku':[12,18],
                   'C/X':[4,12]}

# Ports
NUM_PORTS_PER_ASIC = 64
DP_PORT_OFFSET = 0 # Physical ports for datapath SERDES 

# Relationship between polarisation and converter id
POL_TO_CONV = {'HORIZ': [i for i in range(0,CONVERTERS_PER_ASIC//2)],
               'VERT' : [i for i in range(CONVERTERS_PER_ASIC//2,CONVERTERS_PER_ASIC)]}

# BFN Block (memory map parameters)
MAX_TDMS_ISS = 150 # max useful
MAX_TDMS_OSS = 151
MAX_TIMESLOTS = 256 

# For DSC ASICs (input side, output side)
DSC_TDMS_ISS = (64, 80)
DSC_TIMESWITCHES = (80, 80)
DSC_TDMS_OSS = (80, 64)

DSC_TIMESLOTS = (256, 256)

# Rx TDMs from 0 - 63
# Tx TDMS from 64 - 127
DSC_TDM_OFFSET = {'rx': 0, 'tx': 64}

# For Sw, BFN ASICs (input side, output side)
BFN_TDMS_ISS = (128, 80)
BFN_ENGINES = (64, 64)
BFN_TIMESWITCHES = (16, 16)
BFN_TDMS_OSS = (80, 128)

BFN_TIMESLOTS = (256, 256)

BFN_ENG_OFFSET = 0 # BFN Engine TDMs from 0 - 63
BFN_TS_OFFSET = 64 # Parallel timeswitches TDMs from 64 - 79

# BFN BLOCK -> POLARISATION (which pol to which asic-half?)
POL_TO_BFN = {0 : 'HORIZ',
              1 : 'VERT'}

# For stagger pattern, assign frequency 'ID' to BFN engine
# and relative timeslots.
ENG_TO_FREQ_ID = eng_to_freq_id
# FREQ_ID_TO_SLOT = freq_id_to_slot


# Channeliser look up table (LUT), for DSCO and DSC1
CHANN_DEMUX_LUT = demux_LUT
CHANN_MUX_LUT = mux_LUT



""" DTPSystem """
# Config
SERDES_CONNECTIONS_PER_ASIC_PAIR = 2

# Gen5 ASIC Modes as defined in the config ICD.
# <g5t_asic_type> : (<asic_class_name>, <traffic_type>)
G5T_ASIC_MODES = {
    'RX_MOB'         : ('Rx','USER'),     'RX_GW'      : ('Rx','GW'),
    'TX_MOB'         : ('Tx','USER'),     'TX_GW'      : ('Tx','GW'),

    'RX_TX_MOB'      : ('RxTx','USER'),   
    'RX_TX_GW'       : ('RxTx','GW'),
    
    'RX_PLUS_MOB'    : ('RxPlus','USER'), 'RX_PLUS_GW' : ('RxPlus','GW'),
    'TX_PLUS_MOB'    : ('TxPlus','USER'), 'TX_PLUS_GW' : ('TxPlus','GW'),
    
    'RX_TX_PLUS_MOB' : ('RxTxPlus','USER'), 
    'RX_TX_PLUS_GW'  : ('RxTxPlus','GW'),
    
    'RX_BFN'         : ('RxBFN',''),       'TX_BFN'    : ('TxBFN',''),
    
    'SW'             : ('Sw',''),          'SW_HOP'    : ('SwHop',''),
    
    'CTRLASIC'       : ('CTRL', '')
    }

""" Beam """
# RX_ANTENNA_ELEMENTS = 72
# TX_ANTENNA_ELEMENTS = 96


""" Channel """


""" Link """


""" Managers """


""" SERDES """
# Data precision (bits) to TDM Slots
SERDES_SLOTS = {
    9: 256,
    10: 230,
    12: 192
    }

""" Signal """


""" Other """
