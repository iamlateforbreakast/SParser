"""-----------------------------------------------
 Class and functions for a path
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging


class STS_Path(object):

    def __init__(self, hydra_logger, asic, bfn_block, iss_route, ts_route, oss_route):
     
        """
        Constructor
        
        DESC

        
        @param hydra_logger: 
        @param asic:
        @param bfn_block: 
        @param iss_route: 
        @param ts_route:
        @param oss_route: 
        
        """
        
        # Initialise logger
        self.logger = hydra_logger
        
        # Set logger level
        if self.logger:
            self.logger.disabled = False
#             self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
        
        # Reference the ASIC
        self.asic = asic
        
        # Reference the ISS, TS, OSS 
        self.iss = bfn_block.iss
        self.ts = bfn_block.ts
        self.oss = bfn_block.oss
        
        # Route info
        # These dicts look like (for iss/oss):
        # {'in_tdm' : int(),
        #  'slot'   : int(),
        #  'out_tdm': int()}
        self.iss_route = iss_route
        self.ts_route = ts_route
        self.oss_route = oss_route
        
    def delete(self, target_page):
        
        """
        TODO
        
        """
        # Input spatial switch
        in_tdm = self.iss_route['in_tdm']
        slot = self.iss_route['slot']
        out_tdm = self.iss_route['out_tdm']
        # Remove the out_tdm from the list.
        self.iss.occupancy[in_tdm][slot].remove(out_tdm)
        # Add it back to the availables
        self.iss.available_tdms[slot][out_tdm] = out_tdm
        
        # Time switch
        in_slot = self.ts_route['in_slot']
        tdm = self.ts_route['tdm']
        out_slot = self.ts_route['out_slot']
        # Remove the out_tdm from the list.
        self.ts.occupancy[tdm][in_slot].remove(out_slot)
        # Add it back to the availables
        self.ts.available_ts[tdm][out_slot] = out_slot
        
        # Output spatial switch
        in_tdm = self.oss_route['in_tdm']
        slot = self.oss_route['slot']
        out_tdm = self.oss_route['out_tdm']
        # Remove the out_tdm from the list.
        self.oss.occupancy[in_tdm][slot].remove(out_tdm)
        # Add it back to the availables
        self.oss.available_tdms[slot][in_tdm] = in_tdm

    def get_info(self):
        
        """
        TODO
        
        """
        
class BFN_Path(object):

    def __init__(self, hydra_logger, asic, bfn_block, bfn_engine):
     
        """
        Constructor
        
        DESC

        
        @param hydra_logger: 
        @param uplink:
        @param downlink: 
        @param gain: 
        @param traffic_type:
        
        """
        
        # Initialise logger
        self.logger = hydra_logger
        
        # Set logger level
        if self.logger:
            self.logger.disabled = False
#             self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
            
        # Reference the ASIC
        self.asic = asic
        # Reference the BFN block
        self.bfn_block = bfn_block
        # Reference the BFN engine
        self.bfn_engine = bfn_engine 
        
        # Will have either ISS or OSS route also depending on traffic
        # type. Initialise, then allocate
        self.ss_route = None
        
        # Initialise set for storing Sample objects
        self.samples = set()
        
    def add_sample(self, sample):
        
        """
        TODO
        
        """
        
        self.samples.add(sample)
        
    def delete(self, target_page):
        
        """
        TODO
        
        """
        # Go through each of the samples in this path
        for _ in range(len(self.samples)):
            # Remove each sample from the main list
            samp = self.samples.pop()
            # Delete the route of the Sample
            samp.delete(target_page)
            
        # Also delete the route on the spatial switch
        # Spatial switch
        in_tdm = self.ss_route['in_tdm']
        slot = self.ss_route['slot']
        out_tdm = self.ss_route['out_tdm']
        # If Rx BFN
        if 'rx' in self.asic.name:
            # Remove the out_tdm from the list.
            self.bfn_block.oss.occupancy[in_tdm][slot].remove(out_tdm)
            # ENSURE WE REMOVE THIS SLOT FROM THE AVAILABLE LIST
            self.bfn_block.oss.available_tdms[slot][in_tdm] = in_tdm
        # If Tx BFN
        elif 'tx' in self.asic.name:
            # Remove the out_tdm from the list.
            self.bfn_block.iss.occupancy[in_tdm][slot].remove(out_tdm)
            # ENSURE WE REMOVE THIS SLOT FROM THE AVAILABLE LIST
            self.bfn_block.iss.available_tdms[slot][out_tdm] = out_tdm

        # Delete reference to samples
        del self.samples

    def get_info(self):
        
        """
        TODO
        
        """

class SERDES_Path(object):

    def __init__(self, hydra_logger, serdes, serdes_tdm, slot):
     
        """
        Constructor
        
        DESC

        
        @param hydra_logger: 
        @param serdes:
        @param slot: 
        
        """
        
        # Initialise logger
        self.logger = hydra_logger
        
        # Set logger level
        if self.logger:
            self.logger.disabled = False
#             self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
        
        # Reference the serdes
        self.serdes = serdes
        # Reference the serdes TDM (0 or 1)
        self.serdes_tdm = serdes_tdm
        # Reference the slot being occupied
        self.slot = slot
        
    def delete(self, target_page):
        
        """
        TODO
        
        """
        # Remove the SERDES slot (set it to None)
        self.serdes.occupancy[self.serdes_tdm][self.slot] = None

    def get_info(self):
        
        """
        TODO
        
        """
