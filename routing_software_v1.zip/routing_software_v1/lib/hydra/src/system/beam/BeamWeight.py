
class BeamWeight(object):
	
	def __init__(self, amplitude, phase):
		
		# Amplitude exponent
		self.amp_exp = amplitude[0]
		# Amplitude mantissa
		self.amp_mant = amplitude[1]
		
		# Phase (1024ths of a circle)
		self.phase = phase