
# from lib.hydra.src.system.antenna.AntennaElement import AntennaElement
# from lib.hydra.src.system.Constants import (RX_ANTENNA_ELEMENTS, 
# 										    TX_ANTENNA_ELEMENTS)


class Beam(object):
	
	def __init__(self):
		
		# Force Beam as an abstract type
		if type(self) == Beam:
			raise Exception("Beam is an abstract type")
		
	def get_element_count(self):
		
		if hasattr(self, 'elems'):
			return self.elems
		else:
			next(weight_set for weight_set in self.beamweights)
			self.elems = len(weight_set)
		
		
class RxBeam(Beam): 
	
	def __init__(self, beam_name, beam_id, beam_type, pol, beamweights):
				
		self.name = beam_name
		self.id = beam_id
		self.type = beam_type
		self.pol = pol
		self.beamweights = beamweights


class TxBeam(Beam): 
	
	def __init__(self, beam_name, beam_id, beam_type, pol, beamweights):
				
		self.name = beam_name
		self.id = beam_id
		self.type = beam_type
		self.pol = pol
		self.beamweights = beamweights
		