"""-----------------------------------------------
 Class and functions for Converters (ADC & DAC) 
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

# from lib.hydra.src.system.Constants import ANTENNA_ELEMENTS_PER_CONVERTER
# from lib.hydra.src.system.antenna.AntennaElement import AntennaElement
# from lib.hydra.src.system.asic.internals.ChanneliserLUT import *

#conv_BW = 3840 # MHz


class AbstractConverter(object):

    def __init__(self, conv_id, band, freq_range, lo_freq, dmix, channeliser):
        
        # Name converter
        self.name = f'{self.__class__.__name__}_{conv_id}'
        # ID converter
        self.id = conv_id
        
        # Initialise antenna element to the converter
        self.antenna_element = None
        # Initialise frequency band (Ku, Ka, C/X)
        self.band = band
        # Initialise frequency range GHz ([12,18], [26.5,40], [4,12])
        self.freq_range = freq_range
        # Initialise Local Oscillator (LO) frequency
        self.lo_freq = lo_freq
        # Initialise Digital Mixing frequency
        self.dmix = dmix
        # Initialise Channeliser
        self.channeliser = channeliser
        
        # TODO: update to include digital mixer setting (sum).
        self.f_fft0 = lo_freq
    
        if type(self) == AbstractConverter:
            raise Exception("AbstractConverter is an abstract type")
        
#     def __str__(self):
# #         pass
#         return self.name
        
    def get_sc_number(self, f_sc):
        
        # Function to get the sub-channel number using the frequency
        # of the sub-channel and the centre frequency of the 
        # converter.
        
        SC = int((f_sc - self.f_fft0)/2)
        # If negative, must add 1920
        if  SC < 0:
            SC += 1920
        
        return SC
        
class ADC(AbstractConverter):
    
    def __init__(self, conv_id, band, freq_range, lo_freq, dmix, channeliser):
        
        # Call the Abstract Class constructor
        super(ADC, self).__init__(conv_id, band, freq_range, lo_freq, dmix, channeliser)

        # Offset frequency depending on which ADC
        #self.freqOffset = converter_i*conv_BW        

    
class DAC(AbstractConverter):
    
    def __init__(self, conv_id, band, freq_range, lo_freq, dmix, channeliser):
        
        # Call the Abstract Class constructor
        super(DAC, self).__init__(conv_id, band, freq_range, lo_freq, dmix, channeliser)
        
        # Offset frequency depending on which ADC
        #self.freqOffset = converter_i*conv_BW

