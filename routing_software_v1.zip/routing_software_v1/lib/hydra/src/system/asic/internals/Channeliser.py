"""-----------------------------------------------
 Class and functions for a Channeliser.
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging

from lib.hydra.src.system.Constants import CHANN_DEMUX_LUT, CHANN_MUX_LUT


class Channeliser(object):
    
    def __init__(self, hydra_logger, chann_id, mode):
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)   
                
        self.id = chann_id
        
        self.mode = mode
        
        # Assign relevant look up table
        if self.mode == 'demux':
            self.LUT = CHANN_DEMUX_LUT
        elif self.mode == 'mux':
            self.LUT = CHANN_MUX_LUT
        
        self.occupancy = {}

    def get_slot(self, SC):

        # Find the coord from the LUT.
        # USING LIST TO GET COPY, NOT REFERENCE
        coord = list(self.LUT[SC])

        # Depending on which channeliser, must scale TDM
        # 8 TDMs per channeliser
        coord[0] += self.id*8
        
        # Get the correct resized timeslot value.
        # After every 15th slot, an extra empty slot must be added.
        # Divide the current value by 15, and add the floor of that
        # to the current timeslot.
        coord[1] += int(coord[1]/15)        
        
        # With this can now get the (TDM,slot) using
        # channeliser lookup table
        # returns a (TDM, TS)
        return tuple(coord)