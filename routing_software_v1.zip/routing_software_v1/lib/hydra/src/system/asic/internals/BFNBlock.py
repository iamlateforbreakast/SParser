"""-----------------------------------------------
 Class and functions for each BFN Block in an ASIC
 Rx/Tx/Sw ASICs will need sts_mode, and Rx/Tx BFNs
 will need bfn_mode (64 BFN Engines in
 parallel with 16 timeswitches). 

 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging

from lib.hydra.src.system.asic.internals.Switch import SpatialSwitch, TimeSwitch
from lib.hydra.src.system.asic.internals.BFNEngine import RxEngine, TxEngine
from lib.hydra.src.system.Constants import (DSC_TDMS_ISS, DSC_TIMESWITCHES, 
                                            DSC_TDMS_OSS, DSC_TIMESLOTS, 
                                            DSC_TDM_OFFSET, BFN_TDMS_ISS, 
                                            BFN_TDMS_OSS, BFN_ENGINES, 
                                            BFN_TS_OFFSET, BFN_TIMESLOTS,
                                            BFN_TIMESWITCHES)

class BFNBlock(object):
    
    def __init__(self, hydra_logger, mode):
    
        """ Constructor """

        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
        
        # One of rx_sts, tx_sts, sw_sts, rx_bfn, tx_bfn
        self.mode = mode.lower()
        
        # ------------------- Space-Time-Space mode -------------------
        if 'sts' in self.mode and len(self.mode) > 3:
            
            # Max timeslots available per TDM 
            slots = DSC_TIMESLOTS
            
            # For Rx or Tx mode ASICs
            if 'rx' in self.mode or 'tx' in self.mode:
                
                # Assign the correct input and output parameters for
                # each type of switch. Each of the ISS, TS and OSS have
                # an input side and an output side (as they are just
                # RAMs.
                
                # TDMs available on the input spatial switch input and
                # output side -> (input_tdmds, output_tdms)
                iss_tdms = DSC_TDMS_ISS
                # Number of timeswitches available, connecting the ISS
                # to the OSS -> (input_timeswitches, output_timeswitches)
                ts_tdms = DSC_TIMESWITCHES
                # TDMs available on the output spatial switch input and
                # output side -> (input_tdms, output_tdms)                
                oss_tdms = DSC_TDMS_OSS
                
                # The TDM alignment is different between Rx and Tx mode.
                # Rx mode use TDMs 0-63 for spatial switches,
                # Tx mode use TDMS 64-127 for spatial switches.
                offset = DSC_TDM_OFFSET[self.mode[0:2]]
            
            # For Sw mode ASICs
            elif 'sw' in self.mode:
                
                # As above, but specific to Sw mode.
                iss_tdms = BFN_TDMS_ISS
                ts_tdms = DSC_TIMESWITCHES
                oss_tdms = BFN_TDMS_OSS
                
                offset = None
            
            # Create each type of switch with the parameters specific
            # to the mode of ASIC.
            
            # Input spatial switch
            self.iss=SpatialSwitch(iss_tdms, slots, offset)
            # Time switch
            # Each individual timeswitch is list. 
            # The collective timeswitches are also a list, represented
            # by <ts>.
            self.ts=TimeSwitch(ts_tdms, slots)
            # Output spatial switch
            self.oss=SpatialSwitch(oss_tdms, slots, offset)
        
        # ------------------- BEAMFORMING mode -------------------
        elif 'bfn' in self.mode:
            
            iss_tdms = BFN_TDMS_ISS
            # NOTE: we build all 80 timeswitch, but only use 16 
            # externall to the engine. This is accomplished by using
            # the offset parameter.
            ts_tdms = DSC_TIMESWITCHES 
            oss_tdms = BFN_TDMS_OSS
            
            slots = BFN_TIMESLOTS
            
            offset = BFN_TS_OFFSET
            
            # First spatial switch
            self.iss=SpatialSwitch(iss_tdms, slots)
            # Time switch
            self.ts=TimeSwitch(ts_tdms, slots, offset)
            # Second spatial switch
            self.oss=SpatialSwitch(oss_tdms, slots)
            
            # Multiple ifs due to assigning consistent IDs across two bfn blocks.
            if 'rx' in self.mode:               
                # 64 BFN Engines
                self.bfns = [RxEngine(self.logger, i) for i in range(BFN_ENGINES[0])]

            elif 'tx' in self.mode:
                # 64 BFN Engines
                self.bfns = [TxEngine(self.logger, i) for i in range(BFN_ENGINES[0])]
            
            else:
                raise Exception("BFN engine creation failed.")
        
        else:
            raise Exception(f'Incorrect BFN block mode: {mode}')
        
        
        