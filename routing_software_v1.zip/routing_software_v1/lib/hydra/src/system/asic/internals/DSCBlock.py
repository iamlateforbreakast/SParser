"""-----------------------------------------------
 Class and functions for the DSC blocks.
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging

from lib.hydra.src.system.asic.internals.Channeliser import Channeliser
from lib.hydra.src.system.Constants import (CONVERTERS_PER_ASIC)


class DSC0(object):
    
    def __init__(self, hydra_logger):
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)        

        # Initialise channelisers
        self.channelisers = []
        
        for c_id in range(CONVERTERS_PER_ASIC):
            # Create the Channeliser
            c = Channeliser(self.logger, c_id, 'demux')

            # Add the channeliser to the master list
            self.channelisers.append(c)


class DSC1(object):
    
    def __init__(self, hydra_logger):
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)    
        
        # Initialise channelisers
        self.channelisers = []
        
        # Initialise channelisers
        self.channelisers = []
        
        for c_id in range(CONVERTERS_PER_ASIC):
            # Create the Channeliser
            c = Channeliser(self.logger, c_id, 'mux')

            # Add the channeliser to the master list
            self.channelisers.append(c)