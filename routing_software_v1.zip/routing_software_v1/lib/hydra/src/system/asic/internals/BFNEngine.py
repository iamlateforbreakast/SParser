"""-----------------------------------------------
 Class and functions for a BFN Engine inside each
 BFN ASIC.

 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging

from lib.hydra.src.system.asic.internals.Switch import TimeSwitch
from lib.hydra.src.system.asic.internals.MACC import MACC
from lib.hydra.src.system.Constants import BFN_TIMESLOTS
                         

class BFNEngine(object):
    
    def __init__(self, hydra_logger, eng_id):
        
        """ Constructor """

        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
            
        # Assign engine id
        self.id = eng_id
        # Assign engine name
        self.name = 'eng' + str(self.id)
        
        # Each engine has 1 timeswitch (position dependant on Rx or Tx)
        ts_tdms = [1,1];
        self.ts = TimeSwitch(ts_tdms, BFN_TIMESLOTS)
        
        # Each engine has 8 RAMs (modelled by timeswitch)
        ram_tdms = [8,8]
        self.rams = TimeSwitch(ram_tdms, BFN_TIMESLOTS)
        
        # Each engine has 8 MACCs
        self.maccs = [MACC() for _ in range(8)]
        
        # Initialise frequency (assigned by Routing using freq2bfn
        # yaml), and by stage 1/2 for stagger pattern
        # Each engine can be assigned up to 2 frequencies.
        # For the stagger pattern, each engine has frequency 'IDs'.
        # This relates the frequency to the elements and timeslots.
        self.frequency = ({'id': None, 'value': None, 'slots': dict()}, # 1st freq
                          {'id': None, 'value': None, 'slots': dict()}) # 2nd freq
        
        # Initialise selection variable
        self.is_selected = False
        
        # TODO: From the config file, one of 'OFF', '2BR', '8BR' (with
        # a prefix depending on rx/tx)
        self.bfn_state = 8
        
    def get_available_space(self):
        
        """
        TODO:
        
        """
        
        #
        
class RxEngine(BFNEngine):
    
    def __init__(self, hydra_logger, eng_id,):
        # RAMx8 - MACCx8 - TSx1
        
        # Call the parent (BFNEngine) constructor.
        super(RxEngine, self).__init__(hydra_logger, eng_id)
    
    
class TxEngine(BFNEngine):
    
    def __init__(self, hydra_logger, eng_id):
        # TSx1 - MACCx8 - RAMx8
        
        # Call the parent (BFNEngine) constructor.
        super(TxEngine, self).__init__(hydra_logger, eng_id)

