"""-----------------------------------------------
 Class and functions for type of switch
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""


class SpatialSwitch(object):
    
    def __init__(self, tdms, slots, offset=None):
            
        """ Constructor """
        
        # Maximum number of TDMs on input side
        self.tdms_in = tdms[0]
        # Maximum number of TDMs on output side
        self.tdms_out = tdms[1]
        
        # Maximum number of timeslots on input side
        self.slots_in = slots[0]        
        # Maximum number of timeslots on output side
        self.slots_out = slots[1]
        
        # Initialise collective list of spatial switches
        self.occupancy = []
        
        # For each slot, create an empty list which is <tdms> 
        # long.
        for _ in range(self.tdms_in):
            # Empty list because for multicasting, must be able to 
            # store all the information (rather than just one out TDM)
            self.occupancy.append([[] for _ in range(self.slots_in)])
        
        self.available_tdms = []
         
        for _ in range(self.slots_in):
            # Empty list because for multicasting, must be able to 
            # store all the information (rather than just one out TDM)
            self.available_tdms.append([i for i in range(max(self.tdms_in, self.tdms_out))])
        
#         print('SPATIAL')
#         print(f'tdms={self.tdms} | ts={self.ts} | max_size={self.max_size} | size={self.size}')
      
      
class TimeSwitch(object):
    
    def __init__(self, tdms, slots, offset=None):

        """ Constructor """
        
        # Maximum number of timeswitches (input and output sides 
        # always the same)
        self.no_of_timeswitches = tdms[0]
        
        # Maximum number of timeslots (input and output sides 
        # always the same)
        self.slots = slots[0]
        
        # BFN ASICs have 16 standalone timeswitches, with their TDMs
        # offset by 63. (i.e. 64->79 inclusive)
        # Not important when calculating routes, but important for
        # generating the correct commands to set the memory map.
        self.tdm_offset = offset
        
        # Each timeswitch represented by a list.
        # The total collective timeswitches also represented by a list.
        
        # Initialise collective list of timeswitches
        self.occupancy = []
        
        # For each timeswitch, create an empty list which is <slots> 
        # long.
        for _ in range(self.no_of_timeswitches):
            # Empty list because for multicasting, must be able to 
            # store all the information (rather than just one out slot)
            self.occupancy.append([[] for _ in range(self.slots)])
            
        self.available_ts = []
             
        for _ in range(self.no_of_timeswitches):
            # Empty list because for multicasting, must be able to 
            # store all the information (rather than just one out slot)
            self.available_ts.append([i for i in range(self.slots)])
            
#         print('TIME')
#         print(f'tdms={self.tdms} | ts={self.ts} | max_size={self.max_size} | size={self.size}')