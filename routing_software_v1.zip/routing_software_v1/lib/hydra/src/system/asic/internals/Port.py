"""-----------------------------------------------
 Class and functions for a Port (Out & In)
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""


class Port(object):
    
    def __init__(self, asic, port_i):
        
        """ Constructor """

        # Point to an asic
        self.asic = asic
        
        # Point to a serdes
        self.serdes = None
        
        # Port ID
        self.id = port_i
        
        # Helpful in identifying relation with 2 TDMs in a serdes.
        # One SERDES connects to one port, but two TDMs inside a 
        # SERDES
        self.operating_tdm = (port_i*2,(port_i*2)+1)
        

class InPort(Port):
    pass
    
    
class OutPort(Port):
    pass
        
    
