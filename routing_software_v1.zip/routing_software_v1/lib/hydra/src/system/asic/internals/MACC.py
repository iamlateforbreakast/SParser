"""-----------------------------------------------
 Class and functions for the MACC block
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""


# TODO:
class MACC(object):
    
    def __init__(self):
            
        """ Constructor """
        
        # Initialise weight variables
        self.amp_exp = None
        self.amp_mant = None
        self.phase = None
    
    def load_beamweight(self, subchannel):
        
        # Explicitly clear the previously set weights
        self.amp_exp = None
        self.amp_mant = None
        self.phase = None
        
        # Set new weights
        self.amp_exp = subchannel.amp[0]
        self.amp_mant = subchannel.amp[1]
        self.phase = subchannel.phase
    
    def multiply(self, subchannel):
        pass
    
    def accumulate(self):
        pass
    
    def output(self):
        pass