"""-----------------------------------------------
 Class and functions for a sub-channel
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging
from itertools import count


class SubChannel(object):

    def __init__(self, hydra_logger, sc_id, uplink_cf, downlink_cf):
     
        """
        Constructor
        
        DESC

        
        @param hydra_logger: 
        @param sc_id: 
        @param uplink_cf:
        @param downlink_cf: 
        
        """
        
        
        # Initialise logger
        self.logger = hydra_logger
        
        # Set logger level
        if self.logger:
            self.logger.disabled = False
#             self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
            
        # Assign sub-channel ID 
        self.id = sc_id
        
        # Reference uplink
        self.uplink_cf = uplink_cf
        # Reference downlink
        self.downlink_cf = downlink_cf
        
        # Initialise empty list for paths.
        # Will be at most 9 in length, with even numbers relating
        # to ASICs and odd numbers to SERDES. 
        self.paths = [None for _ in range(9)]
        
        
    def add_path(self, path_obj, pos):
        
        """
        TODO
        
        """  
        
        self.paths[pos] = path_obj
        
    def delete(self, target_page):
        
        """
        TODO
        
        """  
        
        # Go through each of the paths in this sub-channel
        for _ in range(len(self.paths)):
            # Remove each path from the main list
            p = self.paths.pop(0)
            if p:
                # Delete the contents of the path
                p.delete(target_page)

        # Delete reference to sub_channels
        del self.paths
        
    def get_info(self):
        
        """
        TODO
        
        """
        
            
