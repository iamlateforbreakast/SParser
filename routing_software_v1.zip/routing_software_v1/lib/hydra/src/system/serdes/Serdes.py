"""-----------------------------------------------
 Class and functions for Serdes
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""


# TODO: UNUSED SLOTS FOR DATA PRECISION (from spreadsheet).
# Add this to constants, and refer to it here to disable the
# correct timeslots for that data precision.
class Serdes(object):

    def __init__(self, link_id, source, sink):

        """ Constructor """

        # Assign source port
        self.source = source

        # Point source port to serdes 
        source.serdes = self

        # Assign sink port
        self.sink = sink

        # Point sink port to serdes
        sink.serdes = self

        # Initialise collective list of occupancy
        self.occupancy = []
        
        
        # Link id number
        self.id = link_id
        
        # Label for serdes -> 'Serdes_{leftAsic}_{port}_{rightAsic}_{port}'
        self.name = (f'{self.id}__{self.source.asic.name}_' + 
                     f'outport{source.id}_to_{self.sink.asic.name}_' + 
                     f'inport{sink.id}').lower()           

    def __str__(self):
        
        return self.name
    
    def update_data_precision(self, size):
        
        # Assign size of Serdes
        self.size = size
        
        # Serdes made up of 2 TDMs internally, modelled similar to TS
        # For each TDM, create an empty list which is <size> long.
        for _ in range(2):
            self.occupancy.append([None for _ in range(self.size)])
    
    def get_occupancy(self):
         
        tdm_occ = dict()
         
        for TDM in self.occupancy:
             
            occ_counter = 0
             
            for slot in TDM:
                 
                if slot != None:
#                     print(occ_counter)
                    occ_counter += 1
             
            tdm_occ[self.occupancy.index(TDM)] = occ_counter
         
        # Nuance with index func, if identical returns 0.
        # Fix: If there is only one key, duplicate its value to '1'.
        if len(tdm_occ) == 1:
            tdm_occ[1] = tdm_occ[0]
         
        return tdm_occ
                    