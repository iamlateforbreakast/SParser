"""-----------------------------------------------
 Class and functions for a channel
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging
from itertools import count


class Channel(object):
    
    # Initialise counters for channel ids and spare ids (from deleted 
    # channels)
    _chan_id = count(0)
    _spare_ids = set()

    def __init__(self, hydra_logger, chan_id, uplink, downlink, gain, traffic_type):
     
        """
        Constructor
        
        DESC

        
        @param hydra_logger: 
        @param chan_id: 
        @param uplink:
        @param downlink: 
        @param gain: 
        @param traffic_type:
        
        """
        
        
        # Initialise logger
        self.logger = hydra_logger
        
        # Set logger level
        if self.logger:
            self.logger.disabled = False
#             self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
            
        # Assign channel ID if provided
        if chan_id:
            self.id = chan_id
        # If not provided, use incrementing scheme with traffic type
        else:
            # Setup Channel numerical ID
            # If there are unused IDs, use the next one
            if type(self)._spare_ids:
                num_id = type(self)._spare_ids.pop()
            # Otherwise, increment
            else:
                num_id = next(type(self)._chan_id)
            
            self.id = f'{traffic_type}-{num_id}'
        
        # Reference uplink
        self.uplink = uplink
        # Reference downlink
        self.downlink = downlink
        
        # Reference gain
        self.gain = gain
        
        # Reference traffic_type
        self.traffic_type = traffic_type
        
        # Initialise empty set for sub-channels
        self.sub_channels = set()
        
    def add_sub_channel(self, sub_channel):
        
        """
        TODO
        
        """  
        
        # Add the sub-channel to the set
        self.sub_channels.add(sub_channel)
        
    
    def delete(self, target_page):
        
        """
        TODO
        
        """  
        
        # Go through each of the sub-channels in this channel.
        for _ in range(len(self.sub_channels)):
            # Remove each sub-channel from the main set
            sc = self.sub_channels.pop()
            # Delete the contents of the sub-channel
            sc.delete(target_page)

        # Delete reference to sub_channels
        del self.sub_channels
        
    def get_info(self):
        
        """
        TODO
        
        """
        
            
