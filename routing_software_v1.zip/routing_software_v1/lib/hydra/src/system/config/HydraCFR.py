
from lib.shared.config.config_file_reader_base import ConfigFileReaderBase


class HydraCFR(ConfigFileReaderBase):
    
    """ Routing Algorithm implementation of config file reader """
    
    def __init__(self, dtp):
        
        """ Constructor """
        
        self.dtp = dtp
        
    # TODO:
    def add_definitions(self, **kwargs):
        
        """
        Function called by 'load' to add definitions - to
        be overridden by subclass (or not)
        
        @param kwargs: dict of kw-arguments for the dual-module,
            from configuration file
        """
        
        self.g5t_asic_modes = kwargs.get('g5t_asic_modes', dict())
    
    def add_node(self, dual_module_id, module_name, pcb_pos, **kwargs):
        
        """
        Function called by 'load' to add a node (ASIC
        or FPGA)
        
        @param **kwargs: dict of kw-arguments for node,
            from configuration file
        """
        
        if 'CTRL' in kwargs['type']:
            pass
        else:
            node_internals = self.g5t_asic_modes.get(kwargs['type'], dict())
            
            self.dtp.add_asic(kwargs['type'], 
                              node_internals,
                              kwargs['name'])
        
    def add_serdes(self, **kwargs):
        
        """
        Function called by 'load' to add a SERDES link
        
        @param **kwargs: dict of kw-arguments for SpW link,
            from configuration file
        """
        
        # Filter number from link name (returns a list)
        #link_id = re.findall(r'\d+', kwargs['name'])
                
        # Make sure reader ignores ctrl module asics (CHECK which ids 
        # might be used for ctrl modules)
        if 'ctrl' in kwargs['src_node'] or 'ctrl' in kwargs['sink_node'] \
        or 'fpga' in kwargs['src_node'] or 'fpga' in kwargs['sink_node']:
            pass
        else:
            self.dtp.add_serdes(
                kwargs['name'],
                kwargs['src_node'],
                kwargs['src_port'],
                kwargs['sink_node'],
                kwargs['sink_port']
                )
            
    def add_antenna_element(self, **kwargs):
        
        """
        Function called by 'load' to add antenna configurations
        
        @param kwargs: dict of kw-arguments for antenna config,
            from configuration file
        """
        
        # Check if polarisation specified
        pol = kwargs.get('polarisation')
        
        self.dtp.add_antenna_element(kwargs['element'],
                                     kwargs['band'],
                                     kwargs['asic'],
                                     kwargs['type'],
                                     kwargs['converter'],
                                     kwargs['conjugate'],
                                     kwargs['lo_freq'],
                                     pol)
        
    def set_state_bfn_mode(self, **kwargs):
        
        """
        Function called by 'load' to set BFN modes per node type,
        from 'state' attribute 
        
        @param kwargs: dict of kw-arguments for antenna config,
            from configuration file
        """
        
        self.dtp.set_bfn_state(kwargs['rx_bfn'],
                               kwargs['tx_bfn'])
        
#         # Remove these args for now, not beamforming so no need to 
#         # set the mode.
#         kwargs.pop('ctrl', [])
#         kwargs.pop('rx', [])
#         kwargs.pop('sw', [])
#         kwargs.pop('tx', [])

    def set_state_data_format(self, **kwargs):
        
        """
        Function called by 'load' to set data formats per rank-pair,
        from 'state' attribute - to be overridden by subclass (or not)
        
        @param kwargs: dict of kw-arguments for data format between
            a single pair of ranks, from configuration file
        """
        
        self.dtp.set_data_format(kwargs['from_rank'],
                                 kwargs['to_rank'],
                                 kwargs['precision'])
        
            