"""-----------------------------------------------
 Class and functions for the DTP system, including
 building from a config file and generating serdes
 links.
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""

import logging
import os
import sys

from lib.hydra.src.system.asic.Rx import Rx
from lib.hydra.src.system.asic.RxBFN import RxBFN
from lib.hydra.src.system.asic.Sw import Sw
from lib.hydra.src.system.asic.TxBFN import TxBFN
from lib.hydra.src.system.asic.Tx import Tx
from lib.hydra.src.system.asic.RxTx import RxTx
from lib.hydra.src.system.antenna.AntennaElement import (RxAntennaElement,
                                                         TxAntennaElement)
from lib.hydra.src.system.asic.internals.AbstractConverter import ADC, DAC
from lib.hydra.src.system.serdes.Serdes import Serdes
#from lib.hydra.src.managers.AlgoManager import AlgoManager
from lib.hydra.src.operator.managers.BeamManager import BeamManager
from lib.hydra.src.system.config.HydraCFR import HydraCFR
from lib.hydra.src.system.Constants import (G5T_ASIC_MODES, DP_PORT_OFFSET, 
                                            SERDES_CONNECTIONS_PER_ASIC_PAIR,
                                            FREQUENCY_BANDS, SERDES_SLOTS)


class DTPSystem(object):
    
    def __init__(self, hydra_logger, config_path):
        
        """
        Constructor
        
        Builds the DTP system based on the specified configuration
        file, starts up the system_manager (responsible for routing 
        funcs), and sets up the relevant logging (to console/file).
        
        @param hydra_logger: hydra logger instance passed down,
        @param config_path: absolute path or name of the YAML
            configuration file. If name, searches for that file
            inside hca/config. Raises an exception if specified
            file path is invalid, or file is not of YAML format,       
        """
        
        # Initialise logging
        self.logger = hydra_logger
         
        # Set logger level
        if self.logger:
            self.logger.disabled = False
            self.logger.setLevel(logging.DEBUG)
        else:
            logging.disable(logging.CRITICAL)
            
        # Create empty lists for asic ranks
        # (Rx rank, Sw rank etc..)
        self.rxs = list()
        self.sws = list()
        self.txs = list()
        self.rxbfns = list()
        self.txbfns = list()
        
        # Create empty list for serdes
        self.serdes = list()
        
        # Create empty set for antenna elements
        self.antenna_elements = set()
        
        # Create empty set for gateway antennas
        self.gateway_antennas = set()
            
        # Initialise cfg file reader
        cfr = HydraCFR(self)
        
        if self.logger:
            self.logger.info("Building system...")
        
        # Load config using absolute path
        cfr.load(config_path)
                
        # Can also use '{type(self.rxs[0]).__name__}' here instead.
        if self.logger:
            if self.rxs:
                self.logger.info(f"Created {len(self.rxs)} Rxs,") 
            if self.rxbfns:
                self.logger.info(f"Created {len(self.rxbfns)} RxBFNs,")
            if self.sws:   
                self.logger.info(f"Created {len(self.sws)} Sws,")
            if self.txbfns:
                self.logger.info(f"Created {len(self.txbfns)} TxBFNs,")
            if self.txs:
                self.logger.info(f"Created {len(self.txs)} Txs,")
                
            self.logger.info(f"Created {len(self.antenna_elements)} Antenna Elements,")
            
            self.logger.info(f"Created {len(self.gateway_antennas)} Gateway Antennas,")
                
            self.logger.info(f"Created {len(self.serdes)} Serdes.")      
            
        # Assign a master dict to the DTP system.
        # Help in identifying ranks of system for different configs
        # (i.e. flight 5-rank or other test).
        # [DROP 1] 5-rank = flight, any other is test  
        self.master_asic_dict = dict()
        if self.rxs:
            self.master_asic_dict['rx'] = self.rxs
            
        if self.txs:
            self.master_asic_dict['tx'] = self.txs
            
        if self.rxbfns:
            self.master_asic_dict['rxbfn'] = self.rxbfns
            
        if self.txbfns:
            self.master_asic_dict['txbfn'] = self.txbfns
            
        if self.sws:
            self.master_asic_dict['sw'] = self.sws
            

        
    def add_asic(self, asic_type, node_internals, node_name):
        
        # Process <asic_type> in order to create an ASIC in the
        # corresponding mode.
        try:
            asic_to_create = G5T_ASIC_MODES[asic_type][0]
        except:
            raise ValueError(f'Refer to G5T_ASIC_MODES in config ICD.'
                             f'Asic type: {asic_type} not found.')
        
        # Use the name of the ASIC to get the Class name
        new_asic = getattr(sys.modules[__name__], asic_to_create)
        
        # Create an instance of <new_asic>
        # TODO: IMPLEMENT NODE INTERNALS
        # <node_internals> contains the dictionary with all the 
        # relevant blocks and their makeup (i.e. which blocks are 
        # enabled or disabled, or how they operate).
        # <new_asic(self.logger, node_name, node_internals, asic_type)>
        asic_instance = new_asic(self.logger, node_name, asic_type)
        
#         print(asic_to_create.lower())
        
        # Append the asic to the relevant list (ranks)
        if 'rxtx' in asic_to_create.lower():
            self.rxs.append(asic_instance.rx)
            self.txs.append(asic_instance.tx)
        
        elif 'rx' in asic_to_create.lower() and not 'bfn' in asic_to_create.lower():
            self.rxs.append(asic_instance)
            
        elif 'tx' in asic_to_create.lower() and not 'bfn' in asic_to_create.lower():
            self.txs.append(asic_instance)
                   
        elif 'rxbfn' in asic_to_create.lower():
            self.rxbfns.append(asic_instance)
               
        elif 'txbfn' in asic_to_create.lower():
            self.txbfns.append(asic_instance)
            
        elif 'sw' in asic_to_create.lower():
            self.sws.append(asic_instance)
         
        else:
            raise ValueError(f'Unsupported ASIC type: {asic_type}')      

    def add_serdes(self, link_id, source_node, source_port, sink_node, sink_port):
        
        # Keep an eye out, this might cause errors in system building
        # Create search list for the correct source_node
        if 'rx' in source_node and not 'bfn' in source_node:
            src_search_list = self.rxs
        else:
            src_search_list = self.sws + self.rxbfns + self.txbfns
            
#         if link_id == 'sd480':
#             
#             print(link_id, source_node, source_port, sink_node, sink_port)
#             for rx in src_search_list:
#                 print(rx.name)
            
        # Create search list for the correct sink_node
        if 'tx' in sink_node and not 'bfn' in sink_node:
            sink_search_list = self.txs
        else:
            sink_search_list = self.sws + self.rxbfns + self.txbfns
            
        # Check if asics are present
        if src_search_list and sink_search_list:
            
            # Select relevant source/sink asic based on id
            source_asic = next(asic for asic in src_search_list 
                               if asic.name == source_node)
            sink_asic = next(asic for asic in sink_search_list 
                             if asic.name == sink_node)
            
            # Create a serdes 
            s = Serdes(link_id, 
                       source_asic.out_ports[source_port], 
                       sink_asic.in_ports[sink_port])
            
            if self.logger:
                self.logger.debug(f"Creating {s}")
            
            self.serdes.append(s)
        
        else:
            raise ValueError("No ASICs present in system.")
    
    def add_antenna_element(self, element_id, freq_band, asic_name, elem_type, 
                            conv_id, conjugate, lo_freq, pol):     
        
        # Group DSC ASICs present in system
        if elem_type == 'RX':
            asic_search_list = self.rxs
        elif elem_type == 'TX':
            asic_search_list = self.txs
            
        # Find the ASIC object (from the given ASIC name)
        asic_obj = next(asic for asic in asic_search_list if asic.name == asic_name)
        
        # Create converter object
        conv_obj = self.add_converter(asic_obj, 
                                      conv_id,
                                      elem_type,
                                      freq_band,
                                      FREQUENCY_BANDS[freq_band],
                                      lo_freq)
        
        # Find the Converter object (from the given ID)
        if type(asic_obj) == Rx:
            
            # Create rx antenna element with given id and deduced info
            elem = RxAntennaElement(element_id, pol, elem_type, asic_obj, conv_obj)
            
        elif type(asic_obj) == Tx:

            # Create tx antenna element with given id and deduced info
            elem = TxAntennaElement(element_id, pol, elem_type, asic_obj, conv_obj)
        
        # Point converter to element
        conv_obj.antenna_element = elem
        
        if elem.id >= 0:
            self.antenna_elements.add(elem)
            
        elif elem.id < 0:
            self.gateway_antennas.add(elem)
        
        if self.logger:
            self.logger.debug(f"Creating element {elem.id, pol, conv_obj.lo_freq}")
    
    def set_bfn_state(self, rxbfn_state, txbfn_state):
        # TODO, removed for now as not needed 
        pass
        # Set RxBFN engine states
#         for rxbfn in self.rxbfns:
#             
#             for bfn_engine in rxbfn.switch_network.bfns:
#                 bfn_engine.bfn_state = rxbfn_state
# 
#         # Set TxBFN engine states
#         for txbfn in self.txbfns:
#             
#             for bfn_engine in txbfn.switch_network.bfns:
#                 bfn_engine.bfn_state = txbfn_state

    def set_data_format(self, from_rank, to_rank, data_precision):
        
        # Assign the correct TDM size to each SERDES based on data
        # precision
        for s in self.serdes:
            
            # If the serdes matches the requested from and to ranks,
            # assign that data precision/size.
            if s.source.asic.mode == from_rank and s.sink.asic.mode == to_rank:
                
                s.update_data_precision(SERDES_SLOTS[data_precision])
            
            # Otherwise move to the next serdes
            else:
                continue
    
    def add_converter(self, asic, conv_id, conv_type, band, freq_range, lo_freq, dmix=None):

        if conv_type == 'RX':
            
            # Find relevant channeliser
            channeliser = asic.dsc_blk_0.channelisers[conv_id]
            
            c = ADC(conv_id, band, freq_range, lo_freq, dmix, channeliser)
            
            asic.adcs.append(c)
            
        elif conv_type == 'TX':
            
            # Find relevant channeliser
            channeliser = asic.dsc_blk_1.channelisers[conv_id]
            
            c = DAC(conv_id, band, freq_range, lo_freq, dmix, channeliser)
            
            asic.dacs.append(c)
        
        else:
            raise Exception("Failed to create converter")
        
        return c

                