"""-----------------------------------------------
 Class and functions for the basic sanity test
 supplied with v1. Uses the unittest framwork.
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Stelios Souvaliotis
-----------------------------------------------"""
import unittest
from itertools import count

from lib.hydra.src.Hydra import Hydra

TOTAL_RX_ASICS = 22
TOTAL_RXBFN_ASICS = 12
TOTAL_SW_ASICS = 2
TOTAL_TXBFN_ASICS = 12
TOTAL_TX_ASICS = 21

TOTAL_SERDES = 1224

TOTAL_RX_HORIZ = 78
TOTAL_RX_VERT = 78
TOTAL_TX_HORIZ = 78
TOTAL_TX_VERT = 78

TOTAL_RX_GW = 12
TOTAL_TX_GW = 4

class BasicSanityTest(unittest.TestCase):
    
    @classmethod
    def setUpClass(cls):
        cls.hydra = Hydra(r"..\..\..\..\config\onesat_dtp_arch_a.yml",
                           console_log = True, 
                           file_log = True,
                           use_dcm = False)
        
        cls.hydra.operator.load_beams('test_8_elems.yaml')
    
    def tearDown(self):
        pass
               
    def test_check_asics(self):
        # Check the amount of each ASIC aligns with the expected.
        # How many Rx?
#         print(cls.hydra)
        num_rx = len(BasicSanityTest.hydra.dtp.rxs)
        self.assertEqual(num_rx, TOTAL_RX_ASICS, "Missing Rx ASICs")
        
        # How many Rx BFN?
        num_rx = len(BasicSanityTest.hydra.dtp.rxbfns)
        self.assertEqual(num_rx, TOTAL_RXBFN_ASICS, "Missing Rx BFN ASICs")
        
        # How many Sw?
        num_rx = len(BasicSanityTest.hydra.dtp.sws)
        self.assertEqual(num_rx, TOTAL_SW_ASICS, "Missing Sw ASICs")
        
        # How many Tx BFN?
        num_rx = len(BasicSanityTest.hydra.dtp.txbfns)
        self.assertEqual(num_rx, TOTAL_TXBFN_ASICS, "Missing Tx BFN ASICs")
        
        # How many Tx?
        num_rx = len(BasicSanityTest.hydra.dtp.txs)
        self.assertEqual(num_rx, TOTAL_TX_ASICS, "Missing Tx ASICs")
        
    def test_check_serdes(self):
        # Check the amount SERDES aligns with expected
        # How many SERDES?
        num_serdes = len(BasicSanityTest.hydra.dtp.serdes)
        self.assertEqual(num_serdes, TOTAL_SERDES, "Missing SERDES")

    def test_check_elements(self):
        # Check the amount of elements aligns with the expected.
        
        # Count the Rx elements
        rx_horiz_count = 0
        rx_vert_count = 0
        tx_horiz_count = 0
        tx_vert_count = 0
        
        for elem in BasicSanityTest.hydra.dtp.antenna_elements:
            if elem.type == 'RX' and elem.pol == 'HORIZ':
                rx_horiz_count += 1
                
            elif elem.type == 'RX' and elem.pol == 'VERT':
                rx_vert_count += 1
                
            elif elem.type == 'TX' and elem.pol == 'HORIZ':
                tx_horiz_count += 1
                
            elif elem.type == 'TX' and elem.pol == 'VERT':
                tx_vert_count += 1
                
        self.assertEqual(rx_horiz_count, TOTAL_RX_HORIZ, 'Missing Rx horizontal polarised elements')                
        self.assertEqual(rx_vert_count, TOTAL_RX_VERT, 'Missing Rx vertical polarised elements')                
        self.assertEqual(tx_horiz_count, TOTAL_TX_HORIZ, 'Missing Tx horizontal polarised elements')                
        self.assertEqual(tx_vert_count, TOTAL_TX_VERT, 'Missing Tx vertical polarised elements')
        
        rx_gw_count = 0
        tx_gw_count = 0
        for gw in BasicSanityTest.hydra.dtp.gateway_antennas:
            if gw.type == 'RX':
                rx_gw_count += 1
            elif gw.type == 'TX':
                tx_gw_count += 1

        self.assertEqual(rx_gw_count, TOTAL_RX_GW, 'Missing Rx gateway antennas')                
        self.assertEqual(tx_gw_count, TOTAL_TX_GW, 'Missing Tx  gateway antennas') 
           
    def test_create_user_channel(self):
        user_uplink = BasicSanityTest.hydra.operator.link_manager.generate_link('user_up_1', 'rx_beam_8_elem', 30150, 100)
        user_downlink = BasicSanityTest.hydra.operator.link_manager.generate_link('user_down_1', 'tx_beam_8_elem', 30150, 100)
        
        # Gain must be set to None for drop 1.
        target_gain = None
        # Set the target page for the request.
        target_page = 0
        
        BasicSanityTest.hydra.create_channel('USER_CHANN_1', user_uplink, user_downlink, target_gain, target_page)

            
if __name__ == '__main__':
    
    unittest.main()