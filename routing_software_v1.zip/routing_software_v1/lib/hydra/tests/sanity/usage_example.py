
# Import Hydra modules
from lib.hydra.src.Hydra import Hydra

# Absolute or relative path to the config file
hydra = Hydra(r"..\..\..\..\config\onesat_dtp_arch_a.yml",
              console_log = True, 
              file_log = True,
              use_dcm = False)

# Here, specify the beams to be loaded. This process is quite slow,
# as the information is very large. 
# NOTE: 8 Element beams are good for quick test purposes
# because they load fast, but not a very realistic beam.
hydra.operator.load_beams('test_8_elems.yaml')

# Generate a link with the information.
# If it is a beam, the string must be identical to that of the one 
# in the beam config file that has been specified. These are located in 
# "lib/hydra/config/beams/"
# The uplink and downlink centre frequencies must satisfy what has been
# specified in the config file for converter LO freqs (width must also 
# fit in the bandwidth). Please specify in MHz.
test_link_1 = hydra.operator.link_manager.generate_link('uplink_1', 'rx_beam_8_elem', 30180, 100)
test_link_2 = hydra.operator.link_manager.generate_link('downlink_1', 'tx_beam_8_elem', 30220, 100)

# Gain must be set to None for drop 1.
target_gain = None
# Set the target page for the request.
target_page = 0

# Run the create command with the specified Channel ID (string).
hydra.create_channel('USER_CHANNEL_1', test_link_1, test_link_2, target_gain, target_page)
