## @package logging

## @copyright Copyright 2020, 2021 Airbus Defence & Space Ltd.
## @author wallis_s
## @brief
## This package defines a GEN5 logging class to be used within
## the different APIs and the software layer above
 
import logging
import os
from time import strftime

from lib.shared.hca_logger.hca_rotating_file_handler import (
        HCARotatingFileHandler)

def _get_filepath(filedir, filename):
    
    """
    Convenience function to join a file directory and file name into
    a single path.
    
    @param filedir: the directory of the file (absolute or relative),
        does not check if the directory is valid. A falsey value means
        current working directory (cwd)
    @param filename: the name of the file, may include placeholder
        %(timestamp)s to insert current timestamp. A falsey value means
        the default 'log-%(timestamp)s.log' is used
    @return: the full, formatted filepath
    """
    
    timestamp = strftime("%Y-%m-%d-%H%M%S")
    return os.path.abspath(os.path.join(
            filedir or os.getcwd(),
            (filename or 'log-%(timestamp)s.log') % {'timestamp': timestamp}
            ))


class HCALogger(logging.Logger):
    
    """
    Logger subclass specifically suited for Gen5 control software
    development. Inheritance from logging.Logger means all of its powerful
    logging functions are accessible, as well as special features such as
    controlling logging levels for different modules.
    
    Before creating any instance, class variables (e.g. log to file/log
    to console flags, file paths, logging levels etc.) must be initialised
    using HCALogger.setup. Every instance is initialised with a copy of the
    class variables - some of these (e.g. logging level, TBD) may be changed
    at runtime, allowing different logging configurations for each API.
    
    Correct operation assumes single-threaded usage.
    
    Example set up and instantiation:
    >>> HCALogger.setup(log_to_console = True, level = logging.INFO)
    >>> my_hca_logger = HCALogger(__name__)
    """
    
    # ----- Class variables ----- #
    
    ## Logging setup variables (initialise using HCALogger.setup)
    ##
    ## _FORMATTER - formatter: if we can agree to this format let's leave it
    ## _level: initial logging level for logger and handlers (int)
    ## _log_to_file: log to a file (boolean)?
    ## _log_to_console: log to console (boolean)?
    ## _filedir, _filename: file directory & name, if logging to a file (str)
    ## _setup: class variables set up (i.e. HCALogger.setup run)?
    
    _FORMATTER = logging.Formatter('%(asctime)s :: %(name)s :: '
                                   '%(levelname)s :: %(message)s')
    _level = None
    _log_to_file = None
    _log_to_console = None
    _full_filepath = None
    _setup = False
    
    # ----- Constructor ----- #
    
    def __init__(self, name):
        
        """
        Constructor. The instance's logging configuration is initialised
        with the class variables (these must be set up beforehand using
        HCALogger.setup)
        
        @param name: the logger name
        """
        
        # HCALogger must be set up beforehand
        
        if not HCALogger._setup:
            raise RuntimeError('HCALogger must be set up before use')
        
        # logging.Logger constructor
        
        super().__init__(name, level = HCALogger._level)
        
        # Logging variables, copy from class variables - these
        # can be changed later to allow APIs to have different
        # logging configurations
        
        self._level = HCALogger._level
        self._log_to_file = HCALogger._log_to_file
        self._log_to_console = HCALogger._log_to_console
        self._full_filepath = HCALogger._full_filepath
        
        # Set up handlers
        
        if self._log_to_file:
            # HCA rotating file handler
            rfh = HCARotatingFileHandler.get_for_file(self._full_filepath)
            self.addHandler(rfh)
        
        if self._log_to_console:
            # Stream handler - display on console           
            sh = logging.StreamHandler()
            self.addHandler(sh)
        
        # Set the handlers' logging levels to the lowest (let the
        # logger object fully control the logging level), and add
        # the formatter to each of them
        
        for hdlr in self.handlers:
            hdlr.setFormatter(HCALogger._FORMATTER)
            hdlr.setLevel(logging.NOTSET)
    
    # ----- Setup ----- #
    
    @classmethod
    def setup(cls, **kwargs):
        
        """
        Class method to set up the default logging environment. Must be
        called before creating any HCALogger instance. Can only be called
        once (ideally at startup of top-level control software).
        
        When an instance of HCALogger is created afterwards, it takes
        its own copy of the class variables. This allows different APIs
        to initially log to the same targets, and allows their configurations
        to be individually tailored at runtime.
        
        @param **kwargs: (dict) keyword arguments that can be a subset of:
            level: (int) initial logging level for logger and all its
                handlers (default: logging.INFO)
            log_to_file: (bool) log to file? (default: False)
            log_to_console: (bool) log to console? (default: False)
            filedir: (str) path - relative or absolute - to logging file
                directory. If log_to_file = True, default is os.getcwd()
                if not specified. Otherwise, directory is created
                automatically if it doesn't exist. If log_to_file = False,
                this should not be specified
            filename: (str) name of file, including extension. May include
                the placeholder %(timestamp)s to include the current
                timestamp (default: 'logfile.log')
        @raises ValueError if sanity checks do not pass:
            - If not logging to a file, filedir/filename must not be
                specified
            or RuntimeError if setup has already occurred
        """
        
        # Already set up?
        
        if cls._setup:
            raise RuntimeError('HCALogger permits only one setup')
        
        # Pop our kwargs
        
        level = kwargs.pop('level', logging.INFO)
        log_to_file = kwargs.pop('log_to_file', False)
        log_to_console = kwargs.pop('log_to_console', False)
        filedir = kwargs.pop('filedir', None)
        filename = kwargs.pop('filename', None)
        
        # Sanity checks
        
        if kwargs:
            raise ValueError(f'Got unexpected keyword args: '
                             f'{", ".join(kwargs.keys())}')
        
        if not log_to_file:
            # Specified directory/filename, but log to file is disabled?
            if filedir or filename:
                raise ValueError('File directory and filename must not be '
                                 'specified if not logging to file')
        else:
            if filedir and not os.path.exists(filedir):
                os.mkdir(filedir)
            # Set the file path class variable
            cls._full_filepath = _get_filepath(filedir, filename)
        
        # Set the rest of the class variables
        
        cls._level = level
        cls._log_to_file = log_to_file
        cls._log_to_console = log_to_console
        cls._setup = True
        
        # Set this class as our logging class
        
        logging.setLoggerClass(cls)
    
    # ----- Individual log configuration methods ----- #
    
    def change_log_file(self, filedir = None, filename = None):
        
        """
        Change logging file destination, if logging to a file. Removes
        the file handler from self.handlers, if necessary, and adds a
        new one to the new file
        
        @param filedir: path of log directory (absolute or relative)
            (default is None -> no change)
        @param filename: name of log file (including extension)
            (default is None -> no change)
        @raises RuntimeError if not logging to a file, or
            ValueError for non-existing file directory
        """
        
        # Sanity checks
        
        if not self._log_to_file:
            raise RuntimeError('Not logging to file in logger setup')
        
        if filedir is filename is None:
            raise ValueError('Must specify at least one of filedir or filename')
        
        # File directory
        
        if filedir and not os.path.exists(filedir):
            os.mkdir(filedir)
        
        # Shortcut if file path is same as previous
        
        new_full_filepath = _get_filepath(filedir, filename)
        if new_full_filepath == self._full_filepath:
            return
        
        # Get the rotating file handler (assuming there's exactly one)
        
        old_rfh = next(hdlr for hdlr in self.handlers
                       if isinstance(hdlr, HCARotatingFileHandler))
        
        # Remove old handler from list, add new one
        
        new_rfh = HCARotatingFileHandler.get_for_file(new_full_filepath)
        self.removeHandler(old_rfh)
        self.addHandler(new_rfh)
        
        # Finally...
        
        self._full_filepath = new_full_filepath
