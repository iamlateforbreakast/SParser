
"""------------------------------------------------------
 CLI class and functions for the main application HCA
 implementation of logging.handlers.RotatingFileHandler
 
 Example usage:
 >>> rfh = HCARotatingHandler.get_for_file('example.log')
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Sam Wallis
------------------------------------------------------"""

from logging.handlers import RotatingFileHandler

class HCARotatingFileHandler(RotatingFileHandler):
    
    """
    HCA implementation of logging.handlers.RotatingFileHandler
    
    Instances should be obtained with 'get_for_file': if a file
    handler instance already points to the requested file, it
    returns that instance, rather than creating a new one.
    Otherwise, it will return a new one.
    
    This is designed as a workaround for a concurrency issue in
    Windows. See https://bugs.python.org/issue25121.
    """
    
    # Rotation variables - max number of bytes, and backup count
    
    _MAX_BYTES = 64e6
    _BACKUP_COUNT = 200
    
    # Set of instances for this class
    
    _instances = set()
    
    @classmethod
    def get_for_file(cls, filename):
        
        """
        Factory method to return an existing handler if it uses
        the specified filename, otherwise create a new one and
        return that instance
         
        @param filename: logging filename (including extension)
        """
        
        # Search for existing handlers to specified file
        for instance in cls._instances:
            if instance.baseFilename == filename:
                return instance
        # There aren't any so make a new one
        rfh = cls(filename,
                  maxBytes = cls._MAX_BYTES,
                  backupCount = cls._BACKUP_COUNT)
        cls._instances.add(rfh)
        return rfh

