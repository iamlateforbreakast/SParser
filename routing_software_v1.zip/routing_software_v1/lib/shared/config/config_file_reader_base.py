
from jsonschema import validate
import os
import yaml

from lib.shared.config.schema import schema as _SCHEMA
from builtins import FileNotFoundError

"""-----------------------------------------------
 Class and functions for configuration file
 reader and validator
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Sam Wallis
-----------------------------------------------"""

class ConfigFileReaderBase():
    
    """
    An abstract base class for the configuration file reader
    
    Instantiation of this base class raises an exception. Instead,
    create a subclass, and override the 'add_*' methods where
    required. E.g. a routing manager need not override
    ConfigFileReaderBase.add_spw (which does nothing), since SpW
    is not modelled in the software
    """
    
    def __init__(self):
    
        """ Initialiser """
        
        raise NotImplementedError('Class is abstract')
    
    # ----------
    # YAML loading function
    
    def load(self, config_path):
        
        """
        Load the configuration file 'dict' into the system by
        calling the 'add_*' functions, to be implemented by
        user-built subclasses
        
        There should be no need to override this method.
        Should only need to be called once per startup of
        software
        
        @param config_path: the absolute or relative path to the
            config YAML
        @raises:
            - ValidationError if config file does not adhere
            to YAML schema, SchemaError if schema is invalid
            - ValueError (usually) if loaded config has invalid values
            (e.g. bad node ID, reused port)
            - KeyError if mandatory attributes missing from YAML
        """
        
        # Basic checks (file exists and is YAML)
        
        if not os.path.isfile(config_path):
            raise FileNotFoundError('The specified config file was not found')
        if os.path.splitext(config_path)[-1].lower() not in ('.yaml', '.yml'):
            raise ValueError('The specified config file must be a YAML file')
        
        # Load YAML into Python dict
        
        with open(config_path, 'r') as cf:
            try:
                config_dict = yaml.safe_load(cf)
            except yaml.parser.ParserError as e:
                raise RuntimeError(f'Syntax error in YAML file '
                                   f'"{os.path.abspath(config_path)}"') from e
        
        # Validate against HCA config schema
        
        self._validate(config_dict)
        
        # Config file 'header' - name, description and versions
        # (doc and def, both mandatory - def must be 2.0+)
        
        self.doc_version = config_dict['doc_version']
        self.def_version = config_dict['def_version']
        if float(self.def_version) < 3.0:
            raise RuntimeError('Configuration file definition not V3.0+')
        
        self.name = config_dict.get('name', '')
        self.desc = config_dict.get('desc', '')
        
        # Definitions - just keep it as an unformatted dict
        
        definitions = config_dict.get('definitions', dict())
        self.add_definitions(**definitions)
        
        # Iterate over components:
        # - (Dual-modules)
        #     - Modules
        #         - (PCBs)
        #             - Nodes
        # - SpW
        # - SERDES
        # - Antenna config
        # - State variables
        
        config = config_dict.pop('config')
        
        # Iteration starts on the dual-modules
        for dual_module in config.get('dual_modules'):
            # Snap off the modules attribute
            modules = dual_module.pop('modules')
            # Add the dual-module
            self.add_dual_module(**dual_module)
            # Now add the modules
            for module in modules:
                # Snap off the PCBs attribute
                pcbs = module.pop('pcbs')
                # Add the module
                self.add_module(
                        # This argument can be used, or ignored
                        dual_module['name'],
                        # The module attributes
                        **module)
                # Now add the PCBs
                for pcb in pcbs:
                    # Snap off the nodes attribute
                    nodes = pcb.pop('nodes')
                    # Add the PCBs
                    self.add_pcb(
                            # These arguments can be used, or ignored
                            dual_module['name'],
                            module['name'],
                            # The PCB attributes
                            **pcb)
                    # Now add the nodes
                    for node in nodes:
                        self.add_node(
                                # These arguments can be used, or ignored
                                dual_module['name'],
                                module['name'],
                                pcb['pos'],
                                # The node attributes
                                **node)
        # Add SpW (optional)
        for spw_link in config.get('spw', []):
            self.add_spw(**spw_link)
        # Add SERDES (optional)
        for serdes_link in config.get('serdes', []):
            self.add_serdes(**serdes_link)
        # Add FPGA LVDS (optional)
        for fpga_lvds_link in config.get('fpga_lvds', []):
            self.add_fpga_lvds(**fpga_lvds_link)
        # Add antenna configurations (optional)
        antennas = config.get('antennas', [])
        for antenna_config in antennas:
            self.add_antenna_element(**antenna_config)
        # Set state variables (optional)
        state = config.get('state', dict())
        if state:
            # Set data formats (optional)
            data_formats = state.get('data_formats', [])
            for data_format in data_formats:
                self.set_state_data_format(**data_format)
            # Set external control link (optional)
            ext_ctrl_link = state.get('ext_ctrl_link', dict())
            if ext_ctrl_link:
                self.set_state_ext_ctrl_link(**ext_ctrl_link)
    
    # ----------
    # Validation function
    
    def _validate(self, config_dict):
        
        """
        Validate a given python dict against the schema
        
        @params config_dict: the python dict to validate
        @raises: ValidationError if config file does not adhere
            to YAML schema, or SchemaError if schema is invalid
        """
        
        # Schema turned off for now since it needs updating
        #validate(instance = config_dict, schema = _SCHEMA)
    
    # ----------
    # add_* / set_* functions called by 'load'
    
    def add_definitions(self, **kwargs):
        
        """
        Function called by 'load' to add definitions - to
        be overridden by subclass (or not)
        
        @param kwargs: dict of kw-arguments for the dual-module,
            from configuration file
        """
    
    def add_dual_module(self, **kwargs):
        
        """
        Function called by 'load' to add a dual-module container - to
        be overridden by subclass (or not)
        
        @param kwargs: dict of kw-arguments for the dual-module,
            from configuration file
        """
        
    def add_module(self, dual_module_name, **kwargs):
    
        """
        Function called by 'load' to add a module to a dual module
        - to be overridden by subclass (or not)
        
        @param dual_module_name: ID of dual module to add module to
        @param kwargs: dict of kw-arguments for the module,
            from configuration file
        """
    
    def add_pcb(self, dual_module_name, module_name, **kwargs):
        
        """
        Function called by 'load' to add a PCB to a module
        - to be overridden by subclass (or not)
        
        @param dual_module_name: ID of module's dual module
        @param module_name: the name of module to add PCB to
        @param kwargs: dict of kw-arguments for the module,
            from configuration file
        """
    
    def add_node(self, dual_module_name, module_name, pcb_pos, **kwargs):
        
        """
        Function called by 'load' to add a node (ASIC or FPGA)
        to a PCB - to be overridden by subclass (or not)
        
        @param dual_module_name: Dual module name
        @param module_name: the name of module with the target PCB
        @param pcb_pos: position ID of the PCB to add the node to
        @param kwargs: dict of kw-arguments for the node,
            from configuration file
        """
    
    def add_spw(self, **kwargs):
        
        """
        Function called by 'load' to add a *bidirectional* SPW
        link between two nodes - to be overridden by subclass (or not)
        
        @param kwargs: dict of kw-arguments for the link,
            from configuration file
        """
    
    def add_serdes(self, **kwargs):
    
        """
        Function called by 'load' to add a SERDES link -
        to be overridden by subclass (or not)
        
        @param kwargs: dict of kw-arguments for the link,
            from configuration file
        """
    
    def add_fpga_lvds(self, **kwargs):
    
        """
        Function called by 'load' to add an FPGA LVDS
        link - to be overridden by subclass (or not)
        
        @param kwargs: dict of kw-arguments for the link,
            from configuration file
        """
    
    def add_antenna_element(self, **kwargs):
        
        """
        Function called by 'load' to add antenna elements -
        to be overridden by subclass (or not)
        
        @param kwargs: dict of kw-arguments for antenna config,
            from configuration file
        """
    
    def set_state_bfn_mode(self, **kwargs):
        
        """
        Function called by 'load' to set BFN modes per node type,
        from 'state' attribute - to be overridden by subclass (or not)
        
        @param kwargs: dict of kw-arguments for a single rank,
            from configuration file
        """
    
    def set_state_data_format(self, **kwargs):
        
        """
        Function called by 'load' to set data formats per rank-pair,
        from 'state' attribute - to be overridden by subclass (or not)
        
        @param kwargs: dict of kw-arguments for data format between
            a single pair of ranks, from configuration file
        """
    
    def set_state_ext_ctrl_link(self, **kwargs):
        
        """
        Function called by 'load' to set external control link,
        from 'state' attribute - to be overridden by subclass (or not)
        
        @param kwargs: dict of kw-arguments for external control
            link, from configuration file
        """

