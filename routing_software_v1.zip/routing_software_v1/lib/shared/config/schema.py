
"""----------------------------------------------------------
 A YAML/JSON schema for HCA configuration files
 
 https://json-schema.org/understanding-json-schema/reference/
 
 The schema validates the field structures and types, e.g.
 ensuring that an attribute is of a 'list', or 'integer' type
 between two values. It does not use any sophisticated
 look-ahead mechanisms - e.g. it can't ensure that SpW source
 node IDs map to existing nodes. It is down to individual HCA
 components to ensure that the config corresponds to a valid
 DTP structure
 
 Copyright 2019, 2020 Airbus Defence & Space Ltd.
 @author Sam Wallis
----------------------------------------------------------"""

schema = {
    # Dict is formed of 'name' and 'config' attributes
    'type': 'object',
    'properties': {
        # Config name
        'name': {'type': 'string'},
        # The actual config
        'config': {
            # 'config' is formed of 'modules' and 'serdes' dicts
            'type': 'object',
            'properties': {
                # Modules
                'modules': {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            # Module ID
                            'id': {
                                'type': 'integer',
                                'minimum': 0,
                                'maximum': 254
                            },
                            # Module name
                            'name': {'type': 'string'},
                            # Control module?
                            'control': {'type': 'boolean'},
                            # Powered on at startup?
                            'powered': {'type': 'boolean'},
                            # Module nodes
                            'nodes': {
                                'type': 'array',
                                'items': {
                                    'type': 'object',
                                    'properties': {
                                        # Node ID
                                        'id': {
                                            'type': 'integer',
                                            'minimum': 0,
                                            'maximum': 254
                                        },
                                        # Node position ID
                                        'pos': {
                                            'type': 'integer',
                                            'minimum': 0,
                                            'maximum': 3
                                        },
                                        # Node name
                                        'name': {'type': 'string'},
                                        # Node type
                                        'type': {
                                            'type': 'string',
                                            'enum': ['RX', 'RXBFN', 'SW',
                                                     'TX', 'TXBFN', 'CTLFPGA',
                                                     'CTLASIC', 'DSC']
                                        }
                                    }
                                },
                                'minItems': 1,
                                'maxItems': 4
                            },
                            # Intra-module SpW links
                            'spw': {
                                'type': 'array',
                                'items': {
                                    'type': 'object',
                                    'properties': {
                                        # Source node ID
                                        'src_node': {
                                            'type': 'integer',
                                            'minimum': 0,
                                            'maximum': 254
                                        },
                                        # Source physical out-port
                                        'src_port': {
                                            'type': 'integer',
                                            'minimum': 8,
                                            'maximum': 11
                                        },
                                        # Sink node ID
                                        'sink_node': {
                                            'type': 'integer',
                                            'minimum': 0,
                                            'maximum': 254
                                        },
                                        # Sink physical in-port
                                        'sink_port': {
                                            'type': 'integer',
                                            'minimum': 8,
                                            'maximum': 11
                                        }
                                    }
                                },
                                'minItems': 1
                            }
                        },
                        'required': ['id', 'name', 'control', 
                                     'powered', 'nodes'],
                        'additionalProperties': False
                    }
                },
                # SERDES links
                'serdes': {
                    'type': 'array',
                    'items': {
                        'type': 'object',
                        'properties': {
                            # Link name
                            'name': {'type': 'string'},
                            # Source node ID
                            'src_node': {
                                'type': 'integer',
                                'minimum': 0,
                                'maximum': 254
                            },
                            # Source physical out-port
                            'src_port': {
                                'type': 'integer',
                                'minimum': 12,
                                'maximum': 79
                            },
                            # Sink node ID
                            'sink_node': {
                                'type': 'integer',
                                'minimum': 0,
                                'maximum': 254
                            },
                            # Sink physical in-port
                            'sink_port': {
                                'type': 'integer',
                                'minimum': 12,
                                'maximum': 79
                            }
                        },
                        'required': ['name', 'src_node', 'src_port',
                                     'sink_node', 'sink_port'],
                        'additionalProperties': False
                    },
                    'minItems': 1
                }
            },
            'required': ['modules']
        },
    },
    # 'config' is required
    'required': ['config'],
    # Disallow any other attributes
    'additionalProperties': False
}
