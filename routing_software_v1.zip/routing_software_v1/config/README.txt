This directory contains YAML configuration files of a variety of Hyperion harnesses.
