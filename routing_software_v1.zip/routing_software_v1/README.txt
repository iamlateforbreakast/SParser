====== LINUX ======

- Add path to *this folder* to PYTHONPATH
  E.g:
      setenv PYTHONPATH $PYTHONPATH:$pwd

This will then setup the path to all libraries providing all scripts have the imports right in Windows they will also work under Linux

====== Windows ======

- Add path to *this folder* to PYTHONPATH
  E.g:
      setx PYTHONPATH "%cd%;%PYTHONPATH%"
  (Console will need to be restarted for changes to take place)